<?php
/**
*
* acp [English]
* @package Advanced Dungeons & Rabbits (ADR) RPG Mod for phpBB 3.3.x
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

$lang = array_merge($lang, [
	// ACP Navigation, Module Groups & Categories
	'ACP_ADR_TITLE'                  => 'ADR RPG Mod',
	'ACP_ADR_GENERAL'                => 'General Settings',
	'ACP_ADR_RACES'                  => 'Races',
	'ACP_ADR_CLASSES'                => 'Classes',
	'ACP_ADR_ALIGNMENTS'             => 'Alignments',
	'ACP_ADR_ELEMENTS'               => 'Elements',
	'ACP_ADR_MONSTERS'               => 'Monsters',
	'ACP_ADR_SKILLS'                 => 'Skills',
	'ACP_ADR_ITEM_TYPES'             => 'Item Types',
	'ACP_ADR_ITEMS'                  => 'Items',
	'ACP_ADR_STORES'                 => 'Admin Stores',
	'ACP_ADR_VAULT_EXCHANGE'         => 'Stock Exchange',
	'ACP_ADR_USERS'                  => 'Manage Users',
	'ACP_ADR_JAILED_USERS'           => 'Jailed Users',
	'ACP_ADR_TOOLS'                  => 'Tools',
	'ACP_ADR_CONVERTERS'             => 'Converters',

	// Legacy Translation Key Bindings
	'ADR_ACP_GENERAL_CAT'            => 'ADR-General',
	'ADR_ACP_SETTINGS_CAT'           => 'ADR-Settings',
	'ADR_ACP_MISC_CAT'               => 'Misc',
	'ADR_ACP_VAULT_CAT'              => 'ADR-Vault',
	'ADR_ACP_SHARES_CAT'             => 'Shares',
	'ADR_ACP_FORUM_SHOP_CAT'         => 'Forum\'s shop',

	// Global Form Messages
	'ADR_CONFIG_SAVED'               => 'Configuration saved.',
	'ADR_ENTITY_DELETED'             => 'Entry deleted.',
	'ADR_SAVED'                      => 'Changes saved.',
	'ADR_FIELD_EMPTY'                => 'Please fill in all required fields.',

	// Global Core Setup Configurations
	'ADR_GENERAL_SETTINGS'           => 'General Settings',
	'ADR_ENABLE_EXPLAIN'             => 'Enable or disable the entire RPG system.',
	'ADR_XP_SETTINGS'                => 'Experience Point Settings',
	'ADR_XP_FOR_NEW_EXPLAIN'         => 'XP awarded when a user posts a new topic.',
	'ADR_XP_FOR_REPLY_EXPLAIN'       => 'XP awarded when a user replies to a topic.',
	'ADR_XP_FOR_EDIT_EXPLAIN'        => 'XP awarded when a user edits a post.',
	'ADR_NEXT_LEVEL_PENALTY_EXPLAIN' => 'Percentage increase in XP required per level.',
	'ADR_STAT_POINTS_EXPLAIN'        => 'Stat points awarded per level-up.',

	// Modular Switch Toggles
	'ADR_MODULE_SETTINGS'            => 'Module Settings',
	'ADR_BATTLE_ENABLE_EXPLAIN'      => 'Enable monster battles.',
	'ADR_PVP_ENABLE_EXPLAIN'         => 'Enable player vs player battles.',
	'ADR_SHOP_ENABLE_EXPLAIN'        => 'Enable the market/shop system.',
	'ADR_VAULT_ENABLE_EXPLAIN'       => 'Enable the vault/bank system.',
	'ADR_TEMPLE_ENABLE_EXPLAIN'      => 'Enable the temple (healing).',
	'ADR_FORGE_ENABLE_EXPLAIN'       => 'Enable the forge (crafting).',
	'ADR_JAIL_ENABLE_EXPLAIN'        => 'Enable the jail/courthouse system.',
	'ADR_THIEF_ENABLE_EXPLAIN'       => 'Allow thief-class characters to steal items.',

	// Profile View Modifiers
	'ADR_DISPLAY_SETTINGS'           => 'Display Settings',
	'ADR_TOPICS_DISPLAY_EXPLAIN'     => 'Show RPG info (level, class, etc.) next to posts.',
	'ADR_PROFILE_DISPLAY_EXPLAIN'    => 'Show RPG info on user profiles.',

	// Financial Markets Integration
	'ADR_STOCK_SETTINGS'             => 'Stock Exchange Settings',
	'ADR_STOCK_USE_EXPLAIN'          => 'Enable the vault stock exchange.',
	'ADR_STOCK_TIME_EXPLAIN'         => 'How often (in seconds) stock prices fluctuate.',
	'ADR_STOCK_MIN_CHANGE_EXPLAIN'   => 'Minimum percentage change per fluctuation.',
	'ADR_STOCK_MAX_CHANGE_EXPLAIN'   => 'Maximum percentage change per fluctuation.',

	// Item Categorizations
	'ADR_ITEM_TYPE_EXPLAIN'          => 'Here you can configure Item Types. Add, edit or delete them.',
	'ADR_ITEM_TYPE_ADD_EDIT'         => 'Add or edit of Item Types',
	'ADR_ITEM_TYPE_NAME'             => 'Name',
	'ADR_ITEM_TYPE_NAME_EXPLAIN'     => 'The name of the item type. You can use a language key.',
	'ADR_ITEM_TYPE_ID'               => 'ID',
	'ADR_ITEM_TYPE_ID_EXPLAIN'       => 'The ID of the Item Type',
	'ADR_ITEM_TYPE_PRICE'            => 'Price',
	'ADR_ITEM_TYPE_PRICE_EXPLAIN'    => 'The basic price of the Item Type.',
	'ADR_ITEM_TYPE_SUCCESSFUL_ADDED' => 'New Item Type successfully added',
	'ADR_ITEM_TYPE_SUCCESSFUL_EDITED'=> 'Item Type successfully edited',
	'ADR_ITEM_TYPE_SUCCESSFUL_DELET' => 'Item Type deleted successfully',
	'ADR_ITEM_TYPE_ADD'              => 'Add an Item Type',
	'ADR_ITEM_TYPE_CATEGORY'         => 'Category',
	'ADR_ITEM_TYPE_CATEGORY_EXPLAIN' => 'Select a category from the drop down list or write a new category in the text field',

	// Character Generation Settings: Races
	'ADR_RACES_EXPLAIN'              => 'Manage the races players can choose for their characters.',
	'ADR_RACES_ADD'                  => 'Add a race',
	'ADR_RACES_ADD_EDIT'             => 'Add or edit or races',
	'ADR_RACES_ADD_EDIT_EXPLAIN'     => 'Here you can add or edit races.',
	'ADR_RACES_NAME_EXPLAIN'         => 'You can use a language key',
	'ADR_RACES_IMAGE_EXPLAIN'        => 'The image must be placed into the directory /adr/images/races/',
	'ADR_RACES_LEVEL'                => 'User level',
	'ADR_RACES_LEVEL_EXPLAIN'        => 'You can define a user level for the use of this race',
	'ADR_RACES_LEVEL_ALL'            => 'All',
	'ADR_RACES_LEVEL_ADMIN'          => 'Administrator',
	'ADR_RACES_LEVEL_MOD'            => 'Moderator',
	'ADR_RACE_SUCCESSFUL_ADDED'      => 'New race successfully added',
	'ADR_RACE_SUCCESSFUL_EDITED'     => 'Race successfully edited',
	'ADR_RACE_DEFAULT_PROTECT'       => 'You can not delete the default race',
	'ADR_RACE_SUCCESSFUL_DELETED'    => 'Race deleted successfully',
	'ADR_RACES_WEIGHT'               => 'Base max weight',
	'ADR_RACES_WEIGHT_PER_LEVEL'     => 'Percentage of weight increase at level up',

	// Character Generation Settings: Classes
	'ADR_CLASSES_EXPLAIN'            => 'Manage the classes players can choose for their characters.',
	'ADR_CLASSES_ADD'                => 'Add a class',
	'ADR_CLASSES_ADD_EDIT'           => 'Add or edit of classes',
	'ADR_CLASSES_ADD_EDIT_EXPLAIN'   => 'Here you can add or edit classes.',
	'ADR_CLASSES_IMAGE_EXPLAIN'      => 'The image must be placed into the directory /adr/images/classes/',
	'ADR_CLASSES_LEVEL_EXPLAIN'      => 'You can define a user level for the use of this class',
	'ADR_CLASSES_REQ_MIGHT'          => 'Minimum value of the characteristic Strength',
	'ADR_CLASSES_REQ_DEXT'           => 'Minimum value of the characteristic Dexterity',
	'ADR_CLASSES_REQ_CONST'          => 'Minimum value of the characteristic Constitution',
	'ADR_CLASSES_REQ_INT'            => 'Minimum value of the characteristic Intelligence',
	'ADR_CLASSES_REQ_WIS'            => 'Minimum value of the characteristic Wisdom',
	'ADR_CLASSES_REQ_CHA'            => 'Minimum value of the characteristic Charm',
	'ADR_CLASSES_REQ_MA'             => 'Minimum value of the characteristic Magic Attack',
	'ADR_CLASSES_REQ_MD'             => 'Minimum value of the characteristic Magic Resistance',
	'ADR_CLASS_SUCCESSFUL_ADDED'     => 'New class successfully added',
	'ADR_CLASS_SUCCESSFUL_EDITED'    => 'Class successfully edited',
	'ADR_CLASS_DEFAULT_PROTECT'      => 'You can not delete the default class',
	'ADR_CLASS_SUCCESSFUL_DELETED'   => 'Class deleted successfully',
	'ADR_CLASSES_UPDATE_XP_REQ'      => 'Required experience points to level up',
	'ADR_CLASSES_UPDATE_OF'          => 'Is an evolution of',
	'ADR_CLASSES_UPDATE_OF_REQ'      => 'Minimum level to evolve to this class',
	'ADR_CLASSES_SELECTABLE'         => 'Can be chosen during character creation',
	'ADR_CLASSES_EVOLUTION_NONE'     => 'Is not an evolution',

	// Elemental Affinity Modifications
	'ADR_ELEMENTS_ADD'               => 'Add an element',
	'ADR_ELEMENTS_EXPLAIN'           => 'Here you can configure elements. Add, edit or delete them.',
	'ADR_ELEMENTS_ADD_EDIT'          => 'Addition and edition of elements',
	'ADR_ELEMENTS_ADD_EDIT_EXPLAIN'  => 'Here you can add or edit elements.',
	'ADR_ELEMENTS_COLOUR'            => 'Element Colour',
	'ADR_ELEMENTS_COLOUR_EX'         => 'Here you can set a colour to be applied to item names during battle.<br>You can set using an actual name, eg. red, as long as it has been defined in your css file otherwise you will need to add as a hex value instead.',
	'ADR_ELEMENTS_IMAGE_EXPLAIN'     => 'The image must be placed into the directory /adr/images/elements/',
	'ADR_ELEMENTS_LEVEL_EXPLAIN'     => 'You can define a user level for the use of this element',
	'ADR_ELEMENT_SUCCESSFUL_ADDED'   => 'New element successfully added',
	'ADR_ELEMENT_SUCCESSFUL_EDITED'  => 'Element successfully edited',
	'ADR_ELEMENT_SUCCESSFUL_DELETED' => 'Element deleted successfully',
	'ADR_ELEMENT_DEFAULT_PROTECT'    => 'You can not delete the default element',
	'ADR_ELEMENT_OPPOSE_STR'         => 'Chose an opposing element that this element will be stronger than',
	'ADR_ELEMENT_OPPOSE_WEAK'        => 'Chose an opposing element that this element will be weaker than',
	'ADR_ELEMENT_OPPOSE_STR_DMG'     => 'Chose a percentage for the stronger element',
	'ADR_ELEMENT_OPPOSE_SAME_DMG'    => 'Chose a percentage for the same element',
	'ADR_ELEMENT_OPPOSE_WEAK_DMG'    => 'Chose a percentage for the weaker element',

	// Alignment Setup Properties
	'ADR_ALIGNMENTS_ADD'             => 'Add an alignment',
	'ADR_ALIGNMENTS_EXPLAIN'         => 'Here you can configure alignments. Add, edit or delete them.',
	'ADR_ALIGNMENTS_ADD_EDIT'        => 'Add or edit of alignments',
	'ADR_ALIGNMENTS_ADD_EDIT_EXPLAIN'=> 'Here you can add or edit alignments.',
	'ADR_ALIGNMENTS_IMAGE_EXPLAIN'   => 'The image must be placed into the directory /adr/images/alignments/',
	'ADR_ALIGNMENTS_LEVEL_EXPLAIN'   => 'You can define a user level for the use of this alignment',
	'ADR_ALIGNMENT_SUCCESSFUL_ADDED' => 'New alignment successfully added',
	'ADR_ALIGNMENT_SUCCESSFUL_EDITED'=> 'Alignment successfully edited',
	'ADR_ALIGNMENT_SUCCESSFUL_DELET' => 'Alignment deleted successfully',
	'ADR_ALIGNMENT_DEFAULT_PROTECT'  => 'You can not delete the default alignment',

	// Skill Training Constraints
	'ADR_SKILLS_EXPLAIN'             => 'Here you can edit the skills',
	'ADR_SKILLS_REQ'                 => 'Uses',
	'ADR_SKILLS_ADD_EDIT'            => 'Edit of the skills',
	'ADR_SKILLS_REQ_EXPLAIN'         => 'Number of successful uses before the skill increases',
	'ADR_SKILLS_SUCCESSFUL_EDITED'   => 'Skill successfully updated',

	// Dynamic Environments and Ecosystem Cycles
	'ADR_ACP_SEASONS_EXPLAIN'        => 'Configure the season cycle. The season changes automatically over time and affects zone building images.',
	'ADR_ACP_SEASONS_CONFIG'         => 'Season Configuration',
	'ADR_ACP_SEASON_CHOICE'          => 'Current Season',
	'ADR_ACP_SEASON_TIME'            => 'Season Duration',
	'ADR_ACP_SEASON_DAYS'            => 'days',
	'ADR_ACP_SEASON_EMPTY'           => 'Season duration cannot be empty.',
	'ADR_ACP_SEASON_SAVED'           => 'Season settings saved.',
	'ADR_ACP_ZONE_GENERAL_TITLE'     => 'Zone General Settings',
	'ADR_ACP_ZONE_GENERAL_EXPLAIN'   => 'Configure global zone behaviour and stat bonuses.',
	'ADR_ACP_ZONE_GENERAL_SAVED'     => 'Zone general settings saved.',
	'ADR_ACP_ZONE_DEAD_TRAVEL'       => 'Prevent travel while dead',
	'ADR_ACP_ZONE_BONUS_STAT'        => 'Enable zone stat bonus',
	'ADR_ACP_ZONE_BONUS_ATT'         => 'Attack Bonus',
	'ADR_ACP_ZONE_BONUS_DEF'         => 'Defense Bonus',

	// System Actions Log Tracker
	'ADR_LOG_ZONE_SAVED'             => '<strong>ADR zone saved:</strong> %s',
	'ADR_MONSTERS_EXPLAIN'           => 'Manage monsters available in the battle system.',

	// Administrative Character Sheet Overrides
	'ADR_ADMIN_CHAR_INVENTORY_SEL'   => 'Select a users inventory',
	'ADR_ADMIN_CHAR_DELETE_WARN'     => 'Delete this character - This cannot be reversed afterwards!',
	'ADR_ADMIN_CHAR_MOD_VALIDATE'    => 'Validate the modifications',
	'ADR_ADMIN_CHAR_CHARACTERISTICS' => 'Characteristics',
	'ADR_ADMIN_CHAR_EDIT_SUCCESS'    => 'Character successfully edited',
	'ADR_ADMIN_CHAR_DELETED_SUCCESS' => 'Character successfully deleted',
	'ADR_ADMIN_CHAR_LACK_ERROR'      => 'This user does not have a character',
	'ADR_USER_ADMIN_MANAGEMENT'      => 'Characters management',
	'ADR_USER_ADMIN_EXPLAIN'         => 'Here you can edit or delete the characters in ADR mod',
	'ADR_USER_BATTLE_SKILL_LIMITS'   => 'Battle & Skill Limits',
	'ADR_USER_BATTLE_REMAINING'      => 'Current battles remaining:',
	'ADR_USER_SKILL_REMAINING'       => 'Current skill use remaining:',
	'ADR_USER_TRADING_REMAINING'     => 'Current trading skill uses remaining:',
	'ADR_USER_THIEF_REMAINING'       => 'Current thief skill uses remaining:',

	// Operational Inventory Flow Monitors
	'ADR_TRACKER_TITLE'              => 'Track ADR Items',
	'ADR_TRACKER_TEXT'               => 'Here you can view purchases, sales, donations & thefts',
]);