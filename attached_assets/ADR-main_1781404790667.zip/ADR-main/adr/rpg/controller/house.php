<?php

namespace adr\rpg\controller;

class house
{
    protected $config;
    protected $db;
    protected $user;
    protected $template;
    protected $helper;
    protected $request;
    protected $auth;
    protected $root_path;
    protected $php_ext;
    protected $manager;

    public function __construct(
        \phpbb\config\config $config,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\user $user,
        \phpbb\template\template $template,
        \phpbb\controller\helper $helper,
        \phpbb\request\request $request,
        \phpbb\auth\auth $auth,
        $root_path,
        $php_ext,
        \adr\rpg\service\manager $manager
    ) {
        $this->config    = $config;
        $this->db        = $db;
        $this->user      = $user;
        $this->template  = $template;
        $this->helper    = $helper;
        $this->request   = $request;
        $this->auth      = $auth;
        $this->root_path = $root_path;
        $this->php_ext   = $php_ext;
        $this->manager   = $manager;
    }

    public function index()
    {
        if (!$this->user->data['is_registered'])
        {
            redirect(append_sid("{$this->root_path}ucp.{$this->php_ext}"));
        }

        $user_id = (int) $this->user->data['user_id'];
        $this->manager->check_enabled();
        $this->manager->check_ban($user_id);
        $this->manager->check_character_created($user_id);
        $this->manager->check_seasons_cron();

        $adr_user = $this->manager->get_user_infos($user_id);
        $area_id  = (int) $adr_user['character_area'];
        $season   = (int) $this->config['adr_seasons'];
        $season_folder = (string) $season;

        $this->template->assign_vars([
            'L_ZONE_HOUSE'              => $this->user->lang['ADR_ZONE_HOUSE'],
            'L_ZONE_CHARACTER_SHEET'    => $this->user->lang['ADR_CHARACTER_PAGE'],
            'L_ZONE_CHARACTER_INVENTORY'=> $this->user->lang['ADR_INVENTORY'],
            'U_ZONE_CHARACTER_SHEET'    => $this->helper->route('adr_rpg_character'),
            'U_ZONE_CHARACTER_INVENTORY'=> $this->helper->route('adr_rpg_character_inventory'),
            'S_ZONES_ACTION'            => $this->helper->route('adr_rpg_house'),
        ]);

        $this->manager->assign_zone_header($this->template, $this->helper, $this->user, $area_id, $season_folder);

        return $this->helper->render('adr_house.html', $this->user->lang['ADR_ZONE_HOUSE']);
    }
}
