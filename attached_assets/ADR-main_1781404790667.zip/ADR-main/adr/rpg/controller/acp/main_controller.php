<?php
namespace adr\rpg\controller\acp;

class main_controller
{
	public $tpl_name;
    public $page_title;

	protected $config;
	protected $db;
	protected $user;
	protected $template;
	protected $request;
	protected $log;
	protected $manager;
	protected $helper;
	protected $root_path;
	protected $php_ext;
	protected $u_action;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\user $user,
		\phpbb\template\template $template,
		\phpbb\request\request $request,
		\phpbb\log\log $log,
		\adr\rpg\service\manager $manager,
		\phpbb\controller\helper $helper,
		$root_path,
		$php_ext
	)
	{
		$this->config    = $config;
		$this->db        = $db;
		$this->user      = $user;
		$this->template  = $template;
		$this->request   = $request;
		$this->log       = $log;
		$this->manager   = $manager;
		$this->helper    = $helper;
		$this->root_path = $root_path;
		$this->php_ext   = $php_ext;
	}

	public function set_page_url($u_action)
	{
		$this->u_action = $u_action;
	}

	public function general()
	{
		$this->user->add_lang_ext('adr/rpg', 'acp');

		if ($this->request->is_set_post('submit'))
		{
			$settings = [
				'adr_enabled'               => $this->request->variable('adr_enabled', 0),
				'adr_experience_for_new'    => $this->request->variable('adr_experience_for_new', 10),
				'adr_experience_for_reply'  => $this->request->variable('adr_experience_for_reply', 5),
				'adr_experience_for_edit'   => $this->request->variable('adr_experience_for_edit', 1),
				'adr_character_age'         => $this->request->variable('adr_character_age', 16),
				'adr_next_level_penalty'    => $this->request->variable('adr_next_level_penalty', 10),
				'adr_stat_points_per_level' => $this->request->variable('adr_stat_points_per_level', 5),
				'adr_battle_enable'         => $this->request->variable('adr_battle_enable', 1),
				'adr_pvp_enable'            => $this->request->variable('adr_pvp_enable', 1),
				'adr_shop_enable'           => $this->request->variable('adr_shop_enable', 1),
				'adr_vault_enable'          => $this->request->variable('adr_vault_enable', 1),
				'adr_temple_enable'         => $this->request->variable('adr_temple_enable', 1),
				'adr_forge_enable'          => $this->request->variable('adr_forge_enable', 1),
				'adr_jail_enable'           => $this->request->variable('adr_jail_enable', 1),
				'adr_thief_enable'          => $this->request->variable('adr_thief_enable', 1),
				'adr_thief_points'          => $this->request->variable('adr_thief_points', 5),
				'adr_topics_display'        => $this->request->variable('adr_topics_display', 1),
				'adr_profile_display'       => $this->request->variable('adr_profile_display', 1),
				'adr_gold_per_battle'       => $this->request->variable('adr_gold_per_battle', 10),
				'stock_use'                 => $this->request->variable('stock_use', 1),
				'stock_time'                => $this->request->variable('stock_time', 86400),
				'stock_min_change'          => $this->request->variable('stock_min_change', 1),
				'stock_max_change'          => $this->request->variable('stock_max_change', 10),
			];

			foreach ($settings as $key => $value)
			{
				$this->config->set($key, $value);
			}

			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ADR_CONFIG_UPDATED');

			trigger_error($this->user->lang('ADR_CONFIG_SAVED') . adm_back_link($this->u_action));
		}

		$this->template->assign_vars([
			'ADR_ENABLED'               => $this->config['adr_enabled'],
			'ADR_XP_FOR_NEW'            => $this->config['adr_experience_for_new'],
			'ADR_XP_FOR_REPLY'          => $this->config['adr_experience_for_reply'],
			'ADR_XP_FOR_EDIT'           => $this->config['adr_experience_for_edit'],
			'ADR_CHARACTER_AGE'         => $this->config['adr_character_age'],
			'ADR_NEXT_LEVEL_PENALTY'    => $this->config['adr_next_level_penalty'],
			'ADR_STAT_POINTS_PER_LEVEL' => $this->config['adr_stat_points_per_level'],
			'ADR_BATTLE_ENABLE'         => $this->config['adr_battle_enable'],
			'ADR_PVP_ENABLE'            => $this->config['adr_pvp_enable'],
			'ADR_SHOP_ENABLE'           => $this->config['adr_shop_enable'],
			'ADR_VAULT_ENABLE'          => $this->config['adr_vault_enable'],
			'ADR_TEMPLE_ENABLE'         => $this->config['adr_temple_enable'],
			'ADR_FORGE_ENABLE'          => $this->config['adr_forge_enable'],
			'ADR_JAIL_ENABLE'           => $this->config['adr_jail_enable'],
			'ADR_THIEF_ENABLE'          => $this->config['adr_thief_enable'],
			'ADR_THIEF_POINTS'          => $this->config['adr_thief_points'],
			'ADR_TOPICS_DISPLAY'        => $this->config['adr_topics_display'],
			'ADR_PROFILE_DISPLAY'       => $this->config['adr_profile_display'],
			'ADR_GOLD_PER_BATTLE'       => $this->config['adr_gold_per_battle'],
			'STOCK_USE'                 => $this->config['stock_use'],
			'STOCK_TIME'                => $this->config['stock_time'],
			'STOCK_MIN_CHANGE'          => $this->config['stock_min_change'] ?? 1,
			'STOCK_MAX_CHANGE'          => $this->config['stock_max_change'] ?? 10,
			'U_ACTION'                  => $this->u_action,
		]);

		$this->tpl_name = 'template/adr_acp_general';
    	$this->page_title = $this->user->lang('ACP_ADR_GENERAL');
	}

	protected function render_list($type, $table, $title_lang)
	{
		$this->user->add_lang_ext('adr/rpg', 'acp');
		$this->user->add_lang_ext('adr/rpg', 'common');

		$id = $this->request->variable('id', 0);
		$action = $this->request->variable('action', '');
		$id_col = $type . '_id';
		$template_name = $type . 's';
		$template_vars = [
			'class' => ['template' => 'classes', 'loop' => 'CLASSES'],
			'item_type' => ['template' => 'item_types', 'loop' => 'ITEM_TYPES', 'id_col' => 'item_type_id'],
			'item' => ['template' => 'items', 'loop' => 'ITEMS'],
			'store' => ['template' => 'stores', 'loop' => 'STORES'],
			'stock' => ['template' => 'vault_exchange', 'loop' => 'EXCHANGE', 'id_col' => 'stock_id'],
			'monster' => ['template' => 'monsters', 'loop' => 'MONSTERS'],
		];

		if (isset($template_vars[$type]))
		{
			$template_name = $template_vars[$type]['template'];
			$id_col = $template_vars[$type]['id_col'] ?? $id_col;
			$loop_var = $template_vars[$type]['loop'];
		}
		else
		{
			$loop_var = strtoupper($type) . 'S';
		}

		if ($this->request->is_set_post('submit'))
		{
			$data = $this->collect_entity_data($type);

			if (!empty($data))
			{
				if ($id)
				{
					$this->db->sql_query('UPDATE ' . $table . '
						SET ' . $this->db->sql_build_array('UPDATE', $data) . '
						WHERE ' . $id_col . ' = ' . (int) $id);
				}
				else
				{
					$this->db->sql_query('INSERT INTO ' . $table . ' ' . $this->db->sql_build_array('INSERT', $data));
				}

				$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ADR_CONFIG_UPDATED');
				trigger_error($this->user->lang('ADR_CONFIG_SAVED') . adm_back_link($this->u_action));
			}
		}

		if ($this->request->is_set_post('delete') && $id)
		{
			$this->db->sql_query('DELETE FROM ' . $table . ' WHERE ' . $id_col . ' = ' . (int) $id);
			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_ADR_CONFIG_UPDATED');
			trigger_error($this->user->lang('ADR_ENTITY_DELETED') . adm_back_link($this->u_action));
		}

		$entity = [];
		if ($action === 'edit' && $id)
		{
			$sql = 'SELECT * FROM ' . $table . ' WHERE ' . $id_col . ' = ' . (int) $id;
			$result = $this->db->sql_query($sql);
			$entity = $this->db->sql_fetchrow($result) ?: [];
			$this->db->sql_freeresult($result);
		}

		$sql = 'SELECT * FROM ' . $table . ' ORDER BY ' . $id_col . ' ASC';
		$result = $this->db->sql_query($sql);
		$rows   = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$this->template->assign_vars([
			$loop_var               => $rows,
			'ENTITY'                => $entity,
			'U_ACTION'              => $this->u_action,
			'U_FORM_ACTION'         => ($id && $action === 'edit') ? $this->u_action . '&amp;action=edit&amp;id=' . (int) $id : $this->u_action,
		]);

		$this->tpl_name = 'template/adr_acp_' . $template_name;
    	$this->page_title = $this->user->lang($title_lang);
	}

	protected function collect_entity_data($type)
	{
		$fields = [
			'race' => ['race_name', 'race_desc', 'race_img', 'race_level', 'race_might_bonus', 'race_dexterity_bonus', 'race_constitution_bonus', 'race_intelligence_bonus', 'race_wisdom_bonus', 'race_charisma_bonus', 'race_hp_bonus', 'race_mp_bonus', 'race_weight', 'race_weight_per_level'],
			'class' => ['class_name', 'class_desc', 'class_img', 'class_level', 'class_hp_base', 'class_mp_base', 'class_hp_per_level', 'class_mp_per_level', 'class_update_xp_req', 'class_ac_bonus', 'class_thief_class', 'class_might_req', 'class_dexterity_req', 'class_constitution_req', 'class_intelligence_req', 'class_wisdom_req', 'class_charisma_req'],
			'alignment' => ['alignment_name', 'alignment_desc', 'alignment_img', 'alignment_level'],
			'element' => ['element_name', 'element_desc', 'element_img', 'element_level', 'element_skill_mining_bonus', 'element_skill_stone_bonus', 'element_skill_forge_bonus', 'element_skill_enchant_bonus'],
			'monster' => ['monster_name', 'monster_img', 'monster_level', 'monster_base_hp', 'monster_base_att', 'monster_base_def', 'monster_base_mp', 'monster_base_mp_power', 'monster_base_magic_def', 'monster_xp_reward', 'monster_gold_reward', 'monster_item_reward', 'monster_min_level', 'monster_max_level', 'monster_element'],
			'skill' => ['skill_name', 'skill_desc', 'skill_img', 'skill_req', 'skill_chance'],
			'item_type' => ['item_type_lang', 'item_type_category', 'item_type_base_price', 'item_type_order'],
			'item' => ['item_owner_id', 'item_price', 'item_quality', 'item_power', 'item_duration', 'item_duration_max', 'item_icon', 'item_name', 'item_desc', 'item_type', 'item_ac', 'item_in_shop', 'item_in_warehouse', 'item_equipped', 'item_equip_slot', 'item_weight', 'item_restrict_class', 'item_restrict_class_enable', 'item_restrict_race', 'item_restrict_race_enable', 'item_restrict_align', 'item_restrict_align_enable', 'item_restrict_element', 'item_restrict_element_enable', 'item_restrict_level', 'item_restrict_str', 'item_restrict_dex', 'item_restrict_con', 'item_restrict_int', 'item_restrict_wis', 'item_restrict_cha', 'item_forge_material', 'item_forge_level'],
			'store' => ['store_name', 'store_desc', 'store_img'],
			'stock' => ['stock_name', 'stock_desc', 'stock_price'],
		];

		if (!isset($fields[$type]))
		{
			return [];
		}

		$data = [];
		$int_fields = [
			'item_owner_id', 'item_price', 'item_quality', 'item_power', 'item_duration', 'item_duration_max',
			'item_type', 'item_ac', 'item_in_shop', 'item_in_warehouse', 'item_equipped', 'item_weight',
			'item_restrict_class_enable', 'item_restrict_race_enable', 'item_restrict_align_enable',
			'item_restrict_element_enable', 'item_restrict_level', 'item_restrict_str', 'item_restrict_dex',
			'item_restrict_con', 'item_restrict_int', 'item_restrict_wis', 'item_restrict_cha',
			'item_forge_material', 'item_forge_level',
		];

		foreach ($fields[$type] as $field)
		{
			$data[$field] = $this->request->variable($field, '', true);
			if (preg_match('/_(id|level|bonus|base|req|ac|hp|mp|price|order|chance|reward|element|weight|class)$/', $field) || $field === 'class_thief_class' || in_array($field, $int_fields, true))
			{
				$data[$field] = (int) $data[$field];
			}
		}

		return $data;
	}

	public function item_types()
	{
		return $this->render_list('item_type', $this->manager->get_table('shops_items_type'), 'ACP_ADR_ITEM_TYPES');
	}

	public function items()
	{
		$this->render_list('item', $this->manager->get_table('shops_items'), 'ACP_ADR_ITEMS');

		$this->template->assign_vars([
			'ITEM_TYPES' => $this->manager->get_item_types(),
			'ITEM_QUALITIES' => $this->manager->get_item_qualities(),
			'ITEM_STORES' => $this->manager->get_stores(),
		]);
	}

	public function stores()
	{
		return $this->render_list('store', $this->manager->get_table('stores'), 'ACP_ADR_STORES');
	}

	public function vault_exchange()
	{
		return $this->render_list('stock', $this->manager->get_table('vault_exchange'), 'ACP_ADR_VAULT_EXCHANGE');
	}

	public function users()
	{
		$this->template->assign_vars([
			'USERS' => [],
			'U_ACTION' => $this->u_action,
		]);
		$this->tpl_name = 'template/adr_acp_users';
		$this->page_title = $this->user->lang('ACP_ADR_USERS');
	}

	public function jailed_users()
	{
		$this->template->assign_vars([
			'JAILED_USERS' => [],
			'U_ACTION' => $this->u_action,
		]);
		$this->tpl_name = 'template/adr_acp_jailed_users';
		$this->page_title = $this->user->lang('ACP_ADR_JAILED_USERS');
	}

	public function tools()
	{
		$action = $this->request->variable('action', '');

		if ($this->request->is_set_post('confirm'))
		{
			switch ($action)
			{
				case 'heal_all':
					$this->manager->heal_all_characters();
					trigger_error('All characters healed.');
				break;

				case 'reset_pvp':
					$this->manager->reset_pvp_history();
					trigger_error('PvP history cleared.');
				break;

				case 'reset_battles':
					$this->manager->reset_monster_battle_history();
					trigger_error('Battle history cleared.');
				break;
			}
		}

		$this->template->assign_var('U_ACTION', $this->u_action);
		$this->tpl_name = 'template/adr_acp_tools';
		$this->page_title = $this->user->lang('ACP_ADR_TOOLS');
	}

	
	public function races()
    {
        return $this->render_list('race', $this->manager->get_table('races'), 'ACP_ADR_RACES');
    }

    public function classes()
    {
        return $this->render_list('class', $this->manager->get_table('classes'), 'ACP_ADR_CLASSES');
    }

    public function alignments()
    {
        return $this->render_list('alignment', $this->manager->get_table('alignments'), 'ACP_ADR_ALIGNMENTS');
    }

    public function elements()
    {
        return $this->render_list('element', $this->manager->get_table('elements'), 'ACP_ADR_ELEMENTS');
    }

    public function monsters()
    {
        // Monsters might need a custom template/logic later, but for now:
        return $this->render_list('monster', $this->manager->get_table('battle_monsters'), 'ACP_ADR_MONSTERS');
    }

    public function skills()
    {
        return $this->render_list('skill', $this->manager->get_table('skills'), 'ACP_ADR_SKILLS');
    }

	public function zones()
	{
		return $this->render_list('zone', $this->manager->get_table('zones'), 'ACP_ADR_ZONES');
	}

	public function seasons()
	{
		return $this->render_list('season', $this->manager->get_table('seasons'), 'ACP_ADR_SEASONS');
	}

	public function zone_general()
	{
		return $this->render_list('zone_general', $this->manager->get_table('zone_general'), 'ACP_ADR_ZONE_GENERAL');
	}
}
