<?php

namespace adr\rpg\controller\acp;

class seasons_controller
{
    protected $config;
    protected $db;
    protected $user;
    protected $template;
    protected $request;
    protected $log;
    protected $manager;
    protected $root_path;
    protected $php_ext;
    protected $u_action;

    public function __construct(
        \phpbb\config\config $config,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\user $user,
        \phpbb\template\template $template,
        \phpbb\request\request $request,
        \phpbb\log\log $log,
        \adr\rpg\service\manager $manager,
        $root_path,
        $php_ext
    ) {
        $this->config    = $config;
        $this->db        = $db;
        $this->user      = $user;
        $this->template  = $template;
        $this->request   = $request;
        $this->log       = $log;
        $this->manager   = $manager;
        $this->root_path = $root_path;
        $this->php_ext   = $php_ext;
    }

    public function set_page_url($u_action)
    {
        $this->u_action = $u_action;
    }

    public function main()
    {
        $season_names = [
            1 => $this->user->lang['ADR_SEASON_SPRING'],
            2 => $this->user->lang['ADR_SEASON_SUMMER'],
            3 => $this->user->lang['ADR_SEASON_AUTUMN'],
            4 => $this->user->lang['ADR_SEASON_WINTER'],
        ];

        $current_season = (int) $this->config['adr_seasons'];
        $season_options = '';
        foreach ($season_names as $k => $name)
        {
            $sel = ($k === $current_season) ? ' selected="selected"' : '';
            $season_options .= '<option value="' . $k . '"' . $sel . '>' . $name . '</option>';
        }
        $season_list = '<select name="season">' . $season_options . '</select>';

        if ($this->request->is_set_post('submit'))
        {
            $new_season  = $this->request->variable('season', 1);
            $season_time = $this->request->variable('season_time', 7) * 86400;

            if ($season_time <= 0)
            {
                trigger_error($this->user->lang['ADR_ACP_SEASON_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
            }

            $this->config->set('adr_seasons', $new_season);
            $this->config->set('adr_seasons_time', $season_time);

            $this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'ADR_LOG_SEASONS_SAVED');
            trigger_error($this->user->lang['ADR_ACP_SEASON_SAVED'] . adm_back_link($this->u_action));
        }

        $this->template->assign_vars([
            'SEASON_LIST'       => $season_list,
            'SEASON_TIME'       => floor((int) $this->config['adr_seasons_time'] / 86400),
            'L_SEASONS_TITLE'   => $this->user->lang['ADR_ACP_SEASONS_TITLE'],
            'L_SEASONS_EXPLAIN' => $this->user->lang['ADR_ACP_SEASONS_EXPLAIN'],
            'L_SEASONS_CONFIG'  => $this->user->lang['ADR_ACP_SEASONS_CONFIG'],
            'L_SEASON_CHOICE'   => $this->user->lang['ADR_ACP_SEASON_CHOICE'],
            'L_SEASON_TIME'     => $this->user->lang['ADR_ACP_SEASON_TIME'],
            'L_SEASON_DAYS'     => $this->user->lang['ADR_ACP_SEASON_DAYS'],
            'L_SEASON_SUBMIT'   => $this->user->lang['SUBMIT'],
            'S_SEASONS_ACTION'  => $this->u_action,
        ]);

        $this->template->set_filenames(['body' => '@adr_rpg/adr_acp_seasons.html']);
    }
}
