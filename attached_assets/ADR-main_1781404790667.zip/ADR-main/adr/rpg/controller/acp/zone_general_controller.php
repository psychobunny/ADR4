<?php

namespace adr\rpg\controller\acp;

class zone_general_controller
{
    protected $config;
    protected $db;
    protected $user;
    protected $template;
    protected $request;
    protected $log;
    protected $manager;
    protected $root_path;
    protected $php_ext;
    protected $u_action;

    public function __construct(
        \phpbb\config\config $config,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\user $user,
        \phpbb\template\template $template,
        \phpbb\request\request $request,
        \phpbb\log\log $log,
        \adr\rpg\service\manager $manager,
        $root_path,
        $php_ext
    ) {
        $this->config    = $config;
        $this->db        = $db;
        $this->user      = $user;
        $this->template  = $template;
        $this->request   = $request;
        $this->log       = $log;
        $this->manager   = $manager;
        $this->root_path = $root_path;
        $this->php_ext   = $php_ext;
    }

    public function set_page_url($u_action)
    {
        $this->u_action = $u_action;
    }

    public function main()
    {
        if ($this->request->is_set_post('submit'))
        {
            $dead_travel = $this->request->variable('dead_travel', 0);
            $stat_bonus  = $this->request->variable('stat_bonus', 0);
            $att_bonus   = $this->request->variable('att_bonus', '');
            $def_bonus   = $this->request->variable('def_bonus', '');

            if ($att_bonus === '' || $def_bonus === '')
            {
                trigger_error($this->user->lang['ADR_ACP_FIELD_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
            }

            $this->config->set('zone_dead_travel', (int) $dead_travel);
            $this->config->set('zone_bonus_enable', (int) $stat_bonus);
            $this->config->set('zone_bonus_att', $att_bonus);
            $this->config->set('zone_bonus_def', $def_bonus);

            $this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'ADR_LOG_ZONE_GENERAL_SAVED');
            trigger_error($this->user->lang['ADR_ACP_ZONE_GENERAL_SAVED'] . adm_back_link($this->u_action));
        }

        $this->template->assign_vars([
            'L_ZONE_GENERAL_TITLE'  => $this->user->lang['ADR_ACP_ZONE_GENERAL_TITLE'],
            'L_ZONE_GENERAL_EXPLAIN'=> $this->user->lang['ADR_ACP_ZONE_GENERAL_EXPLAIN'],
            'L_ZONE_DEAD_TRAVEL'    => $this->user->lang['ADR_ACP_ZONE_DEAD_TRAVEL'],
            'L_ZONE_BONUS_STAT'     => $this->user->lang['ADR_ACP_ZONE_BONUS_STAT'],
            'L_ZONE_BONUS_ATT'      => $this->user->lang['ADR_ACP_ZONE_BONUS_ATT'],
            'L_ZONE_BONUS_DEF'      => $this->user->lang['ADR_ACP_ZONE_BONUS_DEF'],
            'L_ZONE_SUBMIT'         => $this->user->lang['SUBMIT'],
            'ZONE_DEAD_TRAVEL'      => $this->config['zone_dead_travel'] ? 'checked="checked"' : '',
            'ZONE_BONUS_STAT'       => $this->config['zone_bonus_enable'] ? 'checked="checked"' : '',
            'ZONE_BONUS_ATT'        => $this->config['zone_bonus_att'],
            'ZONE_BONUS_DEF'        => $this->config['zone_bonus_def'],
            'S_ZONE_ACTION'         => $this->u_action,
        ]);

        $this->template->set_filenames(['body' => '@adr_rpg/adr_acp_zone_general.html']);
    }
}
