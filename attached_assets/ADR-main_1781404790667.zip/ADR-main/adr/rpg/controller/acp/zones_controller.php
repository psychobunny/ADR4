<?php

namespace adr\rpg\controller\acp;

class zones_controller
{
    protected $config;
    protected $db;
    protected $user;
    protected $template;
    protected $request;
    protected $log;
    protected $manager;
    protected $root_path;
    protected $php_ext;
    protected $u_action;

    public function __construct(
        \phpbb\config\config $config,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\user $user,
        \phpbb\template\template $template,
        \phpbb\request\request $request,
        \phpbb\log\log $log,
        \adr\rpg\service\manager $manager,
        $root_path,
        $php_ext
    ) {
        $this->config    = $config;
        $this->db        = $db;
        $this->user      = $user;
        $this->template  = $template;
        $this->request   = $request;
        $this->log       = $log;
        $this->manager   = $manager;
        $this->root_path = $root_path;
        $this->php_ext   = $php_ext;
    }

    public function set_page_url($u_action)
    {
        $this->u_action = $u_action;
    }

    public function main()
    {
        $mode     = $this->request->variable('mode', '');
        $zone_id  = $this->request->variable('zone_id', 0);
        $zones_table = $this->manager->zones_table();

        switch ($mode)
        {
            case 'add':
            case 'edit':
                $this->_edit_zone($mode, $zone_id, $zones_table);
                break;

            case 'savenew':
            case 'saveedit':
                $this->_save_zone($mode, $zone_id, $zones_table);
                break;

            case 'delete':
                $this->_delete_zone($zone_id, $zones_table);
                break;

            default:
                $this->_list_zones($zones_table);
                break;
        }
    }

    protected function _list_zones($zones_table)
    {
        $sql = 'SELECT * FROM ' . $zones_table . ' ORDER BY zone_name ASC';
        $result = $this->db->sql_query($sql);
        $row_class = 'row1';
        while ($zone = $this->db->sql_fetchrow($result))
        {
            $row_class = ($row_class === 'row1') ? 'row2' : 'row1';
            $this->template->assign_block_vars('zones', [
                'NAME'        => $zone['zone_name'],
                'ELEMENT'     => $zone['zone_element'],
                'ITEM'        => $zone['zone_item'],
                'DESTINATION1'=> $zone['goto1_name'],
                'DESTINATION2'=> $zone['goto2_name'],
                'RETURN'      => $zone['return_name'],
                'ROW_CLASS'   => $row_class,
                'U_ZONES_EDIT'  => $this->u_action . '&amp;mode=edit&amp;zone_id=' . $zone['zone_id'],
                'U_ZONES_DELETE'=> $this->u_action . '&amp;mode=delete&amp;zone_id=' . $zone['zone_id'],
            ]);
        }
        $this->db->sql_freeresult($result);

        $this->template->assign_vars([
            'L_ZONE_TITLE'      => $this->user->lang['ADR_ACP_ZONES_TITLE'],
            'L_ZONE_EXPLAIN'    => $this->user->lang['ADR_ACP_ZONES_EXPLAIN'],
            'L_ZONE_NAME'       => $this->user->lang['ADR_ZONE_NAME'],
            'L_ZONE_ELEMENT'    => $this->user->lang['ADR_ELEMENT'],
            'L_ZONE_ITEM'       => $this->user->lang['ADR_ACP_ZONE_ITEM'],
            'L_ZONE_DESTINATION1'=> $this->user->lang['ADR_ACP_ZONE_DESTINATION1'],
            'L_ZONE_DESTINATION2'=> $this->user->lang['ADR_ACP_ZONE_DESTINATION2'],
            'L_ZONE_RETURN'     => $this->user->lang['ADR_ACP_ZONE_RETURN'],
            'L_ZONE_ACTION'     => $this->user->lang['ADR_ACP_ACTION'],
            'L_ZONE_ADD'        => $this->user->lang['ADR_ACP_ZONE_ADD'],
            'L_EDIT'            => $this->user->lang['EDIT'],
            'L_DELETE'          => $this->user->lang['DELETE'],
            'S_ZONES_ACTION'    => $this->u_action,
            'S_HIDDEN_FIELDS'   => '',
        ]);

        $this->template->set_filenames(['body' => '@adr_rpg/adr_acp_zones_list.html']);
        assign_to_template('template_name', '@adr_rpg/adr_acp_zones_list.html');
    }

    protected function _edit_zone($mode, $zone_id, $zones_table)
    {
        $zone = [];
        if ($mode === 'edit' && $zone_id)
        {
            $sql = 'SELECT * FROM ' . $zones_table . " WHERE zone_id = $zone_id";
            $result = $this->db->sql_query($sql);
            $zone = $this->db->sql_fetchrow($result);
            $this->db->sql_freeresult($result);
        }

        $all_zones_sql = 'SELECT * FROM ' . $zones_table . ' ORDER BY zone_name ASC';
        $result = $this->db->sql_query($all_zones_sql);
        $zonelist = $this->db->sql_fetchrowset($result);
        $this->db->sql_freeresult($result);

        $dest1_options = $dest2_options = $return_options = '<option value="">' . $this->user->lang['ADR_ACP_ZONE_CHOOSE_DESTINATION'] . '</option>';
        foreach ($zonelist as $z)
        {
            $sel1 = (isset($zone['goto1_name']) && $zone['goto1_name'] === $z['zone_name']) ? ' selected="selected"' : '';
            $sel2 = (isset($zone['goto2_name']) && $zone['goto2_name'] === $z['zone_name']) ? ' selected="selected"' : '';
            $selr = (isset($zone['return_name']) && $zone['return_name'] === $z['zone_name']) ? ' selected="selected"' : '';
            $dest1_options  .= '<option value="' . $z['zone_name'] . '"' . $sel1 . '>' . $z['zone_name'] . '</option>';
            $dest2_options  .= '<option value="' . $z['zone_name'] . '"' . $sel2 . '>' . $z['zone_name'] . '</option>';
            $return_options .= '<option value="' . $z['zone_name'] . '"' . $selr . '>' . $z['zone_name'] . '</option>';
        }

        $elements = ['Fire', 'Water', 'Earth', 'Air', 'Ice', 'Lightning', 'Poison', 'Shadow', 'Holy', 'Unholy', 'Wind'];
        $elem_options = '';
        foreach ($elements as $el)
        {
            $sel = (isset($zone['zone_element']) && $zone['zone_element'] === $el) ? ' selected="selected"' : '';
            $elem_options .= '<option value="' . $el . '"' . $sel . '>' . $el . '</option>';
        }

        $hidden = '<input type="hidden" name="mode" value="' . ($mode === 'edit' ? 'saveedit' : 'savenew') . '" />';
        if ($mode === 'edit') $hidden .= '<input type="hidden" name="zone_id" value="' . $zone_id . '" />';

        $v = function($key, $default = '') use ($zone) { return isset($zone[$key]) ? $zone[$key] : $default; };
        $chk = function($key) use ($zone, $v) { return $v($key, 0) ? 'checked="checked"' : ''; };

        $this->template->assign_vars([
            'L_ZONE_TITLE'          => $this->user->lang['ADR_ACP_ZONES_TITLE'],
            'L_ZONE_EXPLAIN'        => $this->user->lang['ADR_ACP_ZONES_EXPLAIN'],
            'L_ZONE_SETTINGS'       => $this->user->lang['ADR_ACP_ZONE_SETTINGS'],
            'L_ZONE_CONFIG'         => $this->user->lang['ADR_ACP_ZONE_CONFIG'],
            'L_ZONE_BUILDINGS'      => $this->user->lang['ADR_ACP_ZONE_BUILDINGS'],
            'L_ZONE_EVENTS'         => $this->user->lang['ADR_ACP_ZONE_EVENTS'],
            'L_ZONE_NPC'            => $this->user->lang['ADR_ACP_ZONE_NPC'],
            'L_ZONE_NAME'           => $this->user->lang['ADR_ZONE_NAME'],
            'L_ZONE_NAME_EXPLAIN'   => $this->user->lang['ADR_ACP_ZONE_NAME_EXPLAIN'],
            'L_ZONE_DESC'           => $this->user->lang['ADR_ACP_ZONE_DESC'],
            'L_ZONE_DESC_EXPLAIN'   => $this->user->lang['ADR_ACP_ZONE_DESC_EXPLAIN'],
            'L_ZONE_IMG'            => $this->user->lang['ADR_ACP_ZONE_IMG'],
            'L_ZONE_IMG_EXPLAIN'    => $this->user->lang['ADR_ACP_ZONE_IMG_EXPLAIN'],
            'L_ZONE_ELEMENT'        => $this->user->lang['ADR_ELEMENT'],
            'L_ZONE_ELEMENT_EXPLAIN'=> $this->user->lang['ADR_ACP_ZONE_ELEMENT_EXPLAIN'],
            'L_ZONE_ITEM'           => $this->user->lang['ADR_ACP_ZONE_ITEM'],
            'L_ZONE_ITEM_EXPLAIN'   => $this->user->lang['ADR_ACP_ZONE_ITEM_EXPLAIN'],
            'L_ZONE_DESTINATION1'   => $this->user->lang['ADR_ACP_ZONE_DESTINATION1'],
            'L_ZONE_DESTINATION1_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_DESTINATION1_EXPLAIN'],
            'L_ZONE_DESTINATION1_COST'    => $this->user->lang['ADR_ACP_ZONE_DESTINATION1_COST'],
            'L_ZONE_DESTINATION1_COST_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_DESTINATION1_COST_EXPLAIN'],
            'L_ZONE_DESTINATION2'   => $this->user->lang['ADR_ACP_ZONE_DESTINATION2'],
            'L_ZONE_DESTINATION2_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_DESTINATION2_EXPLAIN'],
            'L_ZONE_DESTINATION2_COST'    => $this->user->lang['ADR_ACP_ZONE_DESTINATION2_COST'],
            'L_ZONE_DESTINATION2_COST_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_DESTINATION2_COST_EXPLAIN'],
            'L_ZONE_RETURN'         => $this->user->lang['ADR_ACP_ZONE_RETURN'],
            'L_ZONE_RETURN_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_RETURN_EXPLAIN'],
            'L_ZONE_RETURN_COST'    => $this->user->lang['ADR_ACP_ZONE_RETURN_COST'],
            'L_ZONE_RETURN_COST_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_RETURN_COST_EXPLAIN'],
            'L_ZONE_TEMPLE'         => $this->user->lang['ADR_TEMPLE'],
            'L_ZONE_TEMPLE_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_TEMPLE_EXPLAIN'],
            'L_ZONE_SHOPS'          => $this->user->lang['ADR_SHOPS'],
            'L_ZONE_SHOPS_EXPLAIN'  => $this->user->lang['ADR_ACP_ZONE_SHOPS_EXPLAIN'],
            'L_ZONE_BANK'           => $this->user->lang['ADR_VAULT'],
            'L_ZONE_BANK_EXPLAIN'   => $this->user->lang['ADR_ACP_ZONE_BANK_EXPLAIN'],
            'L_ZONE_PRISON'         => $this->user->lang['ADR_CELL'],
            'L_ZONE_PRISON_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_PRISON_EXPLAIN'],
            'L_ZONE_FORGE'          => $this->user->lang['ADR_FORGE'],
            'L_ZONE_FORGE_EXPLAIN'  => $this->user->lang['ADR_ACP_ZONE_FORGE_EXPLAIN'],
            'L_ZONE_CHANCE'         => $this->user->lang['ADR_ACP_ZONE_CHANCE'],
            'L_ZONE_CHANCE_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_CHANCE_EXPLAIN'],
            'L_ZONE_POINTWIN1'      => $this->user->lang['ADR_ACP_ZONE_POINTWIN1'],
            'L_ZONE_POINTWIN1_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_POINTWIN1_EXPLAIN'],
            'L_ZONE_POINTWIN2'      => $this->user->lang['ADR_ACP_ZONE_POINTWIN2'],
            'L_ZONE_POINTWIN2_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_POINTWIN2_EXPLAIN'],
            'L_ZONE_POINTLOSS1'     => $this->user->lang['ADR_ACP_ZONE_POINTLOSS1'],
            'L_ZONE_POINTLOSS1_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_POINTLOSS1_EXPLAIN'],
            'L_ZONE_POINTLOSS2'     => $this->user->lang['ADR_ACP_ZONE_POINTLOSS2'],
            'L_ZONE_POINTLOSS2_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_POINTLOSS2_EXPLAIN'],
            'L_ZONE_NPC_COST'       => $this->user->lang['ADR_ACP_ZONE_NPC_COST'],
            'L_ZONE_NPC_COST_EXPLAIN' => $this->user->lang['ADR_ACP_ZONE_NPC_COST_EXPLAIN'],
            'L_SUBMIT'              => $this->user->lang['SUBMIT'],

            'ZONE_NAME'             => $v('zone_name'),
            'ZONE_DESC'             => $v('zone_desc'),
            'ZONE_IMG'              => $v('zone_img'),
            'ZONE_ELEMENT'          => '<select name="zone_element"><option value="">' . $this->user->lang['ADR_ACP_ZONE_CHOOSE_ELEMENT'] . '</option>' . $elem_options . '</select>',
            'ZONE_ITEM'             => '<input type="text" name="zone_item" value="' . $v('zone_item', '0') . '" size="30" maxlength="255" />',
            'ZONE_DESTINATION1'     => '<select name="zone_goto1">' . $dest1_options . '</select>',
            'ZONE_DESTINATION2'     => '<select name="zone_goto2">' . $dest2_options . '</select>',
            'ZONE_RETURN'           => '<select name="zone_return">' . $return_options . '</select>',
            'ZONE_COSTDESTINATION1' => $v('cost_goto1', 0),
            'ZONE_COSTDESTINATION2' => $v('cost_goto2', 0),
            'ZONE_COSTRETURN'       => $v('cost_return', 0),
            'ZONE_TEMPLE'           => $chk('zone_temple'),
            'ZONE_SHOPS'            => $chk('zone_shops'),
            'ZONE_BANK'             => $chk('zone_bank'),
            'ZONE_PRISON'           => $chk('zone_prison'),
            'ZONE_FORGE'            => $chk('zone_forge'),
            'ZONE_CHANCE'           => $v('zone_chance', 10),
            'ZONE_POINTWIN1'        => $v('zone_pointwin1', 0),
            'ZONE_POINTWIN2'        => $v('zone_pointwin2', 0),
            'ZONE_POINTLOSS1'       => $v('zone_pointloss1', 0),
            'ZONE_POINTLOSS2'       => $v('zone_pointloss2', 0),
            'ZONE_EVENT1'           => $chk('zone_event1'),
            'ZONE_EVENT2'           => $chk('zone_event2'),
            'ZONE_EVENT3'           => $chk('zone_event3'),
            'ZONE_EVENT4'           => $chk('zone_event4'),
            'ZONE_EVENT5'           => $chk('zone_event5'),
            'ZONE_EVENT6'           => $chk('zone_event6'),
            'ZONE_EVENT7'           => $chk('zone_event7'),
            'ZONE_EVENT8'           => $chk('zone_event8'),
            'ZONE_NPC1'             => $chk('npc1_enable'),
            'ZONE_NPC2'             => $chk('npc2_enable'),
            'ZONE_NPC3'             => $chk('npc3_enable'),
            'ZONE_NPC4'             => $chk('npc4_enable'),
            'ZONE_NPC5'             => $chk('npc5_enable'),
            'ZONE_COSTNPC'          => $v('npc_price', 0),
            'NPC1_MSG'              => $v('npc1_message'),
            'NPC2_MSG'              => $v('npc2_message'),
            'NPC3_MSG'              => $v('npc3_message'),
            'NPC4_MSG'              => $v('npc4_message'),
            'NPC5_MSG'              => $v('npc5_message'),
            'S_ZONES_ACTION'        => $this->u_action,
            'S_HIDDEN_FIELDS'       => $hidden,
        ]);

        for ($i = 1; $i <= 8; $i++)
        {
            $this->template->assign_vars([
                "L_ZONE_EVENT$i"         => $this->user->lang["ADR_ACP_ZONE_EVENT$i"],
                "L_ZONE_EVENT{$i}_EXPLAIN" => $this->user->lang["ADR_ACP_ZONE_EVENT{$i}_EXPLAIN"],
            ]);
        }
        for ($i = 1; $i <= 5; $i++)
        {
            $this->template->assign_vars([
                "L_ZONE_NPC$i"                 => $this->user->lang["ADR_ACP_ZONE_NPC$i"],
                "L_ZONE_NPC{$i}_EXPLAIN"       => $this->user->lang["ADR_ACP_ZONE_NPC{$i}_EXPLAIN"],
                "L_ZONE_NPC{$i}_MESSAGE"       => $this->user->lang["ADR_ACP_ZONE_NPC{$i}_MESSAGE"],
                "L_ZONE_NPC{$i}_MESSAGE_EXPLAIN" => $this->user->lang["ADR_ACP_ZONE_NPC{$i}_MESSAGE_EXPLAIN"],
            ]);
        }

        $this->template->set_filenames(['body' => '@adr_rpg/adr_acp_zones_edit.html']);
    }

    protected function _save_zone($mode, $zone_id, $zones_table)
    {
        $data = [
            'zone_name'     => $this->request->variable('zone_name', ''),
            'zone_desc'     => $this->request->variable('zone_desc', ''),
            'zone_img'      => $this->request->variable('zone_img', ''),
            'zone_element'  => $this->request->variable('zone_element', ''),
            'zone_item'     => $this->request->variable('zone_item', '0'),
            'goto1_name'    => $this->request->variable('zone_goto1', ''),
            'goto2_name'    => $this->request->variable('zone_goto2', ''),
            'return_name'   => $this->request->variable('zone_return', ''),
            'cost_goto1'    => $this->request->variable('zone_cost1', 0),
            'cost_goto2'    => $this->request->variable('zone_cost2', 0),
            'cost_return'   => $this->request->variable('zone_costreturn', 0),
            'zone_shops'    => $this->request->variable('zone_shops', 0),
            'zone_forge'    => $this->request->variable('zone_forge', 0),
            'zone_temple'   => $this->request->variable('zone_temple', 0),
            'zone_prison'   => $this->request->variable('zone_prison', 0),
            'zone_bank'     => $this->request->variable('zone_bank', 0),
            'zone_chance'   => $this->request->variable('zone_chance', 10),
            'zone_pointwin1'=> $this->request->variable('zone_pointwin1', 0),
            'zone_pointwin2'=> $this->request->variable('zone_pointwin2', 0),
            'zone_pointloss1'=> $this->request->variable('zone_pointloss1', 0),
            'zone_pointloss2'=> $this->request->variable('zone_pointloss2', 0),
            'zone_event1'   => $this->request->variable('zone_event1', 0),
            'zone_event2'   => $this->request->variable('zone_event2', 0),
            'zone_event3'   => $this->request->variable('zone_event3', 0),
            'zone_event4'   => $this->request->variable('zone_event4', 0),
            'zone_event5'   => $this->request->variable('zone_event5', 0),
            'zone_event6'   => $this->request->variable('zone_event6', 0),
            'zone_event7'   => $this->request->variable('zone_event7', 0),
            'zone_event8'   => $this->request->variable('zone_event8', 0),
            'npc1_enable'   => $this->request->variable('zone_npc1', 0),
            'npc2_enable'   => $this->request->variable('zone_npc2', 0),
            'npc3_enable'   => $this->request->variable('zone_npc3', 0),
            'npc4_enable'   => $this->request->variable('zone_npc4', 0),
            'npc5_enable'   => $this->request->variable('zone_npc5', 0),
            'npc_price'     => $this->request->variable('zone_costnpc', 0),
            'npc1_message'  => $this->request->variable('npc1_msg', '', true),
            'npc2_message'  => $this->request->variable('npc2_msg', '', true),
            'npc3_message'  => $this->request->variable('npc3_msg', '', true),
            'npc4_message'  => $this->request->variable('npc4_msg', '', true),
            'npc5_message'  => $this->request->variable('npc5_msg', '', true),
        ];

        if ($mode === 'savenew')
        {
            $sql = 'INSERT INTO ' . $zones_table . ' ' . $this->db->sql_build_array('INSERT', $data);
        }
        else
        {
            $sql = 'UPDATE ' . $zones_table . ' SET ' . $this->db->sql_build_array('UPDATE', $data) . " WHERE zone_id = $zone_id";
        }
        $this->db->sql_query($sql);

        $this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'ADR_LOG_ZONE_SAVED', false, [$data['zone_name']]);
        trigger_error($this->user->lang['ADR_ACP_ZONE_SAVED'] . adm_back_link($this->u_action));
    }

    protected function _delete_zone($zone_id, $zones_table)
    {
        $sql = 'DELETE FROM ' . $zones_table . " WHERE zone_id = $zone_id";
        $this->db->sql_query($sql);
        $this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'ADR_LOG_ZONE_DELETED');
        trigger_error($this->user->lang['ADR_ACP_ZONE_DELETED'] . adm_back_link($this->u_action));
    }
}
