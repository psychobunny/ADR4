<?php
namespace adr\rpg\controller;

class shops
{
	protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

	public function __construct(
		\phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
		\phpbb\user $user, \phpbb\template\template $template,
		\phpbb\controller\helper $helper, \phpbb\request\request $request,
		\phpbb\auth\auth $auth, $root_path, $php_ext,
		\adr\rpg\service\manager $manager
	) {
		$this->config = $config; $this->db = $db; $this->user = $user;
		$this->template = $template; $this->helper = $helper;
		$this->request = $request; $this->auth = $auth;
		$this->root_path = $root_path; $this->php_ext = $php_ext;
		$this->manager = $manager;
	}

	public function index()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}

		$user_id = (int) $this->user->data['user_id'];

		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}

		if ($this->manager->is_in_jail($user_id))
		{
			redirect($this->helper->route('adr_rpg_cell'));
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_shop_enable'])
		{
			trigger_error($this->user->lang('ADR_SHOP_DISABLED'));
		}

		$mode      = $this->request->variable('mode', 'general');
		$character = $this->manager->get_user_character($user_id);

		// Blackmarket purchase (user listed items).
		if ($mode === 'blackmarket_buy' && $this->request->is_set_post('buy_blackmarket'))
		{
			$item_id = $this->request->variable('item_id', 0);
			$result  = $this->manager->buy_item_from_user_shop($user_id, $item_id);

			if (!$result['success'])
			{
				$this->template->assign_var('BUY_ERROR', $this->user->lang($result['error'] ?? 'GENERAL_ERROR'));
			}
			else
			{
				$this->template->assign_var('BUY_SUCCESS', true);
				$character = $this->manager->get_user_character($user_id);
			}

			// After processing, render the blackmarket listing page.
			$mode = 'blackmarket';
		}

		if ($mode === 'buy' && $this->request->is_set_post('buy'))
		{
			$item_id  = $this->request->variable('item_id', 0);
			$store_id = $this->request->variable('store_id', 0);
			$result   = $this->manager->buy_item_from_store($user_id, $item_id, $store_id);

			if (!$result['success'])
			{
				$this->template->assign_var('BUY_ERROR', $this->user->lang($result['error'] ?? 'GENERAL_ERROR'));
			}
			else
			{
				$this->template->assign_var('BUY_SUCCESS', true);
				$character = $this->manager->get_user_character($user_id);
			}
		}

		if ($mode === 'thief' && $this->config['adr_thief_enable'])
		{
			$this->handle_theft($user_id, $character);
			$character = $this->manager->get_user_character($user_id);
		}

		$stores = [];
		$store_items = [];
		$view_store = 0;

		$blackmarket_items = [];
		$blackmarket_sellers = [];

		if ($mode === 'blackmarket')
		{
			$seller_id = (int) $this->request->variable('seller_id', 0);

			// Sellers list (distinct owners with items for sale).
			$sql = 'SELECT DISTINCT i.item_owner_id, u.username AS seller_name, u.user_colour AS seller_colour
					FROM ' . $this->manager->get_table('shops_items') . ' i
					LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = i.item_owner_id
					WHERE i.item_in_shop = 1
						AND i.item_in_warehouse = 0
						AND (i.item_duration > 0 OR i.item_duration_max = -1)
						AND i.item_owner_id <> ' . $user_id . '
					' . ($seller_id ? ' AND i.item_owner_id = ' . $seller_id : '') . '
					ORDER BY u.username ASC';
			$result = $this->db->sql_query($sql);
			$blackmarket_sellers = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			// Items for sale from other players.
			$sql = 'SELECT i.*, t.item_type_lang, q.item_quality_lang, q.item_quality_modifier_price,
						u.username AS owner_name
					FROM ' . $this->manager->get_table('shops_items') . ' i
					LEFT JOIN ' . $this->manager->get_table('shops_items_type') . ' t ON t.item_type_id = i.item_type
					LEFT JOIN ' . $this->manager->get_table('shops_items_quality') . ' q ON q.item_quality_id = i.item_quality
					LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = i.item_owner_id
					WHERE i.item_in_shop = 1
						AND i.item_in_warehouse = 0
						AND i.item_equipped = 0
						AND (i.item_duration > 0 OR i.item_duration_max = -1)
						AND i.item_owner_id <> ' . $user_id . '
					' . ($seller_id ? ' AND i.item_owner_id = ' . $seller_id : '') . '
					ORDER BY i.item_type ASC, i.item_id ASC';
			$result = $this->db->sql_query($sql);
			$blackmarket_items = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			foreach ($blackmarket_items as &$item)
			{
				$item['item_final_price'] = (int) ($item['item_price'] * ($item['item_quality_modifier_price'] / 100));
			}
		}
		else
		{
			$stores = $this->manager->get_stores();

			$view_store = $this->request->variable('store_id', 0);
			if ($view_store)
			{
				$char_restrict = $this->build_restrict_sql($character);

				$sql = 'SELECT i.*, t.item_type_lang, q.item_quality_lang, q.item_quality_modifier_price,
							u.username AS owner_name
						FROM ' . $this->manager->get_table('shops_items') . ' i
						LEFT JOIN ' . $this->manager->get_table('shops_items_type') . ' t ON t.item_type_id = i.item_type
						LEFT JOIN ' . $this->manager->get_table('shops_items_quality') . ' q ON q.item_quality_id = i.item_quality
						LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = i.item_owner_id
						WHERE i.item_in_shop = 1
							AND i.item_in_warehouse = 0
							AND (i.item_duration > 0 OR i.item_duration_max = -1)
						' . $char_restrict . '
						ORDER BY i.item_type ASC, i.item_id ASC';
				$result = $this->db->sql_query($sql);
				$store_items = $this->db->sql_fetchrowset($result);
				$this->db->sql_freeresult($result);

				foreach ($store_items as &$item)
				{
					$item['item_final_price'] = (int) ($item['item_price'] * ($item['item_quality_modifier_price'] / 100));
				}
			}
		}

		$player_shop_items = $this->manager->get_user_items($user_id, 1);

		$this->template->assign_vars([
			'CHARACTER'         => $character,
			'STORES'            => $stores,
			'STORE_ITEMS'       => $store_items,
			'PLAYER_SHOP_ITEMS' => $player_shop_items,
			'VIEW_STORE'        => $view_store,
			'MODE'              => $mode,
			'THIEF_ENABLE'      => (bool) $this->config['adr_thief_enable'],
			'U_ACTION'          => $this->helper->route('adr_rpg_shops'),
			'U_BLACKMARKET'     => $this->helper->route('adr_rpg_shops') . '?mode=blackmarket',
			'BLACKMARKET_ITEMS' => array_values($blackmarket_items),
			'BLACKMARKET_SELLERS' => array_values($blackmarket_sellers),
		]);

		return $this->helper->render('@adr_rpg/adr_shops.html', $this->user->lang('ADR_SHOPS'));
	}

	protected function build_restrict_sql($char)
	{
		return " AND (item_restrict_class LIKE '%" . $this->db->sql_escape($char['character_class']) . ",%' OR item_restrict_class_enable = 0)
			AND (item_restrict_race LIKE '%" . $this->db->sql_escape($char['character_race']) . ",%' OR item_restrict_race_enable = 0)
			AND (item_restrict_align LIKE '%" . $this->db->sql_escape($char['character_alignment']) . ",%' OR item_restrict_align_enable = 0)
			AND (item_restrict_element LIKE '%" . $this->db->sql_escape($char['character_element']) . ",%' OR item_restrict_element_enable = 0)
			AND item_restrict_level <= " . (int) $char['character_level'] . "
			AND item_restrict_str <= " . (int) $char['character_might'] . "
			AND item_restrict_dex <= " . (int) $char['character_dexterity'] . "
			AND item_restrict_con <= " . (int) $char['character_constitution'] . "
			AND item_restrict_int <= " . (int) $char['character_intelligence'] . "
			AND item_restrict_wis <= " . (int) $char['character_wisdom'] . "
			AND item_restrict_cha <= " . (int) $char['character_charisma'];
	}

	protected function handle_theft($user_id, $character)
	{
		$target_user_id = $this->request->variable('target_id', 0);
		$item_id        = $this->request->variable('item_id', 0);

		if (!$target_user_id || !$item_id || !$this->manager->character_exists($target_user_id))
		{
			return;
		}

		$sql = 'SELECT cl.class_thief_class FROM ' . $this->manager->get_table('characters') . ' c
				JOIN ' . $this->manager->get_table('classes') . ' cl ON cl.class_id = c.character_class
				WHERE c.character_id = ' . $user_id;
		$result = $this->db->sql_query($sql);
		$class_row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$class_row || !$class_row['class_thief_class'])
		{
			$this->template->assign_var('THIEF_ERROR', $this->user->lang('ADR_THIEF_NOT_THIEF'));
			return;
		}

		$thief_skill = (int) $character['character_skill_thief'];
		$chance      = min(80, 10 + $thief_skill * 5);

		$sql = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $item_id . '
				AND item_owner_id = ' . $target_user_id . '
				AND item_in_shop = 0
				AND item_equipped = 0';
		$result = $this->db->sql_query($sql);
		$item   = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$item)
		{
			return;
		}

		if (rand(1, 100) <= $chance)
		{
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
				SET item_owner_id = ' . $user_id . '
				WHERE item_id = ' . $item_id);

			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET character_weight = character_weight - ' . (int) $item['item_weight'] . '
				WHERE character_id = ' . $target_user_id);

			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET character_weight = character_weight + ' . (int) $item['item_weight'] . '
				WHERE character_id = ' . $user_id);

			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET character_skill_thief = character_skill_thief + 1
				WHERE character_id = ' . $user_id);

			$this->template->assign_var('THIEF_SUCCESS', true);
		}
		else
		{
			$penalty = (int) $this->config['adr_thief_points'];
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET character_gold = character_gold - ' . $penalty . '
				WHERE character_id = ' . $user_id);
			$this->template->assign_var('THIEF_CAUGHT', true);
			$this->template->assign_var('THIEF_PENALTY', $penalty);
		}
	}
}
