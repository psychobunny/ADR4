<?php
namespace adr\rpg\controller;

class forge
{
	protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

	public function __construct(
		\phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
		\phpbb\user $user, \phpbb\template\template $template,
		\phpbb\controller\helper $helper, \phpbb\request\request $request,
		\phpbb\auth\auth $auth, $root_path, $php_ext,
		\adr\rpg\service\manager $manager
	) {
		$this->config = $config; $this->db = $db; $this->user = $user;
		$this->template = $template; $this->helper = $helper;
		$this->request = $request; $this->auth = $auth;
		$this->root_path = $root_path; $this->php_ext = $php_ext;
		$this->manager = $manager;
	}

	public function index()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}

		$user_id = (int) $this->user->data['user_id'];
		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_forge_enable'])
		{
			trigger_error($this->user->lang('ADR_FORGE_DISABLED'));
		}

		$character = $this->manager->get_user_character($user_id);
		$error     = '';
		$success   = '';

		if ($this->request->is_set_post('forge_item'))
		{
			$material_item_id = $this->request->variable('material_item_id', 0);
			$item_type_id     = $this->request->variable('item_type_id', 0);
			$result           = $this->forge_item($user_id, $character, $material_item_id, $item_type_id);

			if ($result['success'])
			{
				$success   = $this->user->lang('ADR_FORGE_SUCCESS');
				$character = $this->manager->get_user_character($user_id);
			}
			else
			{
				$error = $this->user->lang($result['error'] ?? 'GENERAL_ERROR');
			}
		}

		if ($this->request->is_set_post('enchant_item'))
		{
			$target_item_id   = $this->request->variable('target_item_id', 0);
			$material_item_id = $this->request->variable('enchant_material_id', 0);
			$result           = $this->enchant_item($user_id, $character, $target_item_id, $material_item_id);

			if ($result['success'])
			{
				$success = $this->user->lang('ADR_ENCHANT_SUCCESS');
			}
			else
			{
				$error = $this->user->lang($result['error'] ?? 'GENERAL_ERROR');
			}
		}

		if ($this->request->is_set_post('mine_item'))
		{
			$pickaxe_item_id = $this->request->variable('pickaxe_item_id', 0);
			$result          = $this->mine_item($user_id, $character, $pickaxe_item_id);

			if ($result['success'])
			{
				$success   = $this->user->lang('ADR_FORGE_MINING_SUCCESS');
				$character = $this->manager->get_user_character($user_id);
			}
			else
			{
				$error = $this->user->lang($result['error'] ?? 'GENERAL_ERROR');
			}
		}

		$items      = $this->manager->get_user_items($user_id);
		$item_types = $this->manager->get_item_types();
		$qualities  = $this->manager->get_item_qualities();

		$forge_items   = array_filter($items, fn($i) => $i['item_forge_material'] > 0);
		$enchant_items = array_filter($items, fn($i) => $i['item_forge_material'] > 0);
		$pickaxes      = array_filter(
			$items,
			fn($i) => ((int) $i['item_type'] === 3) && ((int) $i['item_duration'] > 0 || (int) $i['item_duration_max'] === -1)
		);

		$this->template->assign_vars([
			'CHARACTER'   => $character,
			'ITEMS'       => $items,
			'FORGE_ITEMS' => array_values($forge_items),
			'PICKAXES'    => array_values($pickaxes),
			'ITEM_TYPES'  => $item_types,
			'QUALITIES'   => $qualities,
			'ERROR'       => $error,
			'SUCCESS'     => $success,
			'U_ACTION'    => $this->helper->route('adr_rpg_forge'),
		]);

		return $this->helper->render('@adr_rpg/adr_forge.html', $this->user->lang('ADR_FORGE'));
	}

	protected function mine_item($user_id, $character, $pickaxe_item_id)
	{
		$user_id = (int) $user_id;
		$pickaxe_item_id = (int) $pickaxe_item_id;

		if ($pickaxe_item_id <= 0)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_MINING_NO_TOOL'];
		}

		$sql = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $pickaxe_item_id . '
					AND item_owner_id = ' . $user_id . '
					AND item_in_shop = 0
					AND item_in_warehouse = 0
					AND item_type = 3';
		$result = $this->db->sql_query($sql);
		$tool   = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$tool)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_MINING_NO_TOOL'];
		}

		// In this codebase, -1 durations represent "infinite/permanent".
		if ((int) $tool['item_duration_max'] !== -1 && (int) $tool['item_duration'] <= 0)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_MINING_BROKEN'];
		}

		$mining_skill   = (int) $character['character_skill_mining'];
		$element_bonus  = (int) $character['element_skill_mining_bonus'];
		$skill_chance   = 5;

		$skill_sql = 'SELECT skill_chance FROM ' . $this->manager->get_table('skills') . ' WHERE skill_id = 1';
		$skill_res = $this->db->sql_query($skill_sql);
		$skill_row = $this->db->sql_fetchrow($skill_res);
		$this->db->sql_freeresult($skill_res);
		if ($skill_row && isset($skill_row['skill_chance']))
		{
			$skill_chance = (int) $skill_row['skill_chance'];
		}

		$chance = ($mining_skill * $skill_chance) + $element_bonus;
		$chance = min(90, max(0, (int) $chance));

		$success = ((int) rand(1, 100) <= $chance);

		// Consume tool durability immediately (legacy consumes the tool/energy regardless of success).
		if ((int) $tool['item_duration_max'] !== -1 && (int) $tool['item_duration'] > 0)
		{
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
				SET item_duration = item_duration - 1
				WHERE item_id = ' . $pickaxe_item_id . '
					AND item_owner_id = ' . $user_id . '
					AND item_duration > 0');

			$this->db->sql_query('DELETE FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $pickaxe_item_id . '
					AND item_owner_id = ' . $user_id . '
					AND item_duration <= 0');
		}

		if (!$success)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_MINING_FAILED'];
		}

		$tool_quality = (int) $tool['item_quality'];
		$tool_power   = (int) $tool['item_power'];

		$modif = ($tool_quality > 3) ? ($tool_quality - 3) : 0;
		$modif += max(0, ($tool_power - 1));

		// Legacy does `rand($modif, 10)`; clamp to safe range.
		if ($modif > 10)
		{
			$happiness = (int) rand(10, $modif);
		}
		else
		{
			$happiness = (int) rand($modif, 10);
		}

		$new_item_type = ($happiness > 8) ? 2 : 1; // 1=ore, 2=diamond

		$item_quality = rand(1, 6);
		$item_duration = rand(1, 3);
		$item_power = rand(1, 3);

		if ($new_item_type === 1)
		{
			$item_name = 'ADR_ITEM_ORE';
			$item_desc = 'ADR_ITEM_ORE_DESC';
			$item_icon = 'ore.gif';
		}
		else
		{
			$item_name = 'ADR_ITEMS_DIAMOND';
			$item_desc = 'ADR_ITEMS_DIAMOND_DESC';
			$item_icon = 'diamond.gif';
		}

		$item_type_sql = 'SELECT item_type_base_price FROM ' . $this->manager->get_table('shops_items_type') . ' WHERE item_type_id = ' . (int) $new_item_type;
		$item_type_res = $this->db->sql_query($item_type_sql);
		$item_type_row = $this->db->sql_fetchrow($item_type_res);
		$this->db->sql_freeresult($item_type_res);
		$item_price = $item_type_row ? (int) $item_type_row['item_type_base_price'] : 0;

		$new_item = [
			'item_owner_id' => $user_id,
			'item_price' => $item_price,
			'item_quality' => $item_quality,
			'item_power' => $item_power,
			'item_duration' => $item_duration,
			'item_duration_max' => $item_duration,
			'item_icon' => $item_icon,
			'item_name' => $item_name,
			'item_desc' => $item_desc,
			'item_type' => $new_item_type,
			'item_ac' => 0,
			'item_in_shop' => 0,
			'item_in_warehouse' => 0,
			'item_equipped' => 0,
			'item_equip_slot' => '',
			'item_weight' => 25,
			'item_restrict_class' => '0-',
			'item_restrict_class_enable' => 0,
			'item_restrict_race' => '0-',
			'item_restrict_race_enable' => 0,
			'item_restrict_align' => '0-',
			'item_restrict_align_enable' => 0,
			'item_restrict_element' => '0-',
			'item_restrict_element_enable' => 0,
			'item_restrict_level' => 0,
			'item_restrict_str' => 0,
			'item_restrict_dex' => 0,
			'item_restrict_con' => 0,
			'item_restrict_int' => 0,
			'item_restrict_wis' => 0,
			'item_restrict_cha' => 0,
			'item_forge_material' => 0,
			'item_forge_level' => 0,
		];

		$this->db->sql_query('INSERT INTO ' . $this->manager->get_table('shops_items') . ' ' .
			$this->db->sql_build_array('INSERT', $new_item));

		// Track successful mining uses/level.
		$this->manager->increment_skill($user_id, 1);

		return ['success' => true];
	}

	protected function forge_item($user_id, $character, $material_id, $item_type_id)
	{
		$user_id      = (int) $user_id;
		$material_id  = (int) $material_id;
		$item_type_id = (int) $item_type_id;

		$forge_skill = (int) $character['character_skill_forge'];

		$sql = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $material_id . '
				AND item_owner_id = ' . $user_id . '
				AND item_forge_material > 0
				AND item_in_shop = 0
				AND item_equipped = 0';
		$result   = $this->db->sql_query($sql);
		$material = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$material)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_NO_MATERIAL'];
		}

		$required_level = (int) $material['item_forge_level'];
		if ($forge_skill < $required_level)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_SKILL_LOW'];
		}

		$sql = 'SELECT * FROM ' . $this->manager->get_table('shops_items_type') . ' WHERE item_type_id = ' . $item_type_id;
		$result    = $this->db->sql_query($sql);
		$item_type = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$item_type)
		{
			return ['success' => false, 'error' => 'ADR_FORGE_INVALID_TYPE'];
		}

		$element_bonus = (int) $character['element_skill_forge_bonus'];
		$chance = min(90, 20 + $forge_skill * 5 + $element_bonus);

		if (rand(1, 100) <= $chance)
		{
			$this->db->sql_query('DELETE FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $material_id);

			$base_power = (int) $material['item_forge_material'];
			$new_item   = [
				'item_owner_id'    => $user_id,
				'item_price'       => (int) $item_type['item_type_base_price'],
				'item_quality'     => 2,
				'item_power'       => $base_power,
				'item_duration'    => -1,
				'item_duration_max'=> -1,
				'item_icon'        => '',
				'item_name'        => $item_type['item_type_lang'],
				'item_desc'        => 'Forged item',
				'item_type'        => $item_type_id,
				'item_ac'          => (int) floor($base_power / 5),
				'item_in_shop'     => 0,
				'item_in_warehouse'=> 0,
				'item_equipped'    => 0,
				'item_equip_slot'  => '',
				'item_weight'      => max(1, (int) floor($base_power / 10)),
				'item_restrict_class'         => '',
				'item_restrict_class_enable'  => 0,
				'item_restrict_race'          => '',
				'item_restrict_race_enable'   => 0,
				'item_restrict_align'         => '',
				'item_restrict_align_enable'  => 0,
				'item_restrict_element'       => '',
				'item_restrict_element_enable'=> 0,
				'item_restrict_level'   => 0,
				'item_restrict_str'     => 0,
				'item_restrict_dex'     => 0,
				'item_restrict_con'     => 0,
				'item_restrict_int'     => 0,
				'item_restrict_wis'     => 0,
				'item_restrict_cha'     => 0,
				'item_forge_material'   => 0,
				'item_forge_level'      => 0,
			];

			$this->db->sql_query('INSERT INTO ' . $this->manager->get_table('shops_items') . ' ' .
				$this->db->sql_build_array('INSERT', $new_item));
			
			// Track successful forge uses (skills now level up via *_uses thresholds).
			$this->manager->increment_skill($user_id, 3);

			return ['success' => true];
		}

		$this->db->sql_query('DELETE FROM ' . $this->manager->get_table('shops_items') . '
			WHERE item_id = ' . $material_id);

		return ['success' => false, 'error' => 'ADR_FORGE_FAILED'];
	}

	protected function enchant_item($user_id, $character, $target_id, $material_id)
	{
		$user_id    = (int) $user_id;
		$target_id  = (int) $target_id;
		$material_id = (int) $material_id;

		$enchant_skill = (int) $character['character_skill_enchantment'];

		$sql_target = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
			WHERE item_id = ' . $target_id . ' AND item_owner_id = ' . $user_id . ' AND item_forge_material = 0';
		$result = $this->db->sql_query($sql_target);
		$target = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$sql_mat = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
			WHERE item_id = ' . $material_id . ' AND item_owner_id = ' . $user_id . ' AND item_forge_material > 0';
		$result   = $this->db->sql_query($sql_mat);
		$material = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$target || !$material)
		{
			return ['success' => false, 'error' => 'ADR_ENCHANT_INVALID_ITEMS'];
		}

		$element_bonus = (int) $character['element_skill_enchant_bonus'];
		$chance = min(90, 15 + $enchant_skill * 4 + $element_bonus);

		if (rand(1, 100) <= $chance)
		{
			$power_bonus = (int) $material['item_forge_material'];

			$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
				SET item_power = item_power + ' . $power_bonus . ',
					item_quality = LEAST(item_quality + 1, 5)
				WHERE item_id = ' . $target_id);

			$this->db->sql_query('DELETE FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $material_id);
			
			// Track successful enchantment uses (skills now level up via *_uses thresholds).
			$this->manager->increment_skill($user_id, 4);

			return ['success' => true];
		}

		$this->db->sql_query('DELETE FROM ' . $this->manager->get_table('shops_items') . '
			WHERE item_id = ' . $material_id);

		return ['success' => false, 'error' => 'ADR_ENCHANT_FAILED'];
	}
}
