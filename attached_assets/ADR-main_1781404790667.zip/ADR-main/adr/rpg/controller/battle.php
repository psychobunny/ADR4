<?php
namespace adr\rpg\controller;

class battle
{
	protected $config;
	protected $db;
	protected $user;
	protected $template;
	protected $helper;
	protected $request;
	protected $auth;
	protected $root_path;
	protected $php_ext;
	protected $manager;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\user $user,
		\phpbb\template\template $template,
		\phpbb\controller\helper $helper,
		\phpbb\request\request $request,
		\phpbb\auth\auth $auth,
		$root_path,
		$php_ext,
		\adr\rpg\service\manager $manager
	)
	{
		$this->config    = $config;
		$this->db        = $db;
		$this->user      = $user;
		$this->template  = $template;
		$this->helper    = $helper;
		$this->request   = $request;
		$this->auth      = $auth;
		$this->root_path = $root_path;
		$this->php_ext   = $php_ext;
		$this->manager   = $manager;
	}

	protected function require_login_and_character()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}
		$user_id = (int) $this->user->data['user_id'];
		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}
		if ($this->manager->is_character_banned($user_id))
		{
			trigger_error($this->user->lang('ADR_BANNED'));
		}
		if ($this->manager->is_in_jail($user_id))
		{
			trigger_error($this->user->lang('ADR_IN_JAIL'));
		}
	}

	public function index()
	{
		$this->require_login_and_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_battle_enable'])
		{
			trigger_error($this->user->lang('ADR_BATTLE_DISABLED'));
		}

		$user_id   = (int) $this->user->data['user_id'];
		$character = $this->manager->get_user_character($user_id);
		$mode      = $this->request->variable('mode', '');

		$current_battle = $this->manager->get_current_battle($user_id);

		if ($mode === 'equip')
		{
			$monster_id = $this->request->variable('monster_id', 0);
			$sql = 'SELECT * FROM ' . $this->manager->get_table('battle_monsters') . ' WHERE monster_id = ' . (int) $monster_id;
			$result = $this->db->sql_query($sql);
			$monster = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if (!$monster)
			{
				trigger_error($this->user->lang('ADR_BATTLE_INVALID_MONSTER'));
			}

			// Get user unequipped inventory items
			$items = $this->manager->get_user_items($user_id, 0, 0);

			$helms    = array_filter($items, fn($i) => (int) $i['item_type'] === 9);
			$armors   = array_filter($items, fn($i) => (int) $i['item_type'] === 7);
			$gloves   = array_filter($items, fn($i) => (int) $i['item_type'] === 10);
			$bucklers = array_filter($items, fn($i) => (int) $i['item_type'] === 8);
			$amulets  = array_filter($items, fn($i) => (int) $i['item_type'] === 13);
			$rings    = array_filter($items, fn($i) => (int) $i['item_type'] === 14);

			$this->template->assign_vars([
				'CHARACTER'  => $character,
				'MONSTER'    => $monster,
				'MODE'       => 'equip',
				'HELMS'      => array_values($helms),
				'ARMORS'     => array_values($armors),
				'GLOVES'     => array_values($gloves),
				'BUCKLERS'   => array_values($bucklers),
				'AMULETS'    => array_values($amulets),
				'RINGS'      => array_values($rings),
				'U_ACTION'   => $this->helper->route('adr_rpg_battle') . '?mode=start',
			]);

			return $this->helper->render('@adr_rpg/adr_battle.html', $this->user->lang('ADR_BATTLE'));
		}

		if ($mode === 'start' && $this->request->is_set_post('monster_id'))
		{
			$monster_id = $this->request->variable('monster_id', 0);
			$equip_info = [
				'helm_id'    => $this->request->variable('item_helm', 0),
				'armor_id'   => $this->request->variable('item_armor', 0),
				'gloves_id'  => $this->request->variable('item_gloves', 0),
				'buckler_id' => $this->request->variable('item_buckler', 0),
				'amulet_id'  => $this->request->variable('item_amulet', 0),
				'ring_id'    => $this->request->variable('item_ring', 0),
			];

			$result = $this->manager->start_monster_battle($user_id, $monster_id, $equip_info);
			if ($result['success'])
			{
				redirect($this->helper->route('adr_rpg_battle') . '?mode=fight&battle_id=' . $result['battle_id']);
			}
			$this->template->assign_var('ERROR', $this->user->lang($result['error'] ?? 'GENERAL_ERROR'));
		}

		if ($mode === 'fight')
		{
			$battle_id = $this->request->variable('battle_id', 0);
			$action    = $this->request->variable('action', 'attack');

			if ($this->request->is_set_post('do_turn') && $battle_id)
			{
				$item_weapon = $this->request->variable('item_weapon', 0);
				$item_spell  = $this->request->variable('item_spell', 0);
				$item_potion = $this->request->variable('item_potion', 0);

				$turn_result = $this->manager->do_battle_turn($battle_id, $user_id, $action, $item_weapon, $item_spell, $item_potion);
				$this->template->assign_vars([
					'BATTLE_RESULT'  => $turn_result,
					'BATTLE_FINISHED'=> $turn_result['finished'] ?? false,
				]);
			}

			$battle_sql = 'SELECT b.*, m.monster_name, m.monster_img, m.monster_level
							FROM ' . $this->manager->get_table('battle_list') . ' b
							JOIN ' . $this->manager->get_table('battle_monsters') . ' m ON m.monster_id = b.battle_monster_id
							WHERE b.battle_id = ' . (int) $battle_id . '
							AND b.battle_challenger_id = ' . $user_id;
			$result = $this->db->sql_query($battle_sql);
			$battle = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			// Populate dynamic dropdown options for active item selectors
			$items = $this->manager->get_user_items($user_id, 0, 0);
			$weapons = array_filter($items, fn($i) => in_array((int) $i['item_type'], [5, 6], true));
			$potions = array_filter($items, fn($i) => in_array((int) $i['item_type'], [15, 16], true));
			$spells  = array_filter($items, fn($i) => in_array((int) $i['item_type'], [11, 12], true));

			$this->template->assign_vars([
				'BATTLE'     => $battle,
				'CHARACTER'  => $this->manager->get_user_character($user_id),
				'MODE'       => 'fight',
				'WEAPONS'    => array_values($weapons),
				'POTIONS'    => array_values($potions),
				'SPELLS'     => array_values($spells),
				'U_ACTION'   => $this->helper->route('adr_rpg_battle') . '?mode=fight&battle_id=' . (int) $battle_id,
			]);

			return $this->helper->render('@adr_rpg/adr_battle.html', $this->user->lang('ADR_BATTLE'));
		}

		if ($mode === 'history')
		{
			$sql = 'SELECT b.*, m.monster_name, m.monster_img
					FROM ' . $this->manager->get_table('battle_list') . ' b
					LEFT JOIN ' . $this->manager->get_table('battle_monsters') . ' m ON m.monster_id = b.battle_monster_id
					WHERE b.battle_challenger_id = ' . $user_id . '
					AND b.battle_result != 0
					ORDER BY b.battle_id DESC';
			$result = $this->db->sql_query_limit($sql, 20);
			$history = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			$this->template->assign_vars([
				'BATTLE_HISTORY' => $history,
				'MODE'           => 'history',
			]);

			return $this->helper->render('@adr_rpg/adr_battle.html', $this->user->lang('ADR_BATTLE_HISTORY'));
		}

		$monsters = $this->manager->get_available_monsters($character['character_level']);

		$this->template->assign_vars([
			'CHARACTER'      => $character,
			'MONSTERS'       => $monsters,
			'CURRENT_BATTLE' => $current_battle,
			'MODE'           => 'select',
			'U_ACTION'       => $this->helper->route('adr_rpg_battle') . '?mode=equip',
			'U_HISTORY'      => $this->helper->route('adr_rpg_battle') . '?mode=history',
			'U_PVP'          => $this->helper->route('adr_rpg_battle_pvp'),
		]);

		return $this->helper->render('@adr_rpg/adr_battle.html', $this->user->lang('ADR_BATTLE'));
	}

	public function pvp()
	{
		$this->require_login_and_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_pvp_enable'])
		{
			trigger_error($this->user->lang('ADR_PVP_DISABLED'));
		}

		$user_id = (int) $this->user->data['user_id'];

		if ($this->request->is_set_post('challenge') || $this->request->variable('challenge', 0))
		{
			$challenged_id = $this->request->variable('challenge', 0);
			if (!$challenged_id)
			{
				$challenged_id = $this->request->variable('challenged_id', 0);
			}

			if ($challenged_id && $this->request->is_set_post('confirm'))
			{
				$result = $this->manager->challenge_pvp($user_id, $challenged_id);
				if ($result['success'])
				{
					$winner_name = ($result['winner'] === $user_id) ?
						$this->user->lang('ADR_YOU') :
						$this->user->lang('ADR_OPPONENT');
					$this->template->assign_var('PVP_WINNER', $winner_name);
					$this->template->assign_var('PVP_RESULT', $result);
				}
				else
				{
					$this->template->assign_var('ERROR', $this->user->lang($result['error'] ?? 'GENERAL_ERROR'));
				}
			}
			else if ($challenged_id)
			{
				$challenged_char = $this->manager->get_user_character($challenged_id);
				$sql = 'SELECT username FROM ' . USERS_TABLE . ' WHERE user_id = ' . $challenged_id;
				$r   = $this->db->sql_query($sql);
				$challenged_user = $this->db->sql_fetchrow($r);
				$this->db->sql_freeresult($r);

				$this->template->assign_vars([
					'CHALLENGED_CHARACTER' => $challenged_char,
					'CHALLENGED_USERNAME'  => $challenged_user['username'] ?? '',
					'CHALLENGED_ID'        => $challenged_id,
					'MODE'                 => 'confirm',
					'U_ACTION'             => $this->helper->route('adr_rpg_battle_pvp'),
				]);

				return $this->helper->render('@adr_rpg/adr_battle_pvp.html', $this->user->lang('ADR_PVP'));
			}
		}

		$battles   = $this->manager->get_pvp_challenges_for_user($user_id);
		$character = $this->manager->get_user_character($user_id);

		$this->template->assign_vars([
			'CHARACTER'   => $character,
			'PVP_BATTLES' => $battles,
			'MODE'        => 'list',
			'U_ACTION'    => $this->helper->route('adr_rpg_battle_pvp'),
		]);

		return $this->helper->render('@adr_rpg/adr_battle_pvp.html', $this->user->lang('ADR_PVP'));
	}

	public function community()
	{
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id = (int) $this->user->data['user_id'];

		if ($this->user->data['is_registered'] && $this->request->is_set_post('post_chat'))
		{
			$message = $this->request->variable('chat_message', '', true);
			if (!empty(trim($message)))
			{
				$chat_data = [
					'chat_posts' => $user_id,
					'chat_text'  => $message,
					'chat_date'  => time(),
				];
				$this->db->sql_query('INSERT INTO ' . $this->manager->get_table('battle_community') . ' ' .
					$this->db->sql_build_array('INSERT', $chat_data));
			}
		}

		$sql = 'SELECT c.*, u.username, u.user_colour
				FROM ' . $this->manager->get_table('battle_community') . ' c
				LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = c.chat_posts
				ORDER BY c.chat_id DESC';
		$result = $this->db->sql_query_limit($sql, 30);
		$posts  = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$this->template->assign_vars([
			'CHAT_POSTS'  => array_reverse($posts),
			'CAN_POST'    => $this->user->data['is_registered'],
			'U_ACTION'    => $this->helper->route('adr_rpg_battle_community'),
		]);

		return $this->helper->render('@adr_rpg/adr_battle_community.html', $this->user->lang('ADR_BATTLE_COMMUNITY'));
	}
}
