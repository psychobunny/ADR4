<?php
namespace adr\rpg\controller;

class temple
{
	protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

	public function __construct(
		\phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
		\phpbb\user $user, \phpbb\template\template $template,
		\phpbb\controller\helper $helper, \phpbb\request\request $request,
		\phpbb\auth\auth $auth, $root_path, $php_ext,
		\adr\rpg\service\manager $manager
	) {
		$this->config = $config; $this->db = $db; $this->user = $user;
		$this->template = $template; $this->helper = $helper;
		$this->request = $request; $this->auth = $auth;
		$this->root_path = $root_path; $this->php_ext = $php_ext;
		$this->manager = $manager;
	}

	public function index()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}

		$user_id = (int) $this->user->data['user_id'];
		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_temple_enable'])
		{
			trigger_error($this->user->lang('ADR_TEMPLE_DISABLED'));
		}

		$character = $this->manager->get_user_character($user_id);
		$mode      = $this->request->variable('mode', '');
		$error     = '';
		$success   = '';

		$cost_per_hp = 2;
		$cost_per_mp = 3;

		if ($mode === 'heal_hp' && $this->request->is_set_post('submit'))
		{
			$result = $this->manager->heal_character($user_id, $cost_per_hp);
			if ($result['success'])
			{
				$success   = $this->user->lang('ADR_TEMPLE_HEAL_OK', $result['hp_restored'], $result['cost']);
				$character = $this->manager->get_user_character($user_id);
			}
			else
			{
				$error = $this->user->lang($result['error'] ?? 'GENERAL_ERROR');
			}
		}

		if ($mode === 'restore_mp' && $this->request->is_set_post('submit'))
		{
			$result = $this->manager->restore_mp($user_id, $cost_per_mp);
			if ($result['success'])
			{
				$success   = $this->user->lang('ADR_TEMPLE_MP_OK', $result['mp_restored'], $result['cost']);
				$character = $this->manager->get_user_character($user_id);
			}
			else
			{
				$error = $this->user->lang($result['error'] ?? 'GENERAL_ERROR');
			}
		}

		$hp_cost = ($character['character_hp_max'] - $character['character_hp']) * $cost_per_hp;
		$mp_cost = ($character['character_mp_max'] - $character['character_mp']) * $cost_per_mp;

		$this->template->assign_vars([
			'CHARACTER'  => $character,
			'HP_COST'    => max(0, $hp_cost),
			'MP_COST'    => max(0, $mp_cost),
			'ERROR'      => $error,
			'SUCCESS'    => $success,
			'U_ACTION'   => $this->helper->route('adr_rpg_temple'),
		]);

		return $this->helper->render('@adr_rpg/adr_temple.html', $this->user->lang('ADR_TEMPLE'));
	}
}
