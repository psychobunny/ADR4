<?php
namespace adr\rpg\controller;

class cell
{
        protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

        public function __construct(
                \phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
                \phpbb\user $user, \phpbb\template\template $template,
                \phpbb\controller\helper $helper, \phpbb\request\request $request,
                \phpbb\auth\auth $auth, $root_path, $php_ext,
                \adr\rpg\service\manager $manager
        ) {
                $this->config = $config; $this->db = $db; $this->user = $user;
                $this->template = $template; $this->helper = $helper;
                $this->request = $request; $this->auth = $auth;
                $this->root_path = $root_path; $this->php_ext = $php_ext;
                $this->manager = $manager;
        }

        public function index()
        {
                if (!$this->user->data['is_registered'])
                {
                        login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
                }

                $user_id = (int) $this->user->data['user_id'];
                $this->user->add_lang_ext('adr/rpg', 'common');

                if (!$this->config['adr_jail_enable'])
                {
                        trigger_error($this->user->lang('ADR_JAIL_DISABLED'));
                }

                $jail_sql = 'SELECT j.*, u.username AS jailer_name
                                        FROM ' . $this->manager->get_table('jail_users') . ' j
                                        LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = j.user_id
                                        WHERE j.celled_id = ' . $user_id . '
                                        AND j.user_freed_by = 0';
                $result = $this->db->sql_query($jail_sql);
                $jail   = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if ($jail && $jail['user_time'] > 0 && $jail['user_time'] < time())
                {
                        $this->db->sql_query('DELETE FROM ' . $this->manager->get_table('jail_users') . '
                                WHERE celled_id = ' . $user_id);
                        $jail = null;
                }

                $time_remaining = 0;
                if ($jail && $jail['user_time'] > 0)
                {
                        $time_remaining = max(0, $jail['user_time'] - time());
                }

                if ($this->request->is_set_post('pay_bail') && $jail)
                {
                        $bail_amount = (int) $jail['user_caution'];
                        $char        = $this->manager->get_user_character($user_id);

                        if ($char && $char['character_gold'] >= $bail_amount)
                        {
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
                                        SET character_gold = character_gold - ' . $bail_amount . '
                                        WHERE character_id = ' . $user_id);
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('jail_users') . '
                                        SET user_freed_by = ' . $user_id . ', user_time = ' . time() . '
                                        WHERE celled_id = ' . $user_id);
                                redirect($this->helper->route('adr_rpg_town'));
                        }
                        else
                        {
                                $this->template->assign_var('BAIL_ERROR', $this->user->lang('ADR_LACK_POINTS'));
                        }
                }

                $character = $this->manager->character_exists($user_id) ? $this->manager->get_user_character($user_id) : null;

                $this->template->assign_vars([
                        'JAIL_DATA'      => $jail,
                        'TIME_REMAINING' => $time_remaining,
                        'CHARACTER'      => $character,
                        'U_ACTION'       => $this->helper->route('adr_rpg_cell'),
                        'U_COURTHOUSE'   => $this->helper->route('adr_rpg_courthouse'),
                ]);

                return $this->helper->render('@adr_rpg/adr_cell.html', $this->user->lang('ADR_CELL'));
        }
}
