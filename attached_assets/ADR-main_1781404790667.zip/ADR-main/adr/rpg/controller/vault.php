<?php
namespace adr\rpg\controller;

class vault
{
        protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

        public function __construct(
                \phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
                \phpbb\user $user, \phpbb\template\template $template,
                \phpbb\controller\helper $helper, \phpbb\request\request $request,
                \phpbb\auth\auth $auth, $root_path, $php_ext,
                \adr\rpg\service\manager $manager
        ) {
                $this->config = $config; $this->db = $db; $this->user = $user;
                $this->template = $template; $this->helper = $helper;
                $this->request = $request; $this->auth = $auth;
                $this->root_path = $root_path; $this->php_ext = $php_ext;
                $this->manager = $manager;
        }

        public function index()
        {
                if (!$this->user->data['is_registered'])
                {
                        login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
                }

                $user_id = (int) $this->user->data['user_id'];
                if (!$this->manager->character_exists($user_id))
                {
                        redirect($this->helper->route('adr_rpg_character_create'));
                }

                $this->user->add_lang_ext('adr/rpg', 'common');

                if (!$this->config['adr_vault_enable'])
                {
                        trigger_error($this->user->lang('ADR_VAULT_DISABLED'));
                }

                $this->manager->update_stock_prices();

                $mode      = $this->request->variable('mode', '');
                $character = $this->manager->get_user_character($user_id);
                $vault     = $this->manager->get_vault_data($user_id);
                $error     = '';
                $success   = '';

                if ($mode === 'deposit' && $this->request->is_set_post('submit'))
                {
                        $amount = $this->request->variable('amount', 0);
                        if ($amount > 0 && $amount <= $character['character_gold'])
                        {
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
                                        SET character_gold = character_gold - ' . $amount . '
                                        WHERE character_id = ' . $user_id);
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                                        SET account_sum = account_sum + ' . $amount . '
                                        WHERE owner_id = ' . $user_id);

                                $success   = sprintf($this->user->lang('ADR_VAULT_DEPOSIT_OK'), $amount);
                                $character = $this->manager->get_user_character($user_id);
                                $vault     = $this->manager->get_vault_data($user_id);
                        }
                        else
                        {
                                $error = $this->user->lang('ADR_LACK_POINTS');
                        }
                }

                if ($mode === 'withdraw' && $this->request->is_set_post('submit'))
                {
                        $amount = $this->request->variable('amount', 0);
                        if ($amount > 0 && $amount <= $vault['account_sum'])
                        {
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                                        SET account_sum = account_sum - ' . $amount . '
                                        WHERE owner_id = ' . $user_id);
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
                                        SET character_gold = character_gold + ' . $amount . '
                                        WHERE character_id = ' . $user_id);
                                $success   = sprintf($this->user->lang('ADR_VAULT_WITHDRAW_OK'), $amount);
                                
                                $character = $this->manager->get_user_character($user_id);
                                $vault     = $this->manager->get_vault_data($user_id);
                        }
                        else
                        {
                                $error = $this->user->lang('ADR_VAULT_INSUFFICIENT_FUNDS');
                        }
                }

                if ($mode === 'transfer' && $this->request->is_set_post('submit'))
                {
                        $target_id = $this->request->variable('target_id', 0);
                        $amount    = $this->request->variable('amount', 0);

                        $blacklist_sql = 'SELECT user_id FROM ' . $this->manager->get_table('vault_blacklist') . '
                                WHERE user_id = ' . $user_id . ' AND user_due > ' . time();
                        $bl_result = $this->db->sql_query($blacklist_sql);
                        $is_blacklisted = $this->db->sql_fetchrow($bl_result);
                        $this->db->sql_freeresult($bl_result);

                        if ($is_blacklisted)
                        {
                                $error = $this->user->lang('ADR_VAULT_BLACKLISTED');
                        }
                        else if ($target_id && $amount > 0 && $amount <= $vault['account_sum'] && $this->manager->character_exists($target_id))
                        {
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                                        SET account_sum = account_sum - ' . $amount . '
                                        WHERE owner_id = ' . $user_id);

                                $target_vault = $this->manager->get_vault_data($target_id);
                                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                                        SET account_sum = account_sum + ' . $amount . '
                                        WHERE owner_id = ' . $target_id);

                                $success = $this->user->lang('ADR_VAULT_TRANSFER_OK');
                                $vault   = $this->manager->get_vault_data($user_id);
                        }
                        else
                        {
                                $error = $this->user->lang('ADR_VAULT_TRANSFER_ERROR');
                        }
                }

                if ($mode === 'stock_buy' && $this->request->is_set_post('submit'))
                {
                        $stock_id = $this->request->variable('stock_id', 0);
                        $amount   = $this->request->variable('amount', 0);
                        $this->buy_stock($user_id, $stock_id, $amount, $vault);
                        $vault = $this->manager->get_vault_data($user_id);
                }

                if ($mode === 'stock_sell' && $this->request->is_set_post('submit'))
                {
                        $stock_id = $this->request->variable('stock_id', 0);
                        $amount   = $this->request->variable('amount', 0);
                        $this->sell_stock($user_id, $stock_id, $amount);
                        $vault = $this->manager->get_vault_data($user_id);
                }

                $exchange  = $this->manager->get_vault_exchange();

                $user_stocks_sql = 'SELECT * FROM ' . $this->manager->get_table('vault_exchange_users') . '
                        WHERE user_id = ' . $user_id;
                $us_result   = $this->db->sql_query($user_stocks_sql);
                $user_stocks = $this->db->sql_fetchrowset($us_result);
                $this->db->sql_freeresult($us_result);

                $user_stock_map = [];
                foreach ($user_stocks as $us)
                {
                        $user_stock_map[$us['stock_id']] = $us['stock_amount'];
                }

                $this->template->assign_vars([
                        'CHARACTER'      => $character,
                        'VAULT'          => $vault,
                        'EXCHANGE'       => $exchange,
                        'USER_STOCKS'    => $user_stock_map,
                        'STOCK_ENABLE'   => (bool) $this->config['stock_use'],
                        'MODE'           => $mode,
                        'ERROR'          => $error,
                        'SUCCESS'        => $success,
                        'U_ACTION'       => $this->helper->route('adr_rpg_vault'),
                ]);

                return $this->helper->render('@adr_rpg/adr_vault.html', $this->user->lang('ADR_VAULT'));
        }

        protected function buy_stock($user_id, $stock_id, $amount, $vault)
        {
                $stock_id = (int) $stock_id;
                $amount   = (int) $amount;

                if (!$stock_id || $amount <= 0)
                {
                        return;
                }

                $sql = 'SELECT * FROM ' . $this->manager->get_table('vault_exchange') . ' WHERE stock_id = ' . $stock_id;
                $result = $this->db->sql_query($sql);
                $stock  = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$stock)
                {
                        return;
                }

                $total = $amount * (int) $stock['stock_price'];
                if ($vault['account_sum'] < $total)
                {
                        $this->template->assign_var('STOCK_ERROR', $this->user->lang('ADR_VAULT_INSUFFICIENT_FUNDS'));
                        return;
                }

                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                        SET account_sum = account_sum - ' . $total . '
                        WHERE owner_id = ' . $user_id);

                $existing_sql = 'SELECT stock_amount FROM ' . $this->manager->get_table('vault_exchange_users') . '
                        WHERE user_id = ' . $user_id . ' AND stock_id = ' . $stock_id;
                $existing_result = $this->db->sql_query($existing_sql);
                $existing = $this->db->sql_fetchrow($existing_result);
                $this->db->sql_freeresult($existing_result);

                if ($existing)
                {
                        $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_exchange_users') . '
                                SET stock_amount = stock_amount + ' . $amount . '
                                WHERE user_id = ' . $user_id . ' AND stock_id = ' . $stock_id);
                }
                else
                {
                        $this->db->sql_query('INSERT INTO ' . $this->manager->get_table('vault_exchange_users') . ' ' .
                                $this->db->sql_build_array('INSERT', [
                                        'user_id'      => $user_id,
                                        'stock_id'     => $stock_id,
                                        'stock_amount' => $amount,
                                ]));
                }
        }

        protected function sell_stock($user_id, $stock_id, $amount)
        {
                $stock_id = (int) $stock_id;
                $amount   = (int) $amount;

                if (!$stock_id || $amount <= 0)
                {
                        return;
                }

                $existing_sql = 'SELECT stock_amount FROM ' . $this->manager->get_table('vault_exchange_users') . '
                        WHERE user_id = ' . $user_id . ' AND stock_id = ' . $stock_id;
                $existing_result = $this->db->sql_query($existing_sql);
                $existing = $this->db->sql_fetchrow($existing_result);
                $this->db->sql_freeresult($existing_result);

                if (!$existing || $existing['stock_amount'] < $amount)
                {
                        return;
                }

                $sql = 'SELECT stock_price FROM ' . $this->manager->get_table('vault_exchange') . ' WHERE stock_id = ' . $stock_id;
                $result = $this->db->sql_query($sql);
                $stock  = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                $total = $amount * (int) $stock['stock_price'];

                $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_users') . '
                        SET account_sum = account_sum + ' . $total . '
                        WHERE owner_id = ' . $user_id);

                if ($existing['stock_amount'] === $amount)
                {
                        $this->db->sql_query('DELETE FROM ' . $this->manager->get_table('vault_exchange_users') . '
                                WHERE user_id = ' . $user_id . ' AND stock_id = ' . $stock_id);
                }
                else
                {
                        $this->db->sql_query('UPDATE ' . $this->manager->get_table('vault_exchange_users') . '
                                SET stock_amount = stock_amount - ' . $amount . '
                                WHERE user_id = ' . $user_id . ' AND stock_id = ' . $stock_id);
                }
        }
}
