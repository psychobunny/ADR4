<?php
namespace adr\rpg\controller;

class character
{
	protected $config;
	protected $db;
	protected $user;
	protected $template;
	protected $helper;
	protected $request;
	protected $auth;
	protected $root_path;
	protected $php_ext;
	protected $manager;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\user $user,
		\phpbb\template\template $template,
		\phpbb\controller\helper $helper,
		\phpbb\request\request $request,
		\phpbb\auth\auth $auth,
		$root_path,
		$php_ext,
		\adr\rpg\service\manager $manager
	)
	{
		$this->config    = $config;
		$this->db        = $db;
		$this->user      = $user;
		$this->template  = $template;
		$this->helper    = $helper;
		$this->request   = $request;
		$this->auth      = $auth;
		$this->root_path = $root_path;
		$this->php_ext   = $php_ext;
		$this->manager   = $manager;
	}

	protected function require_login()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}
	}

	protected function require_character()
	{
		$user_id = (int) $this->user->data['user_id'];
		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}
		if ($this->manager->is_character_banned($user_id))
		{
			trigger_error($this->user->lang('ADR_BANNED') . '<br /><br />' .
				'<a href="' . $this->helper->route('adr_rpg_character') . '">' . $this->user->lang('BACK_TO_PREV') . '</a>');
		}
	}

	public function index()
	{
		$this->require_login();
		return $this->view((int) $this->user->data['user_id']);
	}

	public function view($user_id)
	{
		$user_id = (int) $user_id;
		if (!$user_id)
		{
			$user_id = (int) $this->user->data['user_id'];
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->manager->character_exists($user_id))
		{
			if ($user_id === (int) $this->user->data['user_id'])
			{
				redirect($this->helper->route('adr_rpg_character_create'));
			}
			trigger_error($this->user->lang('ADR_NO_CHARACTER'));
		}

		$character = $this->manager->get_user_character($user_id);
		$is_own    = ((int) $this->user->data['user_id'] === $user_id);

		$user_sql = 'SELECT username, user_colour FROM ' . USERS_TABLE . ' WHERE user_id = ' . $user_id;
		$result   = $this->db->sql_query($user_sql);
		$user_row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$this->template->assign_vars([
			'CHARACTER'           => $character,
			'CHARACTER_USERNAME'  => $user_row['username'] ?? '',
			'CHARACTER_COLOUR'    => $user_row['user_colour'] ?? '',
			'IS_OWN_CHARACTER'    => $is_own,
			'U_CHARACTER_PREFS'   => $is_own ? $this->helper->route('adr_rpg_character_prefs') : '',
			'U_CHARACTER_INVENTORY' => $this->helper->route('adr_rpg_character_inventory'),
			'U_CHARACTER_EQUIPMENT' => $this->helper->route('adr_rpg_character_equipment'),
			'U_CHARACTER_SKILLS'  => $this->helper->route('adr_rpg_character_skills'),
			'U_CHALLENGE_PVP'     => (!$is_own && $this->config['adr_pvp_enable']) ?
				$this->helper->route('adr_rpg_battle_pvp') . '?challenge=' . $user_id : '',
		]);

		return $this->helper->render('@adr_rpg/adr_character.html', $this->user->lang('ADR_CHARACTER_PAGE'));
	}

	public function create()
	{
		$this->require_login();
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id = (int) $this->user->data['user_id'];
		$mode    = $this->request->variable('mode', '');

		if (!$this->config['adr_enabled'])
		{
			trigger_error($this->user->lang('ADR_DISABLED'));
		}

		$races      = $this->manager->get_races();
		$classes    = $this->manager->get_classes();
		$alignments = $this->manager->get_alignments();
		$elements   = $this->manager->get_elements();

		if ($this->request->is_set_post('submit'))
		{
			$race_id      = $this->request->variable('race_id', 0);
			$class_id     = $this->request->variable('class_id', 0);
			$alignment_id = $this->request->variable('alignment_id', 0);
			$element_id   = $this->request->variable('element_id', 0);
			$desc         = $this->request->variable('character_desc', '', true);

			$errors = [];

			if (!$race_id || !$class_id || !$alignment_id || !$element_id)
			{
				$errors[] = $this->user->lang('ADR_CHARACTER_MISSING_FIELDS');
			}

			if (empty($errors))
			{
				$result = $this->manager->create_character($user_id, [
					'race_id'      => $race_id,
					'class_id'     => $class_id,
					'alignment_id' => $alignment_id,
					'element_id'   => $element_id,
					'desc'         => $desc,
				]);

				if ($result)
				{
					redirect($this->helper->route('adr_rpg_character'));
				}
				else
				{
					$errors[] = $this->user->lang('ADR_CHARACTER_ALREADY_EXISTS');
				}
			}

			$this->template->assign_var('ERRORS', $errors);
		}

		$this->template->assign_vars([
			'RACES'      => $races,
			'CLASSES'    => $classes,
			'ALIGNMENTS' => $alignments,
			'ELEMENTS'   => $elements,
			'U_ACTION'   => $this->helper->route('adr_rpg_character_create'),
		]);

		return $this->helper->render('@adr_rpg/adr_character_create.html', $this->user->lang('ADR_CHARACTER_CREATE'));
	}

	public function list()
	{
		$this->user->add_lang_ext('adr/rpg', 'common');

		$start = $this->request->variable('start', 0);
		$sort  = $this->request->variable('sort', 'character_level');
		$order = $this->request->variable('order', 'DESC');

		$data  = $this->manager->get_character_list($start, 20, $sort, $order);

		$this->template->assign_vars([
			'CHARACTERS' => $data['rows'],
			'TOTAL'      => $data['total'],
			'START'      => $start,
			'SORT'       => $sort,
			'ORDER'      => $order,
			'U_SORT_LEVEL'  => $this->helper->route('adr_rpg_character_list') . '?sort=character_level',
			'U_SORT_NAME'   => $this->helper->route('adr_rpg_character_list') . '?sort=character_name',
			'U_SORT_XP'     => $this->helper->route('adr_rpg_character_list') . '?sort=character_xp',
		]);

		return $this->helper->render('@adr_rpg/adr_character_list.html', $this->user->lang('ADR_CHARACTER_LIST'));
	}

	public function inventory()
	{
		$this->require_login();
		$this->require_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id = (int) $this->user->data['user_id'];

		if ($this->request->is_set_post('give_item'))
		{
			$item_id        = $this->request->variable('item_id', 0);
			$target_user_id = $this->request->variable('target_user_id', 0);
			$this->give_item($user_id, $item_id, $target_user_id);
		}

		if ($this->request->is_set_post('sell_item'))
		{
			$item_id = $this->request->variable('item_id', 0);
			$price   = $this->request->variable('sell_price', 0);
			$this->list_item_for_sale($user_id, $item_id, $price);

			// Let the player immediately verify their listing on the blackmarket.
			$this->template->assign_vars([
				'SELL_SUCCESS' => true,
				'SELL_SHOP_URL' => $this->helper->route('adr_rpg_shops') . '?mode=blackmarket&seller_id=' . $user_id,
			]);
		}

		if ($this->request->is_set_post('delist_item'))
		{
			$item_id = $this->request->variable('item_id', 0);
			$this->delist_item($user_id, $item_id);
		}

		$items     = $this->manager->get_user_items($user_id);
		$character = $this->manager->get_user_character($user_id);

		$this->template->assign_vars([
			'ITEMS'     => $items,
			'CHARACTER' => $character,
			'U_ACTION'  => $this->helper->route('adr_rpg_character_inventory'),
		]);

		return $this->helper->render('@adr_rpg/adr_character_inventory.html', $this->user->lang('ADR_INVENTORY'));
	}

	protected function give_item($user_id, $item_id, $target_user_id)
	{
		$user_id        = (int) $user_id;
		$item_id        = (int) $item_id;
		$target_user_id = (int) $target_user_id;

		if (!$item_id || !$target_user_id || $target_user_id === $user_id)
		{
			return;
		}

		if (!$this->manager->character_exists($target_user_id))
		{
			return;
		}

		$item_sql = 'SELECT i.*, c_target.character_weight, c_target.character_weight_max
					FROM ' . $this->manager->get_table('shops_items') . ' i
					JOIN ' . $this->manager->get_table('characters') . ' c_target ON c_target.character_id = ' . $target_user_id . '
					WHERE i.item_id = ' . $item_id . '
					AND i.item_owner_id = ' . $user_id . '
					AND i.item_in_shop = 0
					AND i.item_equipped = 0';
		$result = $this->db->sql_query($item_sql);
		$item   = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$item)
		{
			return;
		}

		if (($item['character_weight'] + $item['item_weight']) > $item['character_weight_max'])
		{
			return;
		}

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_owner_id = ' . $target_user_id . '
			WHERE item_id = ' . $item_id);

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
			SET character_weight = character_weight + ' . (int) $item['item_weight'] . '
			WHERE character_id = ' . $target_user_id);

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
			SET character_weight = character_weight - ' . (int) $item['item_weight'] . '
			WHERE character_id = ' . $user_id);
	}

	protected function list_item_for_sale($user_id, $item_id, $price)
	{
		$user_id = (int) $user_id;
		$item_id = (int) $item_id;
		$price   = max(0, (int) $price);

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_in_shop = 1, item_price = ' . $price . '
			WHERE item_id = ' . $item_id . '
			AND item_owner_id = ' . $user_id . '
			AND item_equipped = 0');
	}

	protected function delist_item($user_id, $item_id)
	{
		$user_id = (int) $user_id;
		$item_id = (int) $item_id;

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_in_shop = 0
			WHERE item_id = ' . $item_id . '
			AND item_owner_id = ' . $user_id);
	}

	public function equipment()
	{
		$this->require_login();
		$this->require_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id   = (int) $this->user->data['user_id'];
		$character = $this->manager->get_user_character($user_id);

		if ($this->request->is_set_post('equip'))
		{
			$item_id = $this->request->variable('item_id', 0);
			$slot    = $this->request->variable('equip_slot', '');
			$this->equip_item($user_id, $item_id, $slot);
		}

		if ($this->request->is_set_post('unequip'))
		{
			$item_id = $this->request->variable('item_id', 0);
			$this->unequip_item($user_id, $item_id);
		}

		$items    = $this->manager->get_user_items($user_id);
		$equipped = $this->manager->get_user_items($user_id, 0, 1);

		$this->template->assign_vars([
			'ITEMS'     => $items,
			'EQUIPPED'  => $equipped,
			'CHARACTER' => $character,
			'U_ACTION'  => $this->helper->route('adr_rpg_character_equipment'),
		]);

		return $this->helper->render('@adr_rpg/adr_character_equipment.html', $this->user->lang('ADR_EQUIPMENT'));
	}

	protected function equip_item($user_id, $item_id, $slot)
	{
		$user_id = (int) $user_id;
		$item_id = (int) $item_id;
		$slot    = preg_replace('/[^a-zA-Z0-9_]/', '', $slot);

		if (!$slot)
		{
			return;
		}

		$sql = 'SELECT * FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $item_id . '
				AND item_owner_id = ' . $user_id . '
				AND item_in_shop = 0
				AND item_equipped = 0';
		$result = $this->db->sql_query($sql);
		$item   = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$item)
		{
			return;
		}

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_equipped = 0
			WHERE item_owner_id = ' . $user_id . '
			AND item_equip_slot = \'' . $this->db->sql_escape($slot) . '\'');

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_equipped = 1, item_equip_slot = \'' . $this->db->sql_escape($slot) . '\'
			WHERE item_id = ' . $item_id . '
			AND item_owner_id = ' . $user_id);

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
			SET character_ac = character_ac + ' . (int) $item['item_ac'] . '
			WHERE character_id = ' . $user_id);
	}

	protected function unequip_item($user_id, $item_id)
	{
		$user_id = (int) $user_id;
		$item_id = (int) $item_id;

		$sql = 'SELECT item_ac FROM ' . $this->manager->get_table('shops_items') . '
				WHERE item_id = ' . $item_id . '
				AND item_owner_id = ' . $user_id . '
				AND item_equipped = 1';
		$result = $this->db->sql_query($sql);
		$item   = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$item)
		{
			return;
		}

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('shops_items') . '
			SET item_equipped = 0, item_equip_slot = \'\'
			WHERE item_id = ' . $item_id . '
			AND item_owner_id = ' . $user_id);

		$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
			SET character_ac = character_ac - ' . (int) $item['item_ac'] . '
			WHERE character_id = ' . $user_id);
	}

	public function skills()
	{
		$this->require_login();
		$this->require_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id   = (int) $this->user->data['user_id'];
		$character = $this->manager->get_user_character($user_id);
		$skills    = $this->manager->get_skills();

		$this->template->assign_vars([
			'CHARACTER' => $character,
			'SKILLS'    => $skills,
		]);

		return $this->helper->render('@adr_rpg/adr_character_skills.html', $this->user->lang('ADR_SKILLS'));
	}

	public function prefs()
	{
		$this->require_login();
		$this->require_character();
		$this->user->add_lang_ext('adr/rpg', 'common');

		$user_id   = (int) $this->user->data['user_id'];
		$character = $this->manager->get_user_character($user_id);

		if ($this->request->is_set_post('submit'))
		{
			$desc = $this->request->variable('character_desc', '', true);
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET character_desc = \'' . $this->db->sql_escape($desc) . '\'
				WHERE character_id = ' . $user_id);
			redirect($this->helper->route('adr_rpg_character'));
		}

		if ($this->request->is_set_post('spend_sp'))
		{
			$sp_might = $this->request->variable('sp_might', 0);
			$sp_dex   = $this->request->variable('sp_dex', 0);
			$sp_con   = $this->request->variable('sp_con', 0);
			$sp_int   = $this->request->variable('sp_int', 0);
			$sp_wis   = $this->request->variable('sp_wis', 0);
			$sp_cha   = $this->request->variable('sp_cha', 0);

			$total_sp = $sp_might + $sp_dex + $sp_con + $sp_int + $sp_wis + $sp_cha;

			if ($total_sp <= $character['character_sp'] && $total_sp > 0)
			{
				$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
					SET character_might = character_might + ' . (int) $sp_might . ',
						character_dexterity = character_dexterity + ' . (int) $sp_dex . ',
						character_constitution = character_constitution + ' . (int) $sp_con . ',
						character_intelligence = character_intelligence + ' . (int) $sp_int . ',
						character_wisdom = character_wisdom + ' . (int) $sp_wis . ',
						character_charisma = character_charisma + ' . (int) $sp_cha . ',
						character_sp = character_sp - ' . $total_sp . '
					WHERE character_id = ' . $user_id);

				$character = $this->manager->get_user_character($user_id);
			}
		}

		$this->template->assign_vars([
			'CHARACTER' => $character,
			'U_ACTION'  => $this->helper->route('adr_rpg_character_prefs'),
		]);

		return $this->helper->render('@adr_rpg/adr_character_prefs.html', $this->user->lang('ADR_PREFS'));
	}

	public function faq()
	{
		$this->user->add_lang_ext('adr/rpg', 'common');

		return $this->helper->render('@adr_rpg/adr_character_faq.html', $this->user->lang('ADR_ZONE_CHARACTER_FAQ'));
	}
}
