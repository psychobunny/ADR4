<?php
namespace adr\rpg\controller;

class courthouse
{
	protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

	public function __construct(
		\phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
		\phpbb\user $user, \phpbb\template\template $template,
		\phpbb\controller\helper $helper, \phpbb\request\request $request,
		\phpbb\auth\auth $auth, $root_path, $php_ext,
		\adr\rpg\service\manager $manager
	) {
		$this->config = $config; $this->db = $db; $this->user = $user;
		$this->template = $template; $this->helper = $helper;
		$this->request = $request; $this->auth = $auth;
		$this->root_path = $root_path; $this->php_ext = $php_ext;
		$this->manager = $manager;
	}

	public function index()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}

		$user_id = (int) $this->user->data['user_id'];
		$this->user->add_lang_ext('adr/rpg', 'common');

		if (!$this->config['adr_jail_enable'])
		{
			trigger_error($this->user->lang('ADR_JAIL_DISABLED'));
		}

		$mode = $this->request->variable('mode', '');

		if ($mode === 'file_complaint' && $this->request->is_set_post('submit'))
		{
			$this->handle_complaint($user_id);
		}

		if ($mode === 'vote' && $this->request->is_set_post('submit'))
		{
			$this->handle_vote($user_id);
		}

		$cases_sql = 'SELECT j.*, u_c.username AS celled_name, u_c.user_colour AS celled_colour,
					u_j.username AS jailer_name
					FROM ' . $this->manager->get_table('jail_users') . ' j
					JOIN ' . USERS_TABLE . ' u_c ON u_c.user_id = j.celled_id
					LEFT JOIN ' . USERS_TABLE . ' u_j ON u_j.user_id = j.user_id
					WHERE j.user_freed_by = 0
					ORDER BY j.user_cell_date DESC';
		$result = $this->db->sql_query($cases_sql);
		$cases  = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		foreach ($cases as &$case)
		{
			$case['time_remaining'] = ($case['user_time'] > 0) ? max(0, $case['user_time'] - time()) : 0;

			$vote_sql = 'SELECT vote_result, COUNT(*) AS cnt FROM ' . $this->manager->get_table('jail_votes') . '
				WHERE vote_id = ' . (int) $case['celled_id'] . '
				GROUP BY vote_result';
			$v_result = $this->db->sql_query($vote_sql);
			$votes_for = 0;
			$votes_against = 0;
			while ($v_row = $this->db->sql_fetchrow($v_result))
			{
				if ($v_row['vote_result'] == 1)
				{
					$votes_for = (int) $v_row['cnt'];
				}
				else
				{
					$votes_against = (int) $v_row['cnt'];
				}
			}
			$this->db->sql_freeresult($v_result);

			$case['votes_for']     = $votes_for;
			$case['votes_against'] = $votes_against;

			$already_sql = 'SELECT vote_result FROM ' . $this->manager->get_table('jail_votes') . '
				WHERE vote_id = ' . (int) $case['celled_id'] . '
				AND voter_id = ' . $user_id;
			$a_result = $this->db->sql_query($already_sql);
			$already  = $this->db->sql_fetchrow($a_result);
			$this->db->sql_freeresult($a_result);
			$case['user_voted'] = (bool) $already;
		}

		$this->template->assign_vars([
			'CASES'     => $cases,
			'U_ACTION'  => $this->helper->route('adr_rpg_courthouse'),
			'U_CELL'    => $this->helper->route('adr_rpg_cell'),
			'CAN_FILE'  => $this->manager->character_exists($user_id),
		]);

		return $this->helper->render('@adr_rpg/adr_courthouse.html', $this->user->lang('ADR_COURTHOUSE'));
	}

	protected function handle_complaint($user_id)
	{
		$target_id = $this->request->variable('target_id', 0);
		$sentence  = $this->request->variable('sentence', '', true);
		$duration  = $this->request->variable('duration', 3600);
		$caution   = $this->request->variable('caution', 0);

		if (!$target_id || $target_id === $user_id || !$this->manager->character_exists($target_id))
		{
			return;
		}

		if ($this->manager->is_in_jail($target_id))
		{
			return;
		}

		$duration = max(60, min(604800, (int) $duration));
		$caution  = max(0, (int) $caution);

		$jail_data = [
			'celled_id'      => $target_id,
			'user_id'        => $user_id,
			'user_cell_date' => time(),
			'user_freed_by'  => 0,
			'user_sentence'  => $sentence,
			'user_caution'   => $caution,
			'user_time'      => time() + $duration,
		];

		$this->db->sql_query('INSERT INTO ' . $this->manager->get_table('jail_users') . ' ' .
			$this->db->sql_build_array('INSERT', $jail_data));
	}

	protected function handle_vote($user_id)
	{
		$celled_id   = $this->request->variable('celled_id', 0);
		$vote_result = $this->request->variable('vote', 0);

		if (!$celled_id || ($vote_result !== 0 && $vote_result !== 1))
		{
			return;
		}

		$already_sql = 'SELECT vote_id FROM ' . $this->manager->get_table('jail_votes') . '
			WHERE vote_id = ' . $celled_id . ' AND voter_id = ' . $user_id;
		$result  = $this->db->sql_query($already_sql);
		$already = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($already)
		{
			return;
		}

		$this->db->sql_query('INSERT INTO ' . $this->manager->get_table('jail_votes') . ' ' .
			$this->db->sql_build_array('INSERT', [
				'vote_id'     => $celled_id,
				'voter_id'    => $user_id,
				'vote_result' => $vote_result,
			]));

		$count_sql = 'SELECT vote_result, COUNT(*) AS cnt FROM ' . $this->manager->get_table('jail_votes') . '
			WHERE vote_id = ' . $celled_id . ' GROUP BY vote_result';
		$count_result = $this->db->sql_query($count_sql);
		$release_votes = 0;
		while ($row = $this->db->sql_fetchrow($count_result))
		{
			if ($row['vote_result'] == 1)
			{
				$release_votes = (int) $row['cnt'];
			}
		}
		$this->db->sql_freeresult($count_result);

		if ($release_votes >= 5)
		{
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('jail_users') . '
				SET user_freed_by = ' . $user_id . ', user_time = ' . time() . '
				WHERE celled_id = ' . $celled_id);
		}
	}
}
