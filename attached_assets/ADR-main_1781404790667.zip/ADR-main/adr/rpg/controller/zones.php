<?php

namespace adr\rpg\controller;

class zones
{
    protected $config;
    protected $db;
    protected $user;
    protected $template;
    protected $helper;
    protected $request;
    protected $auth;
    protected $root_path;
    protected $php_ext;
    protected $manager;

    public function __construct(
        \phpbb\config\config $config,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\user $user,
        \phpbb\template\template $template,
        \phpbb\controller\helper $helper,
        \phpbb\request\request $request,
        \phpbb\auth\auth $auth,
        $root_path,
        $php_ext,
        \adr\rpg\service\manager $manager
    ) {
        $this->config    = $config;
        $this->db        = $db;
        $this->user      = $user;
        $this->template  = $template;
        $this->helper    = $helper;
        $this->request   = $request;
        $this->auth      = $auth;
        $this->root_path = $root_path;
        $this->php_ext   = $php_ext;
        $this->manager   = $manager;
    }

    protected function require_login_and_character()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}
		$user_id = (int) $this->user->data['user_id'];
		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}
		if ($this->manager->is_character_banned($user_id))
		{
			trigger_error($this->user->lang('ADR_BANNED'));
		}
		if ($this->manager->is_in_jail($user_id))
		{
			trigger_error($this->user->lang('ADR_IN_JAIL'));
		}
	}

    public function index()
    {
        $this->require_login_and_character();

        $user_id = (int) $this->user->data['user_id'];

        
        $this->manager->check_seasons_cron();

        $adr_user = $this->manager->get_user_character($user_id);
        $area_id  = (int) $adr_user['character_area'];

        $sql = 'SELECT * FROM ' . $this->manager->zones_table() . " WHERE zone_id = $area_id";
        $result = $this->db->sql_query($sql);
        $zone = $this->db->sql_fetchrow($result);
        $this->db->sql_freeresult($result);

        if (!$zone)
        {
            trigger_error('ADR_ZONES_NOT_FOUND');
        }

        $goto1_name  = $zone['goto1_name'];
        $goto2_name  = $zone['goto2_name'] ?: $this->user->lang('ADR_ZONE_DESTINATION_NONE');
        $return_name = $zone['return_name'] ?: $this->user->lang('ADR_ZONE_DESTINATION_NONE');

        $none = $this->user->lang('ADR_ZONE_DESTINATION_NONE');

        // --- Handle navigation ---
        $action = $this->request->variable('action', '');

        if ($action === 'goto1' && $goto1_name !== '')
        {
            $this->_travel($user_id, $goto1_name, (int) $zone['cost_goto1'], $adr_user);
        }
        elseif ($action === 'goto2' && $goto2_name !== $none)
        {
            $this->_travel($user_id, $goto2_name, (int) $zone['cost_goto2'], $adr_user);
        }
        elseif ($action === 'return' && $return_name !== $none)
        {
            $this->_travel($user_id, $return_name, (int) $zone['cost_return'], $adr_user);
        }
        elseif (in_array($action, ['goto1', 'goto2', 'return']))
        {
            trigger_error($this->user->lang('ADR_ZONE_CHANGE_UNAVAILABLE') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
        }

        // --- Handle NPC talk ---
        for ($i = 1; $i <= 5; $i++)
        {
            if ($this->request->variable("npc$i", '') !== '' && $zone["npc{$i}_enable"])
            {
                $npc_price = (int) $zone['npc_price'];
                $msg       = $zone["npc{$i}_message"];
                $this->manager->subtract_points($user_id, $npc_price);
                trigger_error(nl2br(htmlspecialchars($msg)) . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
            }
        }

        // --- Zone events ---
        $this->_run_events($user_id, $zone, $adr_user);

        // --- Assign season & zone data ---
        $season = (int) $this->config['adr_seasons'];
        $season_folder = $this->_season_folder($season);

        $this->template->assign_vars([
            'ZONE_NAME'         => $zone['zone_name'],
            'ZONE_DESC'         => $zone['zone_desc'],
            'ZONE_IMG'          => $zone['zone_img'],
            'ZONE_ELEMENT'      => $zone['zone_element'],
            'ZONE_SEASON'       => $season_folder,
            'GOTO1_NAME'        => $goto1_name,
            'GOTO2_NAME'        => $goto2_name,
            'RETURN_NAME'       => $return_name,
            'COST_GOTO1'        => $zone['cost_goto1'],
            'COST_GOTO2'        => $zone['cost_goto2'],
            'COST_RETURN'       => $zone['cost_return'],
            'HAS_GOTO2'         => ($goto2_name !== $none),
            'HAS_RETURN'        => ($return_name !== $none),
            'S_ZONES_ACTION'    => $this->helper->route('adr_rpg_zones'),

            'NPC1_ENABLE'       => (bool) $zone['npc1_enable'],
            'NPC2_ENABLE'       => (bool) $zone['npc2_enable'],
            'NPC3_ENABLE'       => (bool) $zone['npc3_enable'],
            'NPC4_ENABLE'       => (bool) $zone['npc4_enable'],
            'NPC5_ENABLE'       => (bool) $zone['npc5_enable'],
            'NPC_PRICE'         => $zone['npc_price'],

            'L_ZONES_TITLE'     => $this->user->lang('ADR_ZONES'),
            'L_ZONE_NAVIGATE'   => $this->user->lang('ADR_FAQ_Q_ENCHANTING'),
            'L_ZONE_GOTO1'      => $this->user->lang('ADR_ZONE_GOTO1'),
            'L_ZONE_GOTO2'      => $this->user->lang('ADR_ZONE_GOTO2'),
            'L_ZONE_RETURN'     => $this->user->lang('ADR_ZONE_RETURN'),
            'L_ZONE_NPC_TALK'   => $this->user->lang('ADR_ZONE_NPC_TALK'),
            'L_ZONE_DESTINATION_NONE' => $this->user->lang('ADR_ZONE_DESTINATION_NONE'),
        ]);

        $this->manager->assign_zone_header($this->template, $this->helper, $this->user, $area_id, $season_folder);

        return $this->helper->render('adr_zones.html', $this->user->lang('ADR_ZONES'));
    }

    protected function _travel($user_id, $dest_name, $cost, $adr_user)
    {
        if ($this->config['zone_dead_travel'] && $adr_user['character_hp'] < 1)
        {
            trigger_error($this->user->lang('ADR_ZONE_CHANGE_DEAD') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
        }

        $dest_name_safe = $this->db->sql_escape($dest_name);
        $sql = 'SELECT * FROM ' . $this->manager->zones_table() . " WHERE zone_name = '$dest_name_safe'";
        $result = $this->db->sql_query($sql);
        $dest_zone = $this->db->sql_fetchrow($result);
        $this->db->sql_freeresult($result);

        if (!$dest_zone)
        {
            trigger_error($this->user->lang('ADR_ZONE_CHANGE_UNAVAILABLE') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
        }

        $dest_id      = (int) $dest_zone['zone_id'];
        $required_item = $dest_zone['zone_item'];

        if ($required_item && $required_item !== '0')
        {
            $uid_safe = (int) $user_id;
            $item_safe = $this->db->sql_escape($required_item);
            $sql = "SELECT item_id FROM " . $this->manager->items_table() . "
                WHERE item_name = '$item_safe' AND item_owner_id = $uid_safe
                AND item_in_shop = 0 AND item_in_warehouse = 0";
            $result = $this->db->sql_query($sql);
            $item_check = $this->db->sql_fetchrow($result);
            $this->db->sql_freeresult($result);

            if (!$item_check)
            {
                trigger_error($this->user->lang('ADR_ZONE_ITEM_LACK') . ': ' . $required_item . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
            }
        }

        $this->manager->subtract_points($user_id, $cost);

        $sql = 'UPDATE ' . $this->manager->characters_table() . "
            SET character_area = $dest_id WHERE character_id = $user_id";
        $this->db->sql_query($sql);

        trigger_error($this->user->lang('ADR_ZONE_CHANGE_SUCCESS') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
    }

    protected function _run_events($user_id, $zone, $adr_user)
    {
        $chance = (int) $zone['zone_chance'];
        if ($chance < 1) return;

        $roll = rand(1, $chance);
        if ($roll !== 1) return;

        $event = rand(1, 8);

        switch ($event)
        {
            case 1:
                if (!$zone['zone_event1']) return;
                $win = rand((int) $zone['zone_pointwin1'], (int) $zone['zone_pointwin2']);
                $this->manager->add_points($user_id, $win);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/get_money.gif" /><br /><br />' . sprintf($this->user->lang('ADR_ZONE_EVENT_WINPOINT'), $win, $this->config['points_name']) . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 2:
                if (!$zone['zone_event2']) return;
                $loss = rand((int) $zone['zone_pointloss1'], (int) $zone['zone_pointloss2']);
                $user_points = (int) $this->user->data['user_points'];
                if ($loss > $user_points) $loss = (int) ($user_points / 2);
                $this->manager->subtract_points($user_id, $loss);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/loss_money.gif" /><br /><br />' . sprintf($this->user->lang('ADR_ZONE_EVENT_LOSSPOINT'), $loss, $this->config['points_name']) . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 3:
                if (!$zone['zone_event3']) return;
                $sql = 'UPDATE ' . $this->manager->characters_table() . " SET character_hp = character_hp_max WHERE character_id = $user_id";
                $this->db->sql_query($sql);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/fountain_of_youth.gif" /><br /><br />' . $this->user->lang('ADR_ZONE_EVENT_FOUNTAIN_YOUTH') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 4:
                if (!$zone['zone_event4']) return;
                $sql = 'UPDATE ' . $this->manager->characters_table() . " SET character_mp = character_mp_max WHERE character_id = $user_id";
                $this->db->sql_query($sql);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/fountain_of_mana.gif" /><br /><br />' . $this->user->lang('ADR_ZONE_EVENT_FOUNTAIN_MANA') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 5:
                if (!$zone['zone_event5']) return;
                $sql = 'UPDATE ' . $this->manager->characters_table() . " SET character_hp = 1 WHERE character_id = $user_id";
                $this->db->sql_query($sql);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/poisonned.gif" /><br /><br />' . $this->user->lang('ADR_ZONE_EVENT_POISON') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 6:
                if (!$zone['zone_event6']) return;
                $sql = 'UPDATE ' . $this->manager->characters_table() . " SET character_mp = 0 WHERE character_id = $user_id";
                $this->db->sql_query($sql);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/weakness.gif" /><br /><br />' . $this->user->lang('ADR_ZONE_EVENT_WEAKNESS') . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
            case 7:
                if (!$zone['zone_event7']) return;
                $this->_drop_item($user_id, (int) $adr_user['character_area']);
                break;
            case 8:
                if (!$zone['zone_event8']) return;
                $loss = rand((int) $zone['zone_pointloss1'], (int) $zone['zone_pointloss2']);
                $user_points = (int) $this->user->data['user_points'];
                if ($loss > $user_points) $loss = $user_points;
                $this->manager->subtract_points($user_id, $loss);
                trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/ambush.gif" /><br /><br />' . sprintf($this->user->lang('ADR_ZONE_EVENT_AMBUSH'), $loss, $this->config['points_name']) . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
                break;
        }
    }

    protected function _drop_item($user_id, $area_id)
    {
        $sql = 'SELECT * FROM ' . $this->manager->items_table() . "
            WHERE item_owner_id = 1 AND (item_zone = $area_id OR item_zone = 0)
            ORDER BY RAND() LIMIT 1";
        $result = $this->db->sql_query($sql);
        $new_item = $this->db->sql_fetchrow($result);
        $this->db->sql_freeresult($result);

        if (!$new_item) return;

        $sql_ary = [
            'item_owner_id'               => $user_id,
            'item_type_use'               => $new_item['item_type_use'],
            'item_name'                   => $new_item['item_name'],
            'item_desc'                   => $new_item['item_desc'],
            'item_icon'                   => $new_item['item_icon'],
            'item_price'                  => $new_item['item_price'],
            'item_quality'                => $new_item['item_quality'],
            'item_duration'               => $new_item['item_duration'],
            'item_duration_max'           => max($new_item['item_duration_max'], $new_item['item_duration']),
            'item_power'                  => $new_item['item_power'],
            'item_add_power'              => $new_item['item_add_power'],
            'item_mp_use'                 => $new_item['item_mp_use'],
            'item_weight'                 => $new_item['item_weight'],
            'item_auth'                   => 0,
            'item_element'                => $new_item['item_element'],
            'item_element_str_dmg'        => $new_item['item_element_str_dmg'],
            'item_element_same_dmg'       => $new_item['item_element_same_dmg'],
            'item_element_weak_dmg'       => $new_item['item_element_weak_dmg'],
            'item_max_skill'              => $new_item['item_max_skill'],
            'item_sell_back_percentage'   => $new_item['item_sell_back_percentage'],
        ];

        $sql = 'INSERT INTO ' . $this->manager->items_table() . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
        $this->db->sql_query($sql);

        $img_url = generate_board_url() . '/ext/adr/rpg/images/items/' . $new_item['item_icon'];
        trigger_error('<img src="' . generate_board_url() . '/ext/adr/rpg/images/zones/get_item.gif" /><br /><br />' . $this->user->lang('ADR_ZONE_EVENT_ITEM') . '<br /><br /><b>' . $new_item['item_name'] . '</b><br /><br /><img src="' . $img_url . '" /><br /><br />' . $new_item['item_desc'] . '<br /><br />' . sprintf($this->user->lang('RETURN_TO'), '<a href="' . $this->helper->route('adr_rpg_zones') . '">' . $this->user->lang('ADR_ZONES') . '</a>'));
    }

    protected function _season_folder($season)
    {
        $map = [1 => '1', 2 => '2', 3 => '3', 4 => '4'];
        return $map[$season] ?? '1';
    }
}
