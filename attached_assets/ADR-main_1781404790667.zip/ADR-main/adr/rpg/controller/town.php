<?php
namespace adr\rpg\controller;

class town
{
	protected $config, $db, $user, $template, $helper, $request, $auth, $root_path, $php_ext, $manager;

	public function __construct(
		\phpbb\config\config $config, \phpbb\db\driver\driver_interface $db,
		\phpbb\user $user, \phpbb\template\template $template,
		\phpbb\controller\helper $helper, \phpbb\request\request $request,
		\phpbb\auth\auth $auth, $root_path, $php_ext,
		\adr\rpg\service\manager $manager
	) {
		$this->config = $config; $this->db = $db; $this->user = $user;
		$this->template = $template; $this->helper = $helper;
		$this->request = $request; $this->auth = $auth;
		$this->root_path = $root_path; $this->php_ext = $php_ext;
		$this->manager = $manager;
	}

	public function index()
	{
		if (!$this->user->data['is_registered'])
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_ADR'));
		}

		$user_id = (int) $this->user->data['user_id'];

		if (!$this->manager->character_exists($user_id))
		{
			redirect($this->helper->route('adr_rpg_character_create'));
		}

		if ($this->manager->is_in_jail($user_id))
		{
			redirect($this->helper->route('adr_rpg_cell'));
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		$mode      = $this->request->variable('mode', '');
		$character = $this->manager->get_user_character($user_id);

		if ($mode === 'training' && $this->request->is_set_post('submit'))
		{
			$this->handle_training($user_id, $character);
			$character = $this->manager->get_user_character($user_id);
		}

		$this->template->assign_vars([
			'CHARACTER'     => $character,
			'MODE'          => $mode,
			'U_ACTION'      => $this->helper->route('adr_rpg_town'),
			'U_BATTLE'      => $this->helper->route('adr_rpg_battle'),
			'U_SHOPS'       => $this->helper->route('adr_rpg_shops'),
			'U_VAULT'       => $this->config['adr_vault_enable'] ? $this->helper->route('adr_rpg_vault') : '',
			'U_TEMPLE'      => $this->config['adr_temple_enable'] ? $this->helper->route('adr_rpg_temple') : '',
			'U_FORGE'       => $this->config['adr_forge_enable'] ? $this->helper->route('adr_rpg_forge') : '',
			'U_COURTHOUSE'  => $this->config['adr_jail_enable'] ? $this->helper->route('adr_rpg_courthouse') : '',
			'U_CHARACTER'   => $this->helper->route('adr_rpg_character'),
			'U_TRAINING'    => $this->helper->route('adr_rpg_town') . '?mode=training',
			'BATTLE_ENABLE' => $this->config['adr_battle_enable'],
			'SHOP_ENABLE'   => $this->config['adr_shop_enable'],
			'VAULT_ENABLE'  => $this->config['adr_vault_enable'],
			'TEMPLE_ENABLE' => $this->config['adr_temple_enable'],
			'FORGE_ENABLE'  => $this->config['adr_forge_enable'],
			'JAIL_ENABLE'   => $this->config['adr_jail_enable'],
		]);

		return $this->helper->render('@adr_rpg/adr_town.html', $this->user->lang('ADR_TOWN'));
	}

	protected function handle_training($user_id, $character)
	{
		$skill = $this->request->variable('skill', '');

		$allowed = ['character_skill_mining', 'character_skill_stone', 'character_skill_forge', 'character_skill_enchantment'];
		if (!in_array($skill, $allowed))
		{
			return;
		}

		$skills      = $this->manager->get_skills();
		$skill_index = array_search(str_replace('character_skill_', '', $skill), array_column($skills, 'skill_name'));

		$skill_obj = $skills[$skill_index] ?? null;
		if (!$skill_obj)
		{
			return;
		}

		$chance = (int) $skill_obj['skill_chance'];

		if (rand(1, 100) <= $chance)
		{
			$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
				SET ' . $skill . ' = ' . $skill . ' + 1
				WHERE character_id = ' . $user_id);
			$this->template->assign_var('TRAINING_SUCCESS', true);
		}
		else
		{
			$this->template->assign_var('TRAINING_SUCCESS', false);
		}
	}
}
