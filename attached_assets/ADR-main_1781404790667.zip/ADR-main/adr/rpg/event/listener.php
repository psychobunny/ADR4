<?php
namespace adr\rpg\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $config;
	protected $db;
	protected $user;
	protected $auth;
	protected $template;
	protected $helper;
	protected $manager;
	protected $topic_character_cache = [];

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		\phpbb\template\template $template,
		\phpbb\controller\helper $helper,
		\adr\rpg\service\manager $manager
	)
	{
		$this->config   = $config;
		$this->db       = $db;
		$this->user     = $user;
		$this->auth     = $auth;
		$this->template = $template;
		$this->helper   = $helper;
		$this->manager  = $manager;
	}

	public static function getSubscribedEvents()
	{
		return [
			'core.posting_modify_submit_post_before'    => 'award_xp_for_post',
			'core.posting_modify_submit_post_after'     => 'post_rewards_success_message',
			'core.viewtopic_modify_post_data'           => 'add_rpg_data_to_posts',
			'core.viewtopic_modify_post_row'            => 'add_rpg_data_to_post_row',
			'core.memberlist_view_profile'              => 'show_character_in_profile',
			'core.page_header'                          => 'add_rpg_nav_links',
			'core.user_delete_after'                    => 'delete_character_on_user_delete',
		];
	}

	public function award_xp_for_post($event)
	{
		if (!$this->config['adr_enabled'])
		{
			return;
		}

		$user_id = (int) $this->user->data['user_id'];
		if (!$user_id || $user_id == ANONYMOUS)
		{
			return;
		}

		$mode = $event['mode'];
		$xp_mode = '';

		if ($mode === 'post')
		{
			$xp_mode = 'newtopic';
		}
		else if ($mode === 'reply')
		{
			$xp_mode = 'reply';
		}
		else if ($mode === 'edit')
		{
			$xp_mode = 'editpost';
		}

		if ($xp_mode)
		{
			$this->manager->add_experience($user_id, $xp_mode);

			// Gold rewards: based on (non-tag) post length.
			$post_message = (string) (($event['data']['message'] ?? '') ?: '');
			$post_length = mb_strlen(strip_tags($post_message));

			// 1 gold per 100 characters (minimum 0).
			$gold_reward = max(0, (int) floor($post_length / 100));
			if ($gold_reward > 0)
			{
				$this->db->sql_query('UPDATE ' . $this->manager->get_table('characters') . '
						SET character_gold = character_gold + ' . $gold_reward . '
						WHERE character_id = ' . $user_id);
			}
		}
	}

	public function post_rewards_success_message($event)
	{
		if (!$this->config['adr_enabled'])
		{
			return;
		}

		$user_id = (int) $this->user->data['user_id'];
		if (!$user_id || $user_id == ANONYMOUS)
		{
			return;
		}

		$this->user->add_lang_ext('adr/rpg', 'common');
		$data = $event['data'] ?? [];
		$forum_id = (int) ($data['forum_id'] ?? 0);

		// If phpBB requires post approval, let phpBB show its own message.
		if ((!$this->auth->acl_get('f_noapprove', $forum_id) && empty($data['force_approved_state'])) ||
			(isset($data['force_approved_state']) && !$data['force_approved_state']))
		{
			return;
		}

		$mode = $event['mode'] ?? '';
		$xp_mode = '';
		if ($mode === 'post')
		{
			$xp_mode = 'newtopic';
		}
		else if ($mode === 'reply')
		{
			$xp_mode = 'reply';
		}
		else if ($mode === 'edit')
		{
			$xp_mode = 'editpost';
		}

		if (!$xp_mode)
		{
			return;
		}

		// Compute what we awarded in `award_xp_for_post`.
		switch ($xp_mode)
		{
			case 'newtopic':
				$xp_reward = (int) $this->config['adr_experience_for_new'];
			break;
			case 'reply':
				$xp_reward = (int) $this->config['adr_experience_for_reply'];
			break;
			case 'editpost':
				$xp_reward = (int) $this->config['adr_experience_for_edit'];
			break;
			default:
				return;
		}

		$post_message = (string) (($event['data']['message'] ?? '') ?: '');
		$post_length = mb_strlen(strip_tags($post_message));
		$gold_reward = max(0, (int) floor($post_length / 100));

		if ($xp_reward <= 0 && $gold_reward <= 0)
		{
			return;
		}

		$redirect_url = $event['redirect_url'] ?? '';
		$message = sprintf(
			$this->user->lang('ADR_POST_XP_GOLD_SUCCESS'),
			$xp_reward,
			$gold_reward
		);

		if ($redirect_url)
		{
			$message .= '<br /><br />' . sprintf(
				$this->user->lang('RETURN_FORUM'),
				'<a href="' . $redirect_url . '">',
				'</a>'
			);
		}

		// Show a success message with totals after the post is stored.
		trigger_error($message);
	}

	public function add_rpg_data_to_posts($event)
	{
		if (!$this->config['adr_enabled'] || !$this->config['adr_topics_display'])
		{
			return;
		}

		$poster_ids = $event['poster_ids'];
		if (empty($poster_ids))
		{
			return;
		}

		$sql = 'SELECT c.character_id, c.character_level,
					r.race_name, r.race_img,
					cl.class_name, cl.class_img,
					a.alignment_name, a.alignment_img,
					e.element_name, e.element_img
				FROM ' . $this->manager->get_table('characters') . ' c
				LEFT JOIN ' . $this->manager->get_table('races') . ' r ON r.race_id = c.character_race
				LEFT JOIN ' . $this->manager->get_table('classes') . ' cl ON cl.class_id = c.character_class
				LEFT JOIN ' . $this->manager->get_table('alignments') . ' a ON a.alignment_id = c.character_alignment
				LEFT JOIN ' . $this->manager->get_table('elements') . ' e ON e.element_id = c.character_element
				WHERE ' . $this->db->sql_in_set('c.character_id', array_map('intval', $poster_ids));

		$result = $this->db->sql_query($sql);
		$char_data = [];
		while ($row = $this->db->sql_fetchrow($result))
		{
			$char_data[$row['character_id']] = $row;
		}
		$this->db->sql_freeresult($result);

		$post_data = $event['post_data'];
		foreach ($post_data as $post_id => &$post)
		{
			$uid = (int) $post['poster_id'];
			if (isset($char_data[$uid]))
			{
				$c = $char_data[$uid];
				$post['adr_level']          = $c['character_level'];
				$post['adr_race']           = $c['race_name'];
				$post['adr_race_img']       = $c['race_img'];
				$post['adr_class']          = $c['class_name'];
				$post['adr_class_img']      = $c['class_img'];
				$post['adr_alignment']      = $c['alignment_name'];
				$post['adr_alignment_img']  = $c['alignment_img'];
				$post['adr_element']        = $c['element_name'];
				$post['adr_element_img']    = $c['element_img'];
				$post['adr_character_url']  = $this->helper->route('adr_rpg_character_view', ['user_id' => $uid]);
			}
		}
		$event['post_data'] = $post_data;
	}

	public function add_rpg_data_to_post_row($event)
	{
		if (!$this->config['adr_enabled'] || !$this->config['adr_topics_display'])
		{
			return;
		}

		$row = $event['row'];
		$poster_id = isset($row['poster_id']) ? (int) $row['poster_id'] : (int) ($event['poster_id'] ?? 0);
		if (!$poster_id || $poster_id == ANONYMOUS)
		{
			return;
		}

		$character = $this->get_topic_character($poster_id);
		if (!$character)
		{
			return;
		}

		$post_row = $event['post_row'];
		$post_row = array_merge($post_row, [
			'ADR_SHOW'          => true,
			'ADR_LEVEL'         => (int) $character['character_level'],
			'ADR_HP'            => (int) $character['character_hp'],
			'ADR_HP_MAX'        => (int) $character['character_hp_max'],
			'ADR_MP'            => (int) $character['character_mp'],
			'ADR_MP_MAX'        => (int) $character['character_mp_max'],
			'ADR_RACE'          => $character['race_name'],
			'ADR_RACE_IMG'      => $character['race_img'],
			'ADR_CLASS'         => $character['class_name'],
			'ADR_CLASS_IMG'     => $character['class_img'],
			'ADR_ALIGNMENT'     => $character['alignment_name'],
			'ADR_ALIGNMENT_IMG' => $character['alignment_img'],
			'ADR_ELEMENT'       => $character['element_name'],
			'ADR_ELEMENT_IMG'   => $character['element_img'],
			'U_ADR_CHARACTER'   => $this->helper->route('adr_rpg_character_view', ['user_id' => $poster_id]),
		]);

		$event['post_row'] = $post_row;
	}

	protected function get_topic_character($user_id)
	{
		$user_id = (int) $user_id;
		if (!array_key_exists($user_id, $this->topic_character_cache))
		{
			$this->topic_character_cache[$user_id] = $this->manager->get_user_character($user_id) ?: false;
		}

		return $this->topic_character_cache[$user_id];
	}

	public function show_character_in_profile($event)
	{
		if (!$this->config['adr_enabled'] || !$this->config['adr_profile_display'])
		{
			return;
		}

		$member = $event['member'];
		$user_id = (int) $member['user_id'];

		if (!$this->manager->character_exists($user_id))
		{
			return;
		}

		$character = $this->manager->get_user_character($user_id);

		$this->template->assign_vars([
			'ADR_PROFILE_SHOW'       => true,
			'ADR_PROFILE_LEVEL'      => $character['character_level'],
			'ADR_PROFILE_HP'         => $character['character_hp'],
			'ADR_PROFILE_HP_MAX'     => $character['character_hp_max'],
			'ADR_PROFILE_MP'         => $character['character_mp'],
			'ADR_PROFILE_MP_MAX'     => $character['character_mp_max'],
			'ADR_PROFILE_RACE'       => $character['race_name'],
			'ADR_PROFILE_RACE_IMG'   => $character['race_img'],
			'ADR_PROFILE_CLASS'      => $character['class_name'],
			'ADR_PROFILE_CLASS_IMG'  => $character['class_img'],
			'ADR_PROFILE_ALIGN'      => $character['alignment_name'],
			'ADR_PROFILE_ALIGN_IMG'  => $character['alignment_img'],
			'ADR_PROFILE_ELEMENT'    => $character['element_name'],
			'ADR_PROFILE_ELEMENT_IMG'=> $character['element_img'],
			'ADR_PROFILE_URL'        => $this->helper->route('adr_rpg_character_view', ['user_id' => $user_id]),
		]);
	}

	public function add_rpg_nav_links($event)
	{
		if (!$this->config['adr_enabled'])
		{
			return;
		}

		$this->user->add_lang_ext('adr/rpg', 'common');

		$this->template->assign_vars([
			'ADR_ENABLED'    => true,
			'U_ADR'          => $this->helper->route('adr_rpg_character'),
			'L_ADR'          => $this->user->lang('ADR_RPG'),
			'U_ADR_TOWN'     => $this->helper->route('adr_rpg_town'),
			'U_ADR_CHARACTER'=> $this->helper->route('adr_rpg_character'),
			'U_ADR_BATTLE'   => $this->config['adr_battle_enable'] ? $this->helper->route('adr_rpg_battle') : '',
			'U_ADR_SHOP'     => $this->config['adr_shop_enable'] ? $this->helper->route('adr_rpg_shops') : '',
			'U_ADR_VAULT'    => $this->config['adr_vault_enable'] ? $this->helper->route('adr_rpg_vault') : '',
			'U_ADR_CHARS'    => $this->helper->route('adr_rpg_character_list'),
		]);
	}

	public function delete_character_on_user_delete($event)
	{
		$user_id = (int) $event['user_id'];
		if ($user_id)
		{
			$this->manager->delete_character($user_id);
		}
	}
}
