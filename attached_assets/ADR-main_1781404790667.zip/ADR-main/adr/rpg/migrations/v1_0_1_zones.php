<?php

namespace adr\rpg\migrations;

class v1_0_1_zones extends \phpbb\db\migration\migration
{
    public function effectively_installed()
    {
        return $this->db_tools->sql_table_exists($this->table_prefix . 'adr_zones');
    }

    public static function depends_on()
    {
        return ['\adr\rpg\migrations\v0_4_5_install'];
    }

    public function update_schema()
    {
        return [
            'add_tables' => [
                $this->table_prefix . 'adr_zones' => [
                    'COLUMNS' => [
                        'zone_id'           => ['UINT', null, 'auto_increment'],
                        'zone_name'         => ['VCHAR:255', ''],
                        'zone_desc'         => ['VCHAR:255', ''],
                        'zone_img'          => ['VCHAR:255', ''],
                        'zone_element'      => ['VCHAR:50', ''],
                        'zone_item'         => ['VCHAR:255', '0'],
                        'goto1_name'        => ['VCHAR:255', ''],
                        'goto2_name'        => ['VCHAR:255', ''],
                        'return_name'       => ['VCHAR:255', ''],
                        'cost_goto1'        => ['UINT', 0],
                        'cost_goto2'        => ['UINT', 0],
                        'cost_return'       => ['UINT', 0],
                        'zone_shops'        => ['BOOL', 0],
                        'zone_forge'        => ['BOOL', 0],
                        'zone_temple'       => ['BOOL', 0],
                        'zone_prison'       => ['BOOL', 0],
                        'zone_bank'         => ['BOOL', 0],
                        'zone_chance'       => ['UINT', 10],
                        'zone_pointwin1'    => ['UINT', 0],
                        'zone_pointwin2'    => ['UINT', 0],
                        'zone_pointloss1'   => ['UINT', 0],
                        'zone_pointloss2'   => ['UINT', 0],
                        'zone_event1'       => ['BOOL', 0],
                        'zone_event2'       => ['BOOL', 0],
                        'zone_event3'       => ['BOOL', 0],
                        'zone_event4'       => ['BOOL', 0],
                        'zone_event5'       => ['BOOL', 0],
                        'zone_event6'       => ['BOOL', 0],
                        'zone_event7'       => ['BOOL', 0],
                        'zone_event8'       => ['BOOL', 0],
                        'npc1_enable'       => ['BOOL', 0],
                        'npc2_enable'       => ['BOOL', 0],
                        'npc3_enable'       => ['BOOL', 0],
                        'npc4_enable'       => ['BOOL', 0],
                        'npc5_enable'       => ['BOOL', 0],
                        'npc_price'         => ['UINT', 0],
                        'npc1_message'      => ['TEXT_UNI', ''],
                        'npc2_message'      => ['TEXT_UNI', ''],
                        'npc3_message'      => ['TEXT_UNI', ''],
                        'npc4_message'      => ['TEXT_UNI', ''],
                        'npc5_message'      => ['TEXT_UNI', ''],
                    ],
                    'PRIMARY_KEY' => 'zone_id',
                ],
            ],
        ];
    }

    public function revert_schema()
    {
        return [
            'drop_tables' => [
                $this->table_prefix . 'adr_zones',
            ],
        ];
    }

    public function update_data()
    {
        return [
            ['config.add', ['adr_seasons', '1']],
            ['config.add', ['adr_seasons_time', '604800']],
            ['config.add', ['adr_seasons_last_time', '0']],
            ['config.add', ['zone_dead_travel', '0']],
            ['config.add', ['zone_bonus_enable', '0']],
            ['config.add', ['zone_bonus_att', '0']],
            ['config.add', ['zone_bonus_def', '0']],
            ['custom', [[$this, 'insert_default_zone']]],
        ];
    }

    public function insert_default_zone()
    {
        $sql = 'INSERT INTO ' . $this->table_prefix . 'adr_zones
            (zone_name, zone_desc, zone_img, zone_element, zone_item,
             goto1_name, goto2_name, return_name,
             cost_goto1, cost_goto2, cost_return,
             zone_shops, zone_forge, zone_temple, zone_prison, zone_bank,
             zone_chance, zone_pointwin1, zone_pointwin2,
             zone_pointloss1, zone_pointloss2,
             zone_event1, zone_event2, zone_event3, zone_event4,
             zone_event5, zone_event6, zone_event7, zone_event8,
             npc1_enable, npc2_enable, npc3_enable, npc4_enable, npc5_enable,
             npc_price, npc1_message, npc2_message, npc3_message, npc4_message, npc5_message)
            VALUES
            (\'The Imperial City\', \'The capital city on the island in Lake Rumare. It is split into 12 districts.\', \'imperialcity.jpg\', \'Earth\', \'0\',
             \'\', \'\', \'\',
             0, 0, 0,
             1, 1, 1, 1, 1,
             10, 5, 20,
             2, 10,
             1, 1, 1, 1,
             1, 1, 1, 1,
             0, 0, 0, 0, 0,
             5, \'\', \'\', \'\', \'\', \'\')';
        $this->db->sql_query($sql);

        $sql = 'ALTER TABLE ' . $this->table_prefix . 'adr_characters ADD COLUMN character_area INT;';
        $this->db->sql_query($sql);


        $sql = 'UPDATE ' . $this->table_prefix . 'adr_characters SET character_area = 1';
        $this->db->sql_query($sql);
    }
}
