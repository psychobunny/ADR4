<?php
namespace adr\rpg\migrations;

class v3_0_1_acp_items_module extends \phpbb\db\migration\migration
{
	public static function depends_on()
	{
		return ['\adr\rpg\migrations\v3_0_0_acp_modules'];
	}

	public function update_data()
	{
		return [
			['module.add', [
				'acp',
				'ACP_ADR_TITLE',
				[
					'module_basename' => '\adr\rpg\acp\main_module',
					'modes'           => ['items'],
				],
			]],
		];
	}
}
