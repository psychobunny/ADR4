<?php
namespace adr\rpg\migrations;

class v3_0_0_acp_modules extends \phpbb\db\migration\migration
{
    public static function depends_on()
    {
        // This ensures the tables exist before we try to add the modules
        return ['\adr\rpg\migrations\v0_4_5_install'];
    }

    public function update_data()
    {
        return [
            // 1. Create the Main Category (Tab/Heading)
            ['module.add', [
                'acp',
                'ACP_CAT_DOT_MODS', // Adds it to the "Extensions" tab
                'ACP_ADR_TITLE'
            ]],

            // 2. Add all the modes from your main_info.php
            ['module.add', [
                'acp',
                'ACP_ADR_TITLE',
                [
                    'module_basename' => '\adr\rpg\acp\main_module',
                    'modes'           => [
                        'general', 'races', 'classes', 'alignments', 
                        'elements', 'monsters', 'skills', 'item_types',
                        'stores', 'vault_exchange', 'users', 'jailed_users', 'tools',
                        'zones', 'seasons', 'zone_general'
                    ],
                ],
            ]],
        ];
    }
}
