<?php
namespace adr\rpg\migrations;

class v0_4_5_install extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return $this->db_tools->sql_table_exists($this->table_prefix . 'adr_characters');
	}

	public static function depends_on()
	{
		return [];
	}

	public function update_schema()
	{
		return [
			'add_tables' => [
				$this->table_prefix . 'adr_alignments' => [
					'COLUMNS' => [
						'alignment_id'    => ['UINT', null, 'auto_increment'],
						'alignment_name'  => ['VCHAR:255', ''],
						'alignment_desc'  => ['TEXT', ''],
						'alignment_level' => ['TINT:1', 0],
						'alignment_img'   => ['VCHAR:255', ''],
					],
					'PRIMARY_KEY' => 'alignment_id',
				],
				$this->table_prefix . 'adr_races' => [
					'COLUMNS' => [
						'race_id'                    => ['UINT', null, 'auto_increment'],
						'race_name'                  => ['VCHAR:255', ''],
						'race_desc'                  => ['TEXT', ''],
						'race_level'                 => ['TINT:1', 0],
						'race_img'                   => ['VCHAR:255', ''],
						'race_might_bonus'           => ['INT:8', 0],
						'race_dexterity_bonus'       => ['INT:8', 0],
						'race_constitution_bonus'    => ['INT:8', 0],
						'race_intelligence_bonus'    => ['INT:8', 0],
						'race_wisdom_bonus'          => ['INT:8', 0],
						'race_charisma_bonus'        => ['INT:8', 0],
						'race_hp_bonus'              => ['INT:8', 0],
						'race_mp_bonus'              => ['INT:8', 0],
						'race_weight'                => ['INT:8', 100],
						'race_weight_per_level'      => ['INT:8', 10],
					],
					'PRIMARY_KEY' => 'race_id',
				],
				$this->table_prefix . 'adr_classes' => [
					'COLUMNS' => [
						'class_id'               => ['UINT', null, 'auto_increment'],
						'class_name'             => ['VCHAR:255', ''],
						'class_desc'             => ['TEXT', ''],
						'class_level'            => ['TINT:1', 0],
						'class_img'              => ['VCHAR:255', ''],
						'class_might_req'        => ['INT:8', 0],
						'class_dexterity_req'    => ['INT:8', 0],
						'class_constitution_req' => ['INT:8', 0],
						'class_intelligence_req' => ['INT:8', 0],
						'class_wisdom_req'       => ['INT:8', 0],
						'class_charisma_req'     => ['INT:8', 0],
						'class_hp_base'          => ['INT:8', 10],
						'class_mp_base'          => ['INT:8', 10],
						'class_hp_per_level'     => ['INT:8', 5],
						'class_mp_per_level'     => ['INT:8', 5],
						'class_update_xp_req'    => ['INT:8', 100],
						'class_ac_bonus'         => ['INT:8', 0],
						'class_thief_class'      => ['TINT:1', 0],
					],
					'PRIMARY_KEY' => 'class_id',
				],
				$this->table_prefix . 'adr_elements' => [
					'COLUMNS' => [
						'element_id'                    => ['UINT', null, 'auto_increment'],
						'element_name'                  => ['VCHAR:255', ''],
						'element_desc'                  => ['TEXT', ''],
						'element_level'                 => ['TINT:1', 0],
						'element_img'                   => ['VCHAR:255', ''],
						'element_skill_mining_bonus'    => ['INT:8', 0],
						'element_skill_stone_bonus'     => ['INT:8', 0],
						'element_skill_forge_bonus'     => ['INT:8', 0],
						'element_skill_enchant_bonus' => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'element_id',
				],
				$this->table_prefix . 'adr_skills' => [
					'COLUMNS' => [
						'skill_id'     => ['UINT', null, 'auto_increment'],
						'skill_name'   => ['VCHAR:255', ''],
						'skill_desc'   => ['TEXT', ''],
						'skill_img'    => ['VCHAR:255', ''],
						'skill_req'    => ['INT:8', 0],
						'skill_chance' => ['INT:8', 5],
					],
					'PRIMARY_KEY' => 'skill_id',
				],
				$this->table_prefix . 'adr_characters' => [
					'COLUMNS' => [
						'character_id'             => ['UINT', 0],
						'character_name'           => ['VCHAR:255', ''],
						'character_desc'           => ['TEXT', ''],
						'character_race'           => ['INT:8', 0],
						'character_class'          => ['INT:8', 0],
						'character_alignment'      => ['INT:8', 0],
						'character_element'        => ['INT:8', 0],
						'character_hp'             => ['INT:8', 0],
						'character_hp_max'         => ['INT:8', 0],
						'character_mp'             => ['INT:8', 0],
						'character_mp_max'         => ['INT:8', 0],
						'character_xp'             => ['INT:8', 0],
						'character_level'          => ['INT:8', 1],
						'character_might'          => ['INT:8', 1],
						'character_dexterity'      => ['INT:8', 1],
						'character_constitution'   => ['INT:8', 1],
						'character_intelligence'   => ['INT:8', 1],
						'character_wisdom'         => ['INT:8', 1],
						'character_charisma'       => ['INT:8', 1],
						'character_ac'             => ['INT:8', 0],
						'character_weight'         => ['INT:8', 0],
						'character_weight_max'     => ['INT:8', 100],
						'character_gold'           => ['INT:8', 0],
						'character_points'         => ['INT:8', 0],
						'character_sp'             => ['INT:8', 0],
						'character_skill_mining'   => ['INT:8', 0],
						'character_skill_stone'    => ['INT:8', 0],
						'character_skill_forge'    => ['INT:8', 0],
						'character_skill_enchantment' => ['INT:8', 0],
						'character_skill_thief'    => ['INT:8', 0],
						'character_banned'         => ['TINT:1', 0],
						'character_banned_expire'  => ['INT:11', 0],
						'character_creation_date'  => ['INT:11', 0],
					],
					'PRIMARY_KEY' => 'character_id',
				],
				$this->table_prefix . 'adr_battle_monsters' => [
					'COLUMNS' => [
						'monster_id'           => ['UINT', null, 'auto_increment'],
						'monster_name'         => ['VCHAR:255', ''],
						'monster_img'          => ['VCHAR:255', ''],
						'monster_level'        => ['INT:8', 0],
						'monster_base_hp'      => ['INT:8', 0],
						'monster_base_att'     => ['INT:8', 0],
						'monster_base_def'     => ['INT:8', 0],
						'monster_base_mp'      => ['INT:8', 10],
						'monster_base_mp_power'=> ['INT:8', 1],
						'monster_base_magic_def' => ['INT:8', 0],
						'monster_xp_reward'    => ['INT:8', 0],
						'monster_gold_reward'  => ['INT:8', 0],
						'monster_item_reward'  => ['INT:8', 0],
						'monster_min_level'    => ['INT:8', 0],
						'monster_max_level'    => ['INT:8', 0],
						'monster_element'      => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'monster_id',
				],
				$this->table_prefix . 'adr_battle_list' => [
					'COLUMNS' => [
						'battle_id'                         => ['UINT:8', null, 'auto_increment'],
						'battle_type'                       => ['TINT:1', 0],
						'battle_turn'                       => ['TINT:1', 0],
						'battle_result'                     => ['TINT:1', 0],
						'battle_text'                       => ['TEXT', ''],
						'battle_challenger_equip_info'  => ['VCHAR:255', ''],
						'battle_round'                      => ['INT:12', 0],
						'battle_start'                      => ['INT:12', 0],
						'battle_finish'                     => ['INT:12', 0],
						'battle_challenger_id'              => ['INT:8', 0],
						'battle_monster_id'                 => ['INT:8', 0],
						'battle_challenger_hp'              => ['INT:8', 0],
						'battle_challenger_hp_max'          => ['INT:8', 0],
						'battle_challenger_mp'              => ['INT:8', 0],
						'battle_monster_hp'                 => ['INT:8', 0],
						'battle_monster_hp_max'             => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'battle_id',
				],
				$this->table_prefix . 'adr_battle_pvp' => [
					'COLUMNS' => [
						'battle_id'              => ['UINT:8', null, 'auto_increment'],
						'battle_turn'            => ['INT:8', 0],
						'battle_result'          => ['TINT:1', 0],
						'battle_text'            => ['TEXT', ''],
						'battle_text_chat'       => ['TEXT', ''],
						'battle_start'           => ['INT:12', 0],
						'battle_finish'          => ['INT:12', 0],
						'battle_challenger_id'   => ['INT:8', 0],
						'battle_challenger_att'  => ['INT:8', 0],
						'battle_challenger_def'  => ['INT:8', 0],
						'battle_challenger_hp'   => ['INT:8', 0],
						'battle_challenger_hp_max' => ['INT:8', 0],
						'battle_challenged_id'   => ['INT:8', 0],
						'battle_challenged_att'  => ['INT:8', 0],
						'battle_challenged_def'  => ['INT:8', 0],
						'battle_challenged_hp'   => ['INT:8', 0],
						'battle_challenged_hp_max' => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'battle_id',
				],
				$this->table_prefix . 'adr_battle_community' => [
					'COLUMNS' => [
						'chat_id'    => ['UINT:10', null, 'auto_increment'],
						'chat_posts' => ['INT:10', 0],
						'chat_text'  => ['TEXT', ''],
						'chat_date'  => ['TIMESTAMP', 0],
					],
					'PRIMARY_KEY' => 'chat_id',
				],
				$this->table_prefix . 'adr_shops' => [
					'COLUMNS' => [
						'shop_id'           => ['UINT:8', 0],
						'shop_owner_id'     => ['INT:8', 0],
						'shop_name'         => ['VCHAR:255', ''],
						'shop_desc'         => ['VCHAR:255', ''],
						'shop_logo'         => ['VCHAR:255', ''],
						'shop_last_updated' => ['INT:12', 0],
					],
					'PRIMARY_KEY' => 'shop_id',
				],
				$this->table_prefix . 'adr_shops_items' => [
					'COLUMNS' => [
						'item_id'                   => ['UINT:8', null, 'auto_increment'],
						'item_owner_id'             => ['INT:8', 0],
						'item_price'                => ['INT:8', 0],
						'item_quality'              => ['INT:8', 0],
						'item_power'                => ['INT:8', 0],
						'item_duration'             => ['INT:8', 0],
						'item_duration_max'         => ['INT:8', 1],
						'item_icon'                 => ['VCHAR:255', ''],
						'item_name'                 => ['VCHAR:255', ''],
						'item_desc'                 => ['VCHAR:255', ''],
						'item_type'                 => ['INT:8', 0],
						'item_ac'                   => ['INT:8', 0],
						'item_in_shop'              => ['TINT:1', 0],
						'item_in_warehouse'         => ['TINT:1', 0],
						'item_equipped'             => ['TINT:1', 0],
						'item_equip_slot'           => ['VCHAR:50', ''],
						'item_weight'               => ['INT:8', 0],
						'item_restrict_class'       => ['VCHAR:255', ''],
						'item_restrict_class_enable'=> ['TINT:1', 0],
						'item_restrict_race'        => ['VCHAR:255', ''],
						'item_restrict_race_enable' => ['TINT:1', 0],
						'item_restrict_align'       => ['VCHAR:255', ''],
						'item_restrict_align_enable'=> ['TINT:1', 0],
						'item_restrict_element'     => ['VCHAR:255', ''],
						'item_restrict_element_enable' => ['TINT:1', 0],
						'item_restrict_level'       => ['INT:8', 0],
						'item_restrict_str'         => ['INT:8', 0],
						'item_restrict_dex'         => ['INT:8', 0],
						'item_restrict_con'         => ['INT:8', 0],
						'item_restrict_int'         => ['INT:8', 0],
						'item_restrict_wis'         => ['INT:8', 0],
						'item_restrict_cha'         => ['INT:8', 0],
						'item_forge_material'       => ['INT:8', 0],
						'item_forge_level'          => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'item_id',
				],
				$this->table_prefix . 'adr_shops_items_type' => [
					'COLUMNS' => [
						'item_type_id'         => ['UINT:8', null, 'auto_increment'],
						'item_type_base_price' => ['INT:8', 0],
						'item_type_lang'       => ['VCHAR:255', ''],
						'item_type_order'      => ['INT:8', 1],
						'item_type_category'   => ['VCHAR:50', ''],
					],
					'PRIMARY_KEY' => 'item_type_id',
				],
				$this->table_prefix . 'adr_shops_items_quality' => [
					'COLUMNS' => [
						'item_quality_id'               => ['UINT:8', 0],
						'item_quality_modifier_price'   => ['INT:8', 0],
						'item_quality_lang'             => ['VCHAR:255', ''],
					],
					'PRIMARY_KEY' => 'item_quality_id',
				],
				$this->table_prefix . 'adr_stores' => [
					'COLUMNS' => [
						'store_id'           => ['UINT:8', null, 'auto_increment'],
						'store_name'         => ['VCHAR:100', ''],
						'store_desc'         => ['VCHAR:255', ''],
						'store_img'          => ['VCHAR:255', ''],
						'store_status'       => ['TINT:1', 1],
						'store_sales_status' => ['TINT:1', 0],
						'store_admin'        => ['TINT:1', 0],
						'store_owner_id'     => ['INT:8', 1],
					],
					'PRIMARY_KEY' => 'store_id',
				],
				$this->table_prefix . 'adr_stores_stats' => [
					'COLUMNS' => [
						'store_stats_character_id'          => ['INT:12', 0],
						'store_stats_store_id'              => ['INT:12', 0],
						'store_stats_buy_total'             => ['INT:12', 0],
						'store_stats_buy_last'              => ['INT:12', 0],
						'store_stats_sold_total'            => ['INT:12', 0],
						'store_stats_sold_last'             => ['INT:12', 0],
						'store_stats_stolen_item_total'     => ['INT:12', 0],
						'store_stats_stolen_item_fail'=> ['INT:12', 0],
					],
				],
				$this->table_prefix . 'adr_stores_user_history' => [
					'COLUMNS' => [
						'user_store_trans_id'   => ['INT:12', 0],
						'user_store_owner_id'   => ['INT:8', 0],
						'user_store_info'       => ['TEXT', ''],
						'user_store_total_price'=> ['INT:12', 0],
						'user_store_date'       => ['INT:12', 0],
						'user_store_buyer'      => ['TEXT', ''],
					],
					'PRIMARY_KEY' => ['user_store_trans_id', 'user_store_owner_id'],
				],
				$this->table_prefix . 'adr_vault_users' => [
					'COLUMNS' => [
						'owner_id'         => ['UINT:8', 0],
						'account_id'       => ['INT:8', 0],
						'account_sum'      => ['INT:8', 0],
						'account_time'     => ['INT:11', 0],
						'loan_sum'         => ['INT:8', 0],
						'loan_time'        => ['INT:11', 0],
						'account_protect'  => ['TINT:1', 0],
						'loan_protect'     => ['TINT:1', 0],
					],
					'PRIMARY_KEY' => 'owner_id',
				],
				$this->table_prefix . 'adr_vault_exchange' => [
					'COLUMNS' => [
						'stock_id'             => ['UINT:8', null, 'auto_increment'],
						'stock_name'           => ['VCHAR:40', ''],
						'stock_desc'           => ['VCHAR:255', ''],
						'stock_price'          => ['INT:8', 0],
						'stock_previous_price' => ['INT:8', 0],
						'stock_best_price'     => ['INT:8', 0],
						'stock_worst_price'    => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'stock_id',
				],
				$this->table_prefix . 'adr_vault_exchange_users' => [
					'COLUMNS' => [
						'stock_id'     => ['INT:8', 0],
						'user_id'      => ['INT:8', 0],
						'stock_amount' => ['INT:8', 0],
					],
					'KEYS' => [
						'stock_id' => ['INDEX', 'stock_id'],
						'user_id'  => ['INDEX', 'user_id'],
					],
				],
				$this->table_prefix . 'adr_vault_blacklist' => [
					'COLUMNS' => [
						'user_id'  => ['UINT:8', 0],
						'user_due' => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'user_id',
				],
				$this->table_prefix . 'adr_jail_users' => [
					'COLUMNS' => [
						'celled_id'       => ['UINT:8', 0],
						'user_id'         => ['INT:8', 0],
						'user_cell_date'  => ['INT:11', 0],
						'user_freed_by'   => ['INT:8', 0],
						'user_sentence'   => ['TEXT', ''],
						'user_caution'    => ['INT:8', 0],
						'user_time'       => ['INT:11', 0],
					],
					'PRIMARY_KEY' => 'celled_id',
				],
				$this->table_prefix . 'adr_jail_votes' => [
					'COLUMNS' => [
						'vote_id'     => ['INT:8', 0],
						'voter_id'    => ['INT:8', 0],
						'vote_result' => ['INT:8', 0],
					],
					'KEYS' => [
						'vote_id'  => ['INDEX', 'vote_id'],
						'voter_id' => ['INDEX', 'voter_id'],
					],
				],
				$this->table_prefix . 'adr_general' => [
					'COLUMNS' => [
						'config_name'  => ['VCHAR:255', ''],
						'config_value' => ['VCHAR:255', ''],
					],
					'PRIMARY_KEY' => 'config_name',
				],
				$this->table_prefix . 'adr_create_exploit_fix' => [
					'COLUMNS' => [
						'user_id'           => ['UINT:10', 0],
						'power'             => ['INT:8', 0],
						'agility'           => ['INT:8', 0],
						'endurance'         => ['INT:8', 0],
						'intelligence'      => ['INT:8', 0],
						'willpower'         => ['INT:8', 0],
						'charm'             => ['INT:8', 0],
						'magic_attack'      => ['INT:8', 0],
						'magic_resistance'  => ['INT:8', 0],
					],
					'PRIMARY_KEY' => 'user_id',
				],
			],
		];
	}

	public function revert_schema()
	{
		return [
			'drop_tables' => [
				$this->table_prefix . 'adr_alignments',
				$this->table_prefix . 'adr_races',
				$this->table_prefix . 'adr_classes',
				$this->table_prefix . 'adr_elements',
				$this->table_prefix . 'adr_skills',
				$this->table_prefix . 'adr_characters',
				$this->table_prefix . 'adr_battle_monsters',
				$this->table_prefix . 'adr_battle_list',
				$this->table_prefix . 'adr_battle_pvp',
				$this->table_prefix . 'adr_battle_community',
				$this->table_prefix . 'adr_shops',
				$this->table_prefix . 'adr_shops_items',
				$this->table_prefix . 'adr_shops_items_type',
				$this->table_prefix . 'adr_shops_items_quality',
				$this->table_prefix . 'adr_stores',
				$this->table_prefix . 'adr_stores_stats',
				$this->table_prefix . 'adr_stores_user_history',
				$this->table_prefix . 'adr_vault_users',
				$this->table_prefix . 'adr_vault_exchange',
				$this->table_prefix . 'adr_vault_exchange_users',
				$this->table_prefix . 'adr_vault_blacklist',
				$this->table_prefix . 'adr_jail_users',
				$this->table_prefix . 'adr_jail_votes',
				$this->table_prefix . 'adr_general',
				$this->table_prefix . 'adr_create_exploit_fix',
			],
		];
	}

	public function update_data()
	{
		return [
			['config.add', ['adr_version', '0.4.5']],
			['config.add', ['adr_enabled', '1']],
			['config.add', ['adr_experience_for_new', '10']],
			['config.add', ['adr_experience_for_reply', '5']],
			['config.add', ['adr_experience_for_edit', '1']],
			['config.add', ['adr_character_age', '16']],
			['config.add', ['adr_skill_sp_enable', '0']],
			['config.add', ['adr_character_sp_enable', '0']],
			['config.add', ['adr_thief_enable', '1']],
			['config.add', ['adr_thief_points', '5']],
			['config.add', ['adr_warehouse_duration', '1']],
			['config.add', ['adr_battle_enable', '1']],
			['config.add', ['adr_pvp_enable', '1']],
			['config.add', ['adr_shop_enable', '1']],
			['config.add', ['adr_vault_enable', '1']],
			['config.add', ['adr_temple_enable', '1']],
			['config.add', ['adr_forge_enable', '1']],
			['config.add', ['adr_jail_enable', '1']],
			['config.add', ['adr_next_level_penalty', '10']],
			['config.add', ['adr_stat_points_per_level', '5']],
			['config.add', ['adr_gold_per_battle', '10']],
			['config.add', ['adr_topics_display', '1']],
			['config.add', ['adr_profile_display', '1']],
			['config.add', ['stock_use', '1']],
			['config.add', ['stock_time', '86400']],
			['config.add', ['stock_last_change', '0']],
			['config.add', ['stock_min_change', '1']],
			['config.add', ['stock_max_change', '10']],
			['custom', [[$this, 'insert_default_data']]],
		];
	}

	public function insert_default_data()
	{
		$defaults = [
			'alignments' => [
				['alignment_id' => 1, 'alignment_name' => 'ADR_ALIGNMENT_NEUTRAL', 'alignment_desc' => 'ADR_ALIGNMENT_NEUTRAL_DESC', 'alignment_level' => 0, 'alignment_img' => 'Neutral.png'],
				['alignment_id' => 2, 'alignment_name' => 'ADR_ALIGNMENT_EVIL', 'alignment_desc' => 'ADR_ALIGNMENT_EVIL_DESC', 'alignment_level' => 0, 'alignment_img' => 'Evil.png'],
				['alignment_id' => 3, 'alignment_name' => 'ADR_ALIGNMENT_GOOD', 'alignment_desc' => 'ADR_ALIGNMENT_GOOD_DESC', 'alignment_level' => 0, 'alignment_img' => 'Good.png'],
			],
			'races' => [
				['race_id' => 1, 'race_name' => 'ADR_RACE_HUMAN', 'race_desc' => 'ADR_RACE_HUMAN_DESC', 'race_level' => 0, 'race_img' => 'Human.png', 'race_might_bonus' => 0, 'race_dexterity_bonus' => 0, 'race_constitution_bonus' => 0, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 0, 'race_charisma_bonus' => 0, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 2, 'race_name' => 'ADR_RACE_HALF-ELF', 'race_desc' => 'ADR_RACE_HALF-ELF_DESC', 'race_level' => 0, 'race_img' => 'Half-elf.png', 'race_might_bonus' => 0, 'race_dexterity_bonus' => 1, 'race_constitution_bonus' => 0, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 0, 'race_charisma_bonus' => 1, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 3, 'race_name' => 'ADR_RACE_HALF-ORC', 'race_desc' => 'ADR_RACE_HALF-ORC_DESC', 'race_level' => 0, 'race_img' => 'Half-orc.png', 'race_might_bonus' => 2, 'race_dexterity_bonus' => 0, 'race_constitution_bonus' => 1, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 0, 'race_charisma_bonus' => 0, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 4, 'race_name' => 'ADR_RACE_ELF', 'race_desc' => 'ADR_RACE_ELF_DESC', 'race_level' => 0, 'race_img' => 'Elf.png', 'race_might_bonus' => 0, 'race_dexterity_bonus' => 2, 'race_constitution_bonus' => 0, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 0, 'race_charisma_bonus' => 2, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 5, 'race_name' => 'ADR_RACE_GNOME', 'race_desc' => 'ADR_RACE_GNOME_DESC', 'race_level' => 0, 'race_img' => 'Gnome.png', 'race_might_bonus' => 0, 'race_dexterity_bonus' => 1, 'race_constitution_bonus' => 0, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 1, 'race_charisma_bonus' => 0, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 6, 'race_name' => 'ADR_RACE_HALFLING', 'race_desc' => 'ADR_RACE_HALFLING_DESC', 'race_level' => 2, 'race_img' => 'Halfeling.png', 'race_might_bonus' => 0, 'race_dexterity_bonus' => 2, 'race_constitution_bonus' => 0, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 2, 'race_charisma_bonus' => 0, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
				['race_id' => 7, 'race_name' => 'ADR_RACE_DWARF', 'race_desc' => 'ADR_RACE_DWARF_DESC', 'race_level' => 0, 'race_img' => 'Dwarf.png', 'race_might_bonus' => 1, 'race_dexterity_bonus' => 0, 'race_constitution_bonus' => 2, 'race_intelligence_bonus' => 0, 'race_wisdom_bonus' => 1, 'race_charisma_bonus' => 0, 'race_hp_bonus' => 0, 'race_mp_bonus' => 0, 'race_weight' => 1000, 'race_weight_per_level' => 5],
			],
			'classes' => [
				['class_id' => 1, 'class_name' => 'ADR_CLASS_FIGHTER', 'class_desc' => 'ADR_CLASS_FIGHTER_DESC', 'class_level' => 0, 'class_img' => 'Fighter.png', 'class_might_req' => 0, 'class_dexterity_req' => 0, 'class_constitution_req' => 0, 'class_intelligence_req' => 0, 'class_wisdom_req' => 0, 'class_charisma_req' => 0, 'class_hp_base' => 30, 'class_mp_base' => 2, 'class_hp_per_level' => 3, 'class_mp_per_level' => 0, 'class_update_xp_req' => 1500, 'class_ac_bonus' => 15, 'class_thief_class' => 0],
				['class_id' => 2, 'class_name' => 'ADR_CLASS_BARBARE', 'class_desc' => 'ADR_CLASS_BARBARE_DESC', 'class_level' => 0, 'class_img' => 'Barbare.png', 'class_might_req' => 12, 'class_dexterity_req' => 0, 'class_constitution_req' => 10, 'class_intelligence_req' => 0, 'class_wisdom_req' => 0, 'class_charisma_req' => 0, 'class_hp_base' => 40, 'class_mp_base' => 1, 'class_hp_per_level' => 4, 'class_mp_per_level' => 0, 'class_update_xp_req' => 2000, 'class_ac_bonus' => 10, 'class_thief_class' => 0],
				['class_id' => 3, 'class_name' => 'ADR_CLASS_DRUID', 'class_desc' => 'ADR_CLASS_DRUID_DESC', 'class_level' => 0, 'class_img' => 'Druid.png', 'class_might_req' => 0, 'class_dexterity_req' => 0, 'class_constitution_req' => 0, 'class_intelligence_req' => 0, 'class_wisdom_req' => 10, 'class_charisma_req' => 0, 'class_hp_base' => 20, 'class_mp_base' => 20, 'class_hp_per_level' => 1, 'class_mp_per_level' => 2, 'class_update_xp_req' => 1800, 'class_ac_bonus' => 10, 'class_thief_class' => 0],
				['class_id' => 4, 'class_name' => 'ADR_CLASS_BARD', 'class_desc' => 'ADR_CLASS_BARD_DESC', 'class_level' => 0, 'class_img' => 'Bard.png', 'class_might_req' => 3, 'class_dexterity_req' => 3, 'class_constitution_req' => 3, 'class_intelligence_req' => 3, 'class_wisdom_req' => 3, 'class_charisma_req' => 10, 'class_hp_base' => 15, 'class_mp_base' => 15, 'class_hp_per_level' => 2, 'class_mp_per_level' => 2, 'class_update_xp_req' => 1200, 'class_ac_bonus' => 15, 'class_thief_class' => 0],
				['class_id' => 5, 'class_name' => 'ADR_CLASS_MAGICIAN', 'class_desc' => 'ADR_CLASS_MAGICIAN_DESC', 'class_level' => 0, 'class_img' => 'Magician.png', 'class_might_req' => 0, 'class_dexterity_req' => 0, 'class_constitution_req' => 0, 'class_intelligence_req' => 14, 'class_wisdom_req' => 14, 'class_charisma_req' => 0, 'class_hp_base' => 8, 'class_mp_base' => 30, 'class_hp_per_level' => 0, 'class_mp_per_level' => 1, 'class_update_xp_req' => 2500, 'class_ac_bonus' => 5, 'class_thief_class' => 0],
				['class_id' => 6, 'class_name' => 'ADR_CLASS_MONK', 'class_desc' => 'ADR_CLASS_MONK_DESC', 'class_level' => 0, 'class_img' => 'Monk.png', 'class_might_req' => 5, 'class_dexterity_req' => 5, 'class_constitution_req' => 5, 'class_intelligence_req' => 5, 'class_wisdom_req' => 5, 'class_charisma_req' => 5, 'class_hp_base' => 25, 'class_mp_base' => 10, 'class_hp_per_level' => 2, 'class_mp_per_level' => 2, 'class_update_xp_req' => 2400, 'class_ac_bonus' => 20, 'class_thief_class' => 0],
				['class_id' => 7, 'class_name' => 'ADR_CLASS_PALADIN', 'class_desc' => 'ADR_CLASS_PALADIN_DESC', 'class_level' => 0, 'class_img' => 'Paladin.png', 'class_might_req' => 10, 'class_dexterity_req' => 8, 'class_constitution_req' => 10, 'class_intelligence_req' => 10, 'class_wisdom_req' => 8, 'class_charisma_req' => 15, 'class_hp_base' => 40, 'class_mp_base' => 15, 'class_hp_per_level' => 2, 'class_mp_per_level' => 4, 'class_update_xp_req' => 3000, 'class_ac_bonus' => 20, 'class_thief_class' => 0],
				['class_id' => 8, 'class_name' => 'ADR_CLASS_PRIEST', 'class_desc' => 'ADR_CLASS_PRIEST_DESC', 'class_level' => 0, 'class_img' => 'Priest.png', 'class_might_req' => 0, 'class_dexterity_req' => 0, 'class_constitution_req' => 0, 'class_intelligence_req' => 10, 'class_wisdom_req' => 12, 'class_charisma_req' => 0, 'class_hp_base' => 20, 'class_mp_base' => 20, 'class_hp_per_level' => 1, 'class_mp_per_level' => 2, 'class_update_xp_req' => 2000, 'class_ac_bonus' => 15, 'class_thief_class' => 0],
				['class_id' => 9, 'class_name' => 'ADR_CLASS_SORCEROR', 'class_desc' => 'ADR_CLASS_SORCEROR_DESC', 'class_level' => 0, 'class_img' => 'Sorcerer.png', 'class_might_req' => 0, 'class_dexterity_req' => 0, 'class_constitution_req' => 0, 'class_intelligence_req' => 16, 'class_wisdom_req' => 0, 'class_charisma_req' => 0, 'class_hp_base' => 30, 'class_mp_base' => 100, 'class_hp_per_level' => 0, 'class_mp_per_level' => 1, 'class_update_xp_req' => 4500, 'class_ac_bonus' => 10, 'class_thief_class' => 0],
				['class_id' => 10, 'class_name' => 'ADR_CLASS_THIEF', 'class_desc' => 'ADR_CLASS_THIEF_DESC', 'class_level' => 0, 'class_img' => 'Thief.png', 'class_might_req' => 0, 'class_dexterity_req' => 12, 'class_constitution_req' => 0, 'class_intelligence_req' => 0, 'class_wisdom_req' => 0, 'class_charisma_req' => 0, 'class_hp_base' => 20, 'class_mp_base' => 10, 'class_hp_per_level' => 1, 'class_mp_per_level' => 2, 'class_update_xp_req' => 1500, 'class_ac_bonus' => 10, 'class_thief_class' => 1],
			],
			'elements' => [
				['element_id' => 1, 'element_name' => 'ADR_ELEMENT_WATER', 'element_desc' => 'ADR_ELEMENT_WATER_DESC', 'element_level' => 0, 'element_img' => 'Water.png', 'element_skill_mining_bonus' => 0, 'element_skill_stone_bonus' => 0, 'element_skill_forge_bonus' => 0, 'element_skill_enchant_bonus' => 1],
				['element_id' => 2, 'element_name' => 'ADR_ELEMENT_EARTH', 'element_desc' => 'ADR_ELEMENT_EARTH_DESC', 'element_level' => 0, 'element_img' => 'Earth.png', 'element_skill_mining_bonus' => 1, 'element_skill_stone_bonus' => 1, 'element_skill_forge_bonus' => 0, 'element_skill_enchant_bonus' => 0],
				['element_id' => 3, 'element_name' => 'ADR_ELEMENT_HOLY', 'element_desc' => 'ADR_ELEMENT_HOLY_DESC', 'element_level' => 2, 'element_img' => 'Holy.png', 'element_skill_mining_bonus' => 1, 'element_skill_stone_bonus' => 1, 'element_skill_forge_bonus' => 1, 'element_skill_enchant_bonus' => 1],
				['element_id' => 4, 'element_name' => 'ADR_ELEMENT_FIRE', 'element_desc' => 'ADR_ELEMENT_FIRE_DESC', 'element_level' => 0, 'element_img' => 'Fire.png', 'element_skill_mining_bonus' => 0, 'element_skill_stone_bonus' => 0, 'element_skill_forge_bonus' => 1, 'element_skill_enchant_bonus' => 0],
			],
			'monsters' => [
				['monster_id' => 1, 'monster_name' => 'Globuz', 'monster_img' => 'Monster1.jpg', 'monster_level' => 1, 'monster_base_hp' => 15, 'monster_base_att' => 30, 'monster_base_def' => 30, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 10, 'monster_gold_reward' => 10, 'monster_item_reward' => 0, 'monster_min_level' => 1, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 2, 'monster_name' => 'Kargh', 'monster_img' => 'Monster2.jpg', 'monster_level' => 2, 'monster_base_hp' => 20, 'monster_base_att' => 40, 'monster_base_def' => 60, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 20, 'monster_gold_reward' => 20, 'monster_item_reward' => 0, 'monster_min_level' => 2, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 3, 'monster_name' => 'Bouglou', 'monster_img' => 'Monster3.jpg', 'monster_level' => 1, 'monster_base_hp' => 14, 'monster_base_att' => 40, 'monster_base_def' => 70, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 10, 'monster_gold_reward' => 10, 'monster_item_reward' => 0, 'monster_min_level' => 1, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 4, 'monster_name' => 'Dretg', 'monster_img' => 'Monster4.jpg', 'monster_level' => 1, 'monster_base_hp' => 25, 'monster_base_att' => 30, 'monster_base_def' => 30, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 10, 'monster_gold_reward' => 10, 'monster_item_reward' => 0, 'monster_min_level' => 1, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 5, 'monster_name' => 'Greyiok', 'monster_img' => 'Monster5.jpg', 'monster_level' => 1, 'monster_base_hp' => 10, 'monster_base_att' => 70, 'monster_base_def' => 70, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 10, 'monster_gold_reward' => 10, 'monster_item_reward' => 0, 'monster_min_level' => 1, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 6, 'monster_name' => 'Itchy', 'monster_img' => 'Monster6.jpg', 'monster_level' => 2, 'monster_base_hp' => 25, 'monster_base_att' => 90, 'monster_base_def' => 80, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 20, 'monster_gold_reward' => 20, 'monster_item_reward' => 0, 'monster_min_level' => 2, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 7, 'monster_name' => 'Globber', 'monster_img' => 'Monster7.jpg', 'monster_level' => 3, 'monster_base_hp' => 45, 'monster_base_att' => 250, 'monster_base_def' => 200, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 30, 'monster_gold_reward' => 30, 'monster_item_reward' => 0, 'monster_min_level' => 3, 'monster_max_level' => 0, 'monster_element' => 1],
				['monster_id' => 8, 'monster_name' => 'Scratchy', 'monster_img' => 'Monster8.jpg', 'monster_level' => 4, 'monster_base_hp' => 80, 'monster_base_att' => 350, 'monster_base_def' => 300, 'monster_base_mp' => 10, 'monster_base_mp_power' => 1, 'monster_base_magic_def' => 10, 'monster_xp_reward' => 40, 'monster_gold_reward' => 40, 'monster_item_reward' => 0, 'monster_min_level' => 4, 'monster_max_level' => 0, 'monster_element' => 1],
			],
			'skills' => [
				['skill_id' => 1, 'skill_name' => 'ADR_MINING', 'skill_desc' => 'ADR_SKILL_MINING_DESC', 'skill_img' => 'skill_mining.png', 'skill_req' => 100, 'skill_chance' => 5],
				['skill_id' => 2, 'skill_name' => 'ADR_STONE', 'skill_desc' => 'ADR_SKILL_STONE_DESC', 'skill_img' => 'skill_stone.png', 'skill_req' => 200, 'skill_chance' => 5],
				['skill_id' => 3, 'skill_name' => 'ADR_FORGE', 'skill_desc' => 'ADR_SKILL_FORGE_DESC', 'skill_img' => 'skill_forge.png', 'skill_req' => 50, 'skill_chance' => 5],
				['skill_id' => 4, 'skill_name' => 'ADR_ENCHANTMENT', 'skill_desc' => 'ADR_SKILL_ENCHANTMENT_DESC', 'skill_img' => 'skill_enchantment.png', 'skill_req' => 300, 'skill_chance' => 5],
				['skill_id' => 5, 'skill_name' => 'ADR_TRADING', 'skill_desc' => 'ADR_SKILL_TRADING_DESC', 'skill_img' => 'skill_trading.png', 'skill_req' => 80, 'skill_chance' => 5],
				['skill_id' => 6, 'skill_name' => 'ADR_THIEF', 'skill_desc' => 'ADR_SKILL_THIEF_DESC', 'skill_img' => 'skill_thief.png', 'skill_req' => 70, 'skill_chance' => 5],
			],
			'item_quality' => [
				['item_quality_id' => 0, 'item_quality_modifier_price' => 0, 'item_quality_lang' => 'ADR_DONT_CARE'],
				['item_quality_id' => 1, 'item_quality_modifier_price' => 20, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_VERY_POOR'],
				['item_quality_id' => 2, 'item_quality_modifier_price' => 50, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_POOR'],
				['item_quality_id' => 3, 'item_quality_modifier_price' => 100, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_MEDIUM'],
				['item_quality_id' => 4, 'item_quality_modifier_price' => 140, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_GOOD'],
				['item_quality_id' => 5, 'item_quality_modifier_price' => 200, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_VERY_GOOD'],
				['item_quality_id' => 6, 'item_quality_modifier_price' => 300, 'item_quality_lang' => 'ADR_ITEMS_QUALITY_EXCELLENT'],
			],
			'item_types' => [
				['item_type_id' => 1, 'item_type_base_price' => 50, 'item_type_lang' => 'ADR_ITEMS_TYPE_RAW_MATERIALS', 'item_type_order' => 1, 'item_type_category' => ''],
				['item_type_id' => 2, 'item_type_base_price' => 200, 'item_type_lang' => 'ADR_ITEMS_TYPE_RARE_RAW_MATERIALS', 'item_type_order' => 2, 'item_type_category' => ''],
				['item_type_id' => 3, 'item_type_base_price' => 100, 'item_type_lang' => 'ADR_ITEMS_TYPE_TOOLS_PICKAXE', 'item_type_order' => 3, 'item_type_category' => ''],
				['item_type_id' => 4, 'item_type_base_price' => 100, 'item_type_lang' => 'ADR_ITEMS_TYPE_TOOLS_MAGICTOME', 'item_type_order' => 4, 'item_type_category' => ''],
				['item_type_id' => 5, 'item_type_base_price' => 100, 'item_type_lang' => 'ADR_ITEMS_TYPE_WEAPON', 'item_type_order' => 5, 'item_type_category' => ''],
				['item_type_id' => 6, 'item_type_base_price' => 1000, 'item_type_lang' => 'ADR_ITEMS_TYPE_ENCHANTED_WEAPON', 'item_type_order' => 6, 'item_type_category' => ''],
				['item_type_id' => 7, 'item_type_base_price' => 200, 'item_type_lang' => 'ADR_ITEMS_TYPE_ARMOR', 'item_type_order' => 7, 'item_type_category' => ''],
				['item_type_id' => 8, 'item_type_base_price' => 100, 'item_type_lang' => 'ADR_ITEMS_TYPE_BUCKLER', 'item_type_order' => 8, 'item_type_category' => ''],
				['item_type_id' => 9, 'item_type_base_price' => 50, 'item_type_lang' => 'ADR_ITEMS_TYPE_HELM', 'item_type_order' => 9, 'item_type_category' => ''],
				['item_type_id' => 10, 'item_type_base_price' => 50, 'item_type_lang' => 'ADR_ITEMS_TYPE_GLOVES', 'item_type_order' => 10, 'item_type_category' => ''],
				['item_type_id' => 11, 'item_type_base_price' => 500, 'item_type_lang' => 'ADR_ITEMS_TYPE_MAGIC_ATTACK', 'item_type_order' => 11, 'item_type_category' => ''],
				['item_type_id' => 12, 'item_type_base_price' => 500, 'item_type_lang' => 'ADR_ITEMS_TYPE_MAGIC_DEFEND', 'item_type_order' => 12, 'item_type_category' => ''],
				['item_type_id' => 13, 'item_type_base_price' => 5000, 'item_type_lang' => 'ADR_ITEMS_TYPE_AMULET', 'item_type_order' => 13, 'item_type_category' => ''],
				['item_type_id' => 14, 'item_type_base_price' => 10000, 'item_type_lang' => 'ADR_ITEMS_TYPE_RING', 'item_type_order' => 14, 'item_type_category' => ''],
				['item_type_id' => 15, 'item_type_base_price' => 20, 'item_type_lang' => 'ADR_ITEMS_TYPE_HEALTH_POTION', 'item_type_order' => 15, 'item_type_category' => ''],
				['item_type_id' => 16, 'item_type_base_price' => 20, 'item_type_lang' => 'ADR_ITEMS_TYPE_MANA_POTION', 'item_type_order' => 16, 'item_type_category' => ''],
				['item_type_id' => 17, 'item_type_base_price' => 1, 'item_type_lang' => 'ADR_ITEMS_TYPE_MISC', 'item_type_order' => 17, 'item_type_category' => ''],
			],
			'shops' => [
				['shop_id' => 1, 'shop_owner_id' => 1, 'shop_name' => 'ADR_SHOP_FORUMS', 'shop_desc' => 'ADR_SHOP_FORUMS_DESC', 'shop_logo' => '', 'shop_last_updated' => 0],
			],
			'stores' => [
				['store_id' => 1, 'store_name' => 'Forum Store', 'store_desc' => 'The general forum store', 'store_img' => '', 'store_status' => 1, 'store_sales_status' => 0, 'store_admin' => 0, 'store_owner_id' => 1],
				['store_id' => 2, 'store_name' => 'Admin Only Store', 'store_desc' => 'Viewable only by the board admin', 'store_img' => '', 'store_status' => 1, 'store_sales_status' => 0, 'store_admin' => 1, 'store_owner_id' => 1],
			],
			'vault_exchange' => [
				['stock_id' => 1, 'stock_name' => 'ADR_VAULT_ACTION_NAME_1', 'stock_desc' => 'ADR_VAULT_ACTION_DESC_1', 'stock_price' => 113, 'stock_previous_price' => 108, 'stock_best_price' => 113, 'stock_worst_price' => 100],
				['stock_id' => 2, 'stock_name' => 'ADR_VAULT_ACTION_NAME_2', 'stock_desc' => 'ADR_VAULT_ACTION_DESC_2', 'stock_price' => 177, 'stock_previous_price' => 192, 'stock_best_price' => 200, 'stock_worst_price' => 177],
				['stock_id' => 3, 'stock_name' => 'ADR_VAULT_ACTION_NAME_3', 'stock_desc' => 'ADR_VAULT_ACTION_DESC_3', 'stock_price' => 280, 'stock_previous_price' => 288, 'stock_best_price' => 300, 'stock_worst_price' => 280],
			],
			'items' => [
				['item_id' => 1, 'item_owner_id' => 1, 'item_price' => 56, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'ore.gif', 'item_name' => 'ADR_ITEM_ORE', 'item_desc' => 'ADR_ITEM_ORE_DESC', 'item_type' => 1, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 2, 'item_owner_id' => 1, 'item_price' => 352, 'item_quality' => 3, 'item_power' => 4, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'sapphire.gif', 'item_name' => 'ADR_ITEMS_SAPPHIRE', 'item_desc' => 'ADR_ITEMS_SAPPHIRE_DESC', 'item_type' => 2, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 3, 'item_owner_id' => 1, 'item_price' => 555, 'item_quality' => 4, 'item_power' => 5, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'diamond.gif', 'item_name' => 'ADR_ITEMS_DIAMOND', 'item_desc' => 'ADR_ITEMS_DIAMOND_DESC', 'item_type' => 2, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 4, 'item_owner_id' => 1, 'item_price' => 111, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'tome.gif', 'item_name' => 'ADR_ITEM_TOME', 'item_desc' => 'ADR_ITEM_TOME_DESC', 'item_type' => 4, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 5, 'item_owner_id' => 1, 'item_price' => 154, 'item_quality' => 3, 'item_power' => 3, 'item_duration' => 200, 'item_duration_max' => 200, 'item_icon' => 'miner.gif', 'item_name' => 'ADR_ITEMS_MINER', 'item_desc' => 'ADR_ITEMS_MINER_DESC', 'item_type' => 3, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 6, 'item_owner_id' => 1, 'item_price' => 550, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'scroll1.gif', 'item_name' => 'ADR_ITEMS_SCROLL_1', 'item_desc' => 'ADR_ITEMS_SCROLL_1_DESC', 'item_type' => 11, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 7, 'item_owner_id' => 1, 'item_price' => 100, 'item_quality' => 3, 'item_power' => 10, 'item_duration' => 10, 'item_duration_max' => 10, 'item_icon' => 'scroll2.gif', 'item_name' => 'ADR_ITEMS_SCROLL_2', 'item_desc' => 'ADR_ITEMS_SCROLL_2_DESC', 'item_type' => 11, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '3,5,8,9,', 'item_restrict_class_enable' => 1, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 5, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 20, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 8, 'item_owner_id' => 1, 'item_price' => 550, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'scroll3.gif', 'item_name' => 'ADR_ITEMS_SCROLL_3', 'item_desc' => 'ADR_ITEMS_SCROLL_3_DESC', 'item_type' => 12, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 9, 'item_owner_id' => 1, 'item_price' => 1078, 'item_quality' => 4, 'item_power' => 3, 'item_duration' => 1, 'item_duration_max' => 1, 'item_icon' => 'scroll4.gif', 'item_name' => 'ADR_ITEMS_SCROLL_4', 'item_desc' => 'ADR_ITEMS_SCROLL_4_DESC', 'item_type' => 12, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 10, 'item_owner_id' => 1, 'item_price' => 11000, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 150, 'item_duration_max' => 150, 'item_icon' => 'ring1.gif', 'item_name' => 'ADR_ITEMS_RING_1', 'item_desc' => 'ADR_ITEMS_RING_1_DESC', 'item_type' => 14, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 11, 'item_owner_id' => 1, 'item_price' => 27721, 'item_quality' => 4, 'item_power' => 5, 'item_duration' => 600, 'item_duration_max' => 600, 'item_icon' => 'ring2.gif', 'item_name' => 'ADR_ITEMS_RING_2', 'item_desc' => 'ADR_ITEMS_RING_2_DESC', 'item_type' => 14, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '0-', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0-', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0-', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0-', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 13, 'item_owner_id' => 1, 'item_price' => 13861, 'item_quality' => 4, 'item_power' => 5, 'item_duration' => 650, 'item_duration_max' => 650, 'item_icon' => 'amulet2.gif', 'item_name' => 'ADR_ITEMS_AMULET_2', 'item_desc' => 'ADR_ITEMS_AMULET_2_DESC', 'item_type' => 13, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 25, 'item_restrict_class' => '1,2,7,', 'item_restrict_class_enable' => 1, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '2,3,', 'item_restrict_align_enable' => 1, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 7, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 15, 'item_restrict_wis' => 15, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 14, 'item_owner_id' => 1, 'item_price' => 25, 'item_quality' => 4, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'winged-helm.gif', 'item_name' => 'Winged Helm', 'item_desc' => '', 'item_type' => 9, 'item_ac' => 1, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 5, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 15, 'item_owner_id' => 1, 'item_price' => 35, 'item_quality' => 5, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'armor.gif', 'item_name' => 'ADR_ITEMS_ARMOUR', 'item_desc' => 'ADR_ITEMS_ARMOUR_DESC', 'item_type' => 7, 'item_ac' => 1, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 10, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 16, 'item_owner_id' => 1, 'item_price' => 25, 'item_quality' => 3, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'bracer.gif', 'item_name' => 'ADR_ITEMS_TOUGH_SHIELD', 'item_desc' => 'ADR_ITEMS_TOUGH_SHIELD_DESC', 'item_type' => 8, 'item_ac' => 1, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 10, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 17, 'item_owner_id' => 1, 'item_price' => 15, 'item_quality' => 1, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'glove.gif', 'item_name' => 'ADR_ITEMS_GLOVES', 'item_desc' => 'ADR_ITEMS_GLOVES_DESC', 'item_type' => 10, 'item_ac' => 1, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 5, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 18, 'item_owner_id' => 1, 'item_price' => 35, 'item_quality' => 4, 'item_power' => 1, 'item_duration' => 100, 'item_duration_max' => 100, 'item_icon' => 'sword.gif', 'item_name' => 'ADR_ITEMS_SWORD', 'item_desc' => 'ADR_ITEMS_SWORD_DESC', 'item_type' => 5, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 5, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 19, 'item_owner_id' => 1, 'item_price' => 100, 'item_quality' => 6, 'item_power' => 5, 'item_duration' => 250, 'item_duration_max' => 250, 'item_icon' => 'flail.gif', 'item_name' => 'ADR_ITEMS_FLAIL', 'item_desc' => 'ADR_ITEMS_FLAIL_DESC', 'item_type' => 5, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 12, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 3, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 20, 'item_owner_id' => 1, 'item_price' => 150, 'item_quality' => 4, 'item_power' => 10, 'item_duration' => 300, 'item_duration_max' => 300, 'item_icon' => 'bow.gif', 'item_name' => 'ADR_ITEMS_BOW', 'item_desc' => 'ADR_ITEMS_BOW_DESC', 'item_type' => 5, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 15, 'item_restrict_class' => '4,5,9,10,', 'item_restrict_class_enable' => 1, 'item_restrict_race' => '1,2,4,', 'item_restrict_race_enable' => 1, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 5, 'item_restrict_str' => 0, 'item_restrict_dex' => 20, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 21, 'item_owner_id' => 1, 'item_price' => 10, 'item_quality' => 1, 'item_power' => 10, 'item_duration' => 5, 'item_duration_max' => 5, 'item_icon' => 'potion1.gif', 'item_name' => 'ADR_ITEMS_HEALTH_POTION', 'item_desc' => 'ADR_ITEMS_HEALTH_POTION_DESC', 'item_type' => 15, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 3, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
				['item_id' => 22, 'item_owner_id' => 1, 'item_price' => 10, 'item_quality' => 4, 'item_power' => 10, 'item_duration' => 5, 'item_duration_max' => 5, 'item_icon' => 'potion2.gif', 'item_name' => 'ADR_ITEMS_MANA_POTION', 'item_desc' => 'ADR_ITEMS_MANA_POTION_DESC', 'item_type' => 16, 'item_ac' => 0, 'item_in_shop' => 1, 'item_in_warehouse' => 0, 'item_equipped' => 0, 'item_equip_slot' => '', 'item_weight' => 3, 'item_restrict_class' => '0', 'item_restrict_class_enable' => 0, 'item_restrict_race' => '0', 'item_restrict_race_enable' => 0, 'item_restrict_align' => '0', 'item_restrict_align_enable' => 0, 'item_restrict_element' => '0', 'item_restrict_element_enable' => 0, 'item_restrict_level' => 0, 'item_restrict_str' => 0, 'item_restrict_dex' => 0, 'item_restrict_con' => 0, 'item_restrict_int' => 0, 'item_restrict_wis' => 0, 'item_restrict_cha' => 0, 'item_forge_material' => 0, 'item_forge_level' => 0],
			],
		];

		$this->insert_rows('adr_alignments', $defaults['alignments']);
		$this->insert_rows('adr_races', $defaults['races']);
		$this->insert_rows('adr_classes', $defaults['classes']);
		$this->insert_rows('adr_elements', $defaults['elements']);
		$this->insert_rows('adr_battle_monsters', $defaults['monsters']);
		$this->insert_rows('adr_skills', $defaults['skills']);
		$this->insert_rows('adr_shops_items_quality', $defaults['item_quality']);
		$this->insert_rows('adr_shops_items_type', $defaults['item_types']);
		$this->insert_rows('adr_shops', $defaults['shops']);
		$this->insert_rows('adr_stores', $defaults['stores']);
		$this->insert_rows('adr_vault_exchange', $defaults['vault_exchange']);
		$this->insert_rows('adr_shops_items', $defaults['items']);
	}

	protected function insert_rows($table, array $rows)
	{
		if (!empty($rows))
		{
			$this->db->sql_multi_insert($this->table_prefix . $table, $rows);
		}
	}
}
