<?php
namespace adr\rpg\migrations;

class v3_0_2_skill_uses extends \phpbb\db\migration\migration
{
	public static function depends_on()
	{
		return ['\adr\rpg\migrations\v3_0_1_acp_items_module'];
	}

	public function update_schema()
	{
		return [
			'add_columns' => [
				$this->table_prefix . 'adr_characters' => [
					'character_skill_mining_uses'      => ['INT:8', 0],
					'character_skill_stone_uses'       => ['INT:8', 0],
					'character_skill_forge_uses'       => ['INT:8', 0],
					'character_skill_enchant_uses'     => ['INT:8', 0],
					'character_skill_thief_uses'       => ['INT:8', 0],
				],
			],
		];
	}

	public function revert_schema()
	{
		return [
			'drop_columns' => [
				$this->table_prefix . 'adr_characters' => [
					'character_skill_mining_uses',
					'character_skill_stone_uses',
					'character_skill_forge_uses',
					'character_skill_enchant_uses',
					'character_skill_thief_uses',
				],
			],
		];
	}
}
