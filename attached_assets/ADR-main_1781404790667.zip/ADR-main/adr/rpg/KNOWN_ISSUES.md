In Progress: Porting phpBB2 extension (found in adr/legacy) to phpBB 3.3.16 (found in adr/rpg)
