<?php

namespace adr\rpg\acp;

class zone_general_module
{
    public $u_action;

    public function main($id, $mode)
    {
        global $phpbb_container;

        $controller = $phpbb_container->get('adr.rpg.controller.acp.zone_general');
        $controller->set_page_url($this->u_action);
        $controller->main();
    }
}
