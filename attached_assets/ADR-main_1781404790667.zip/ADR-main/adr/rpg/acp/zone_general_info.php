<?php

namespace adr\rpg\acp;

class zone_general_info
{
    public function module()
    {
        return [
            'filename'  => '\adr\rpg\acp\zone_general_module',
            'title'     => 'ADR_ACP_ZONE_GENERAL',
            'modes'     => [
                'manage' => [
                    'title' => 'ADR_ACP_ZONE_GENERAL_MANAGE',
                    'auth'  => 'ext_adr/rpg && acl_a_board',
                    'cat'   => ['ADR_ACP_CAT_ZONES'],
                ],
            ],
        ];
    }
}
