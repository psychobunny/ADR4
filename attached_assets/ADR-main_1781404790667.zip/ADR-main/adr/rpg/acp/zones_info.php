<?php

namespace adr\rpg\acp;

class zones_info
{
    public function module()
    {
        return [
            'filename'  => '\adr\rpg\acp\zones_module',
            'title'     => 'ADR_ACP_ZONES',
            'modes'     => [
                'manage' => [
                    'title' => 'ADR_ACP_ZONES_MANAGE',
                    'auth'  => 'ext_adr/rpg && acl_a_board',
                    'cat'   => ['ADR_ACP_CAT_ZONES'],
                ],
            ],
        ];
    }
}
