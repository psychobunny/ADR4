<?php

namespace adr\rpg\acp;

class seasons_info
{
    public function module()
    {
        return [
            'filename'  => '\adr\rpg\acp\seasons_module',
            'title'     => 'ADR_ACP_SEASONS',
            'modes'     => [
                'manage' => [
                    'title' => 'ADR_ACP_SEASONS_MANAGE',
                    'auth'  => 'ext_adr/rpg && acl_a_board',
                    'cat'   => ['ADR_ACP_CAT_ZONES'],
                ],
            ],
        ];
    }
}
