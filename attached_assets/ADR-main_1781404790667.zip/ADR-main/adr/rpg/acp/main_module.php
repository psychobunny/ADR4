<?php
namespace adr\rpg\acp;

class main_module
{
    public $u_action;
    public $tpl_name;
    public $page_title;
    protected $controller;

    public function main($id, $mode)
    {
        global $phpbb_container;

        $this->controller = $phpbb_container->get('adr.rpg.controller.acp.main');
        $this->controller->set_page_url($this->u_action);

        switch ($mode)
        {
            case 'general':
                $this->controller->general();
            break;
            case 'races':
                $this->controller->races();
            break;
            case 'classes':
                $this->controller->classes();
            break;
            case 'alignments':
                $this->controller->alignments();
            break;
            case 'elements':
                $this->controller->elements();
            break;
            case 'monsters':
                $this->controller->monsters();
            break;
            case 'skills':
                $this->controller->skills();
            break;
            case 'item_types':
                $this->controller->item_types();
            break;
            case 'items':
                $this->controller->items();
            break;
            case 'stores':
                $this->controller->stores();
            break;
            case 'vault_exchange':
                $this->controller->vault_exchange();
            break;
            case 'users':
                $this->controller->users();
            break;
            case 'jailed_users':
                $this->controller->jailed_users();
            break;
            case 'tools':
                $this->controller->tools();
            break;
			case 'zones':
				$this->controller->zones();
			break;
			case 'seasons':
				$this->controller->seasons();
			break;
			case 'zone_general':
				$this->controller->zone_general();
			break;
        }

        $this->tpl_name = $this->controller->tpl_name;
        $this->page_title = $this->controller->page_title;
    }
}
