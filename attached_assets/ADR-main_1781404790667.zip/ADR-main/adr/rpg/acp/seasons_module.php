<?php

namespace adr\rpg\acp;

class seasons_module
{
    public $u_action;

    public function main($id, $mode)
    {
        global $phpbb_container;

        $controller = $phpbb_container->get('adr.rpg.controller.acp.seasons');
        $controller->set_page_url($this->u_action);
        $controller->main();
    }
}
