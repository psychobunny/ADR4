<?php
namespace adr\rpg\acp;

class main_info
{
	public function module()
	{
		return [
			'filename'  => '\adr\rpg\acp\main_module',
			'title'     => 'ACP_ADR_TITLE',
			'language'  => 'acp',
			'modes'     => [
				'general'       => ['title' => 'ACP_ADR_GENERAL',       'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'races'         => ['title' => 'ACP_ADR_RACES',         'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'classes'       => ['title' => 'ACP_ADR_CLASSES',       'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'alignments'    => ['title' => 'ACP_ADR_ALIGNMENTS',    'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'elements'      => ['title' => 'ACP_ADR_ELEMENTS',      'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'monsters'      => ['title' => 'ACP_ADR_MONSTERS',      'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'skills'        => ['title' => 'ACP_ADR_SKILLS',        'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'item_types'    => ['title' => 'ACP_ADR_ITEM_TYPES',    'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'items'         => ['title' => 'ACP_ADR_ITEMS',         'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'stores'        => ['title' => 'ACP_ADR_STORES',        'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'vault_exchange'=> ['title' => 'ACP_ADR_VAULT_EXCHANGE','auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'users'         => ['title' => 'ACP_ADR_USERS',         'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'jailed_users'  => ['title' => 'ACP_ADR_JAILED_USERS',  'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'tools'         => ['title' => 'ACP_ADR_TOOLS',         'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'zones'         => ['title' => 'ACP_ADR_ZONES',         'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'seasons'       => ['title' => 'ACP_ADR_SEASONS',       'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
				'zone_general'  => ['title' => 'ACP_ADR_ZONE_GENERAL',  'auth' => 'ext_adr/rpg && acl_a_board', 'cat' => ['ACP_ADR_TITLE']],
			],
		];
	}
}
