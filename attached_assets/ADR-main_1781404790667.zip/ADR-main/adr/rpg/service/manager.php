<?php
namespace adr\rpg\service;

class manager
{
        protected $config;
        protected $db;
        protected $user;
        protected $root_path;
        protected $php_ext;

        public function __construct(
                \phpbb\config\config $config,
                \phpbb\db\driver\driver_interface $db,
                \phpbb\user $user,
                $root_path,
                $php_ext
        )
        {
                $this->config     = $config;
                $this->db         = $db;
                $this->user       = $user;
                $this->root_path  = $root_path;
                $this->php_ext    = $php_ext;
        }

        public function get_table($name)
        {
                global $table_prefix;
                return $table_prefix . 'adr_' . $name;
        }

        public function get_general_config()
        {
                $sql = 'SELECT config_name, config_value FROM ' . $this->get_table('general');
                $result = $this->db->sql_query($sql);
                $config = [];
                while ($row = $this->db->sql_fetchrow($result))
                {
                        $config[$row['config_name']] = $row['config_value'];
                }
                $this->db->sql_freeresult($result);
                return $config;
        }

        public function get_user_character($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT c.*, r.race_name, r.race_img, cl.class_name, cl.class_img,
                                        a.alignment_name, a.alignment_img,
                                        e.element_name, e.element_img,
                                        e.element_skill_mining_bonus, e.element_skill_stone_bonus, e.element_skill_forge_bonus, e.element_skill_enchant_bonus
                                FROM ' . $this->get_table('characters') . ' c
                                LEFT JOIN ' . $this->get_table('races') . ' r ON r.race_id = c.character_race
                                LEFT JOIN ' . $this->get_table('classes') . ' cl ON cl.class_id = c.character_class
                                LEFT JOIN ' . $this->get_table('alignments') . ' a ON a.alignment_id = c.character_alignment
                                LEFT JOIN ' . $this->get_table('elements') . ' e ON e.element_id = c.character_element
                                WHERE c.character_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $character = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);
                return $character;
        }

        /**
         * Increment a character skill "success uses" counter and level up when threshold reached.
         *
         * Skill thresholds come from `adr_skills.skill_req`.
         *
         * @return array{level_up: bool, new_uses: int, new_level?: int}
         */
        public function increment_skill($user_id, $skill_id)
        {
                $user_id = (int) $user_id;
                $skill_id = (int) $skill_id;

                // These columns exist in current schema (see v0_4_5_install + v3_0_2_skill_uses).
                $mapping = [
                        1 => ['level' => 'character_skill_mining', 'uses' => 'character_skill_mining_uses'],
                        2 => ['level' => 'character_skill_stone', 'uses' => 'character_skill_stone_uses'],
                        3 => ['level' => 'character_skill_forge', 'uses' => 'character_skill_forge_uses'],
                        4 => ['level' => 'character_skill_enchantment', 'uses' => 'character_skill_enchant_uses'],
                        6 => ['level' => 'character_skill_thief', 'uses' => 'character_skill_thief_uses'],
                ];

                if (!isset($mapping[$skill_id]))
                {
                        return ['level_up' => false, 'new_uses' => 0];
                }

                $level_col = $mapping[$skill_id]['level'];
                $uses_col  = $mapping[$skill_id]['uses'];

                $sql = 'SELECT c.' . $uses_col . ' AS uses,
                                c.' . $level_col . ' AS level,
                                s.skill_req
                        FROM ' . $this->get_table('characters') . ' c
                        JOIN ' . $this->get_table('skills') . ' s ON s.skill_id = ' . $skill_id . '
                        WHERE c.character_id = ' . $user_id;

                $result = $this->db->sql_query($sql);
                $row = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$row)
                {
                        return ['level_up' => false, 'new_uses' => 0];
                }

                $current_uses = (int) $row['uses'];
                $current_level = (int) $row['level'];
                $skill_req = (int) $row['skill_req'];

                // Avoid division by 0 / weird schema states.
                if ($skill_req <= 0)
                {
                        $sql = 'UPDATE ' . $this->get_table('characters') . '
                                SET ' . $level_col . ' = ' . $level_col . ' + 1,
                                    ' . $uses_col . ' = 0
                                WHERE character_id = ' . $user_id;
                        $this->db->sql_query($sql);

                        return ['level_up' => true, 'new_uses' => 0, 'new_level' => $current_level + 1];
                }

                $new_uses = $current_uses + 1;
                $level_up = $new_uses >= $skill_req;

                if ($level_up)
                {
                        $sql = 'UPDATE ' . $this->get_table('characters') . '
                                SET ' . $uses_col . ' = 0,
                                    ' . $level_col . ' = ' . $level_col . ' + 1
                                WHERE character_id = ' . $user_id;
                        $this->db->sql_query($sql);

                        return ['level_up' => true, 'new_uses' => 0, 'new_level' => $current_level + 1];
                }

                $sql = 'UPDATE ' . $this->get_table('characters') . '
                        SET ' . $uses_col . ' = ' . $uses_col . ' + 1
                        WHERE character_id = ' . $user_id;
                $this->db->sql_query($sql);

                return ['level_up' => false, 'new_uses' => $new_uses];
        }

        public function character_exists($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT character_id FROM ' . $this->get_table('characters') . '
                                WHERE character_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $row = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);
                return (bool) $row;
        }

        public function is_character_banned($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT character_banned, character_banned_expire FROM ' . $this->get_table('characters') . '
                                WHERE character_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $row = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$row)
                {
                        return false;
                }

                if ($row['character_banned'] && ($row['character_banned_expire'] == 0 || $row['character_banned_expire'] > time()))
                {
                        return true;
                }

                return false;
        }

        public function is_in_jail($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT celled_id, user_time FROM ' . $this->get_table('jail_users') . '
                                WHERE celled_id = ' . $user_id . '
                                AND user_freed_by = 0';
                $result = $this->db->sql_query($sql);
                $row = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$row)
                {
                        return false;
                }

                if ($row['user_time'] > 0 && $row['user_time'] < time())
                {
                        $this->db->sql_query('DELETE FROM ' . $this->get_table('jail_users') . '
                                WHERE celled_id = ' . $user_id);
                        return false;
                }

                return true;
        }

        public function add_experience($user_id, $mode)
        {
                $user_id = (int) $user_id;

                if (!$this->character_exists($user_id))
                {
                        return;
                }

                switch ($mode)
                {
                        case 'newtopic':
                                $xp = (int) $this->config['adr_experience_for_new'];
                        break;
                        case 'reply':
                                $xp = (int) $this->config['adr_experience_for_reply'];
                        break;
                        case 'editpost':
                                $xp = (int) $this->config['adr_experience_for_edit'];
                        break;
                        default:
                                return;
                }

                if ($xp <= 0)
                {
                        return;
                }

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_xp = character_xp + ' . $xp . '
                        WHERE character_id = ' . $user_id);

                $this->check_level_up($user_id);
        }

        public function check_level_up($user_id)
        {
                $user_id = (int) $user_id;

                $sql = 'SELECT c.character_xp, c.character_level, cl.class_update_xp_req
                                FROM ' . $this->get_table('characters') . ' c
                                JOIN ' . $this->get_table('classes') . ' cl ON cl.class_id = c.character_class
                                WHERE c.character_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $row = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$row)
                {
                        return;
                }

                $xp_req = $row['class_update_xp_req'];
                $penalty = (int) $this->config['adr_next_level_penalty'];

                for ($p = 1; $p < $row['character_level']; $p++)
                {
                        $xp_req = (int) floor($xp_req * ((100 + $penalty) / 100));
                }

                if ($row['character_xp'] >= $xp_req)
                {
                        $this->level_up($user_id);
                }
        }

        public function level_up($user_id)
        {
                $user_id = (int) $user_id;

                $sql = 'SELECT c.*, cl.class_hp_per_level, cl.class_mp_per_level, cl.class_update_xp_req,
                                        r.race_weight_per_level
                                FROM ' . $this->get_table('characters') . ' c
                                JOIN ' . $this->get_table('classes') . ' cl ON cl.class_id = c.character_class
                                JOIN ' . $this->get_table('races') . ' r ON r.race_id = c.character_race
                                WHERE c.character_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $char = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$char)
                {
                        return;
                }

                $new_level     = $char['character_level'] + 1;
                $new_hp_max    = $char['character_hp_max'] + $char['class_hp_per_level'];
                $new_mp_max    = $char['character_mp_max'] + $char['class_mp_per_level'];
                $new_weight_max = (int) ($char['character_weight_max'] * (1 + $char['race_weight_per_level'] / 100));
                $stat_points   = (int) $this->config['adr_stat_points_per_level'];

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_level = ' . $new_level . ',
                                character_hp_max = ' . $new_hp_max . ',
                                character_hp = ' . $new_hp_max . ',
                                character_mp_max = ' . $new_mp_max . ',
                                character_mp = ' . $new_mp_max . ',
                                character_weight_max = ' . $new_weight_max . ',
                                character_sp = character_sp + ' . $stat_points . ',
                                character_xp = 0
                        WHERE character_id = ' . $user_id);
        }

        public function get_races()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('races') . ' ORDER BY race_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_classes()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('classes') . ' ORDER BY class_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_alignments()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('alignments') . ' ORDER BY alignment_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_elements()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('elements') . ' ORDER BY element_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_skills()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('skills') . ' ORDER BY skill_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_monsters()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('battle_monsters') . ' ORDER BY monster_level ASC, monster_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_available_monsters($user_level)
        {
                $user_level = (int) $user_level;
                $sql = 'SELECT * FROM ' . $this->get_table('battle_monsters') . '
                                WHERE monster_min_level <= ' . $user_level . '
                                AND (monster_max_level = 0 OR monster_max_level >= ' . $user_level . ')
                                ORDER BY monster_level ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function modifier_calc($stat)
        {
                $stat = (int) $stat;
                return (int) floor(($stat - 10) / 2);
        }

        public function calc_attack($might, $constitution)
        {
                return (int) ceil(($might + ($might * 0.5)) + $this->modifier_calc($constitution));
        }

        public function calc_magic_attack($intelligence)
        {
                return (int) ceil($intelligence + ($intelligence * 0.75));
        }

        public function calc_defense($ac, $dexterity)
        {
                return (int) ceil(($ac + ($ac * 0.5)) + $this->modifier_calc($dexterity));
        }

        public function calc_magic_defense($wisdom)
        {
                return (int) ceil($wisdom + ($wisdom * 0.5));
        }

        public function get_user_items($user_id, $in_shop = null, $equipped = null)
        {
                $user_id = (int) $user_id;

                $where = 'item_owner_id = ' . $user_id;

                if ($in_shop !== null)
                {
                        $where .= ' AND item_in_shop = ' . (int) $in_shop;
                }

                if ($equipped !== null)
                {
                        $where .= ' AND item_equipped = ' . (int) $equipped;
                }

                $sql = 'SELECT i.*, t.item_type_lang, q.item_quality_lang, q.item_quality_modifier_price
                                FROM ' . $this->get_table('shops_items') . ' i
                                LEFT JOIN ' . $this->get_table('shops_items_type') . ' t ON t.item_type_id = i.item_type
                                LEFT JOIN ' . $this->get_table('shops_items_quality') . ' q ON q.item_quality_id = i.item_quality
                                WHERE ' . $where . '
                                AND (i.item_duration > 0 OR i.item_duration_max = -1)
                                AND i.item_in_warehouse = 0
                                ORDER BY i.item_id ASC';
                $result = $this->db->sql_query($sql);
                $items = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $items;
        }

        public function create_character($user_id, $data)
        {
                $user_id = (int) $user_id;

                if ($this->character_exists($user_id))
                {
                        return false;
                }

                $username = $this->user->data['username'];

                $race_sql = 'SELECT * FROM ' . $this->get_table('races') . ' WHERE race_id = ' . (int) $data['race_id'];
                $result = $this->db->sql_query($race_sql);
                $race = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                $class_sql = 'SELECT * FROM ' . $this->get_table('classes') . ' WHERE class_id = ' . (int) $data['class_id'];
                $result = $this->db->sql_query($class_sql);
                $class = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$race || !$class)
                {
                        return false;
                }

                $base_might   = 5 + (int) $race['race_might_bonus'];
                $base_dex     = 5 + (int) $race['race_dexterity_bonus'];
                $base_con     = 5 + (int) $race['race_constitution_bonus'];
                $base_int     = 5 + (int) $race['race_intelligence_bonus'];
                $base_wis     = 5 + (int) $race['race_wisdom_bonus'];
                $base_cha     = 5 + (int) $race['race_charisma_bonus'];
                $base_hp      = $class['class_hp_base'] + (int) $race['race_hp_bonus'];
                $base_mp      = $class['class_mp_base'] + (int) $race['race_mp_bonus'];

                $character_data = [
                        'character_id'            => $user_id,
                        'character_name'          => $username,
                        'character_desc'          => $this->db->sql_escape($data['desc'] ?? ''),
                        'character_race'          => (int) $data['race_id'],
                        'character_class'         => (int) $data['class_id'],
                        'character_alignment'     => (int) $data['alignment_id'],
                        'character_element'       => (int) $data['element_id'],
                        'character_hp'            => $base_hp,
                        'character_hp_max'        => $base_hp,
                        'character_mp'            => $base_mp,
                        'character_mp_max'        => $base_mp,
                        'character_xp'            => 0,
                        'character_level'         => 1,
                        'character_area'          => 1,
                        'character_might'         => $base_might,
                        'character_dexterity'     => $base_dex,
                        'character_constitution'  => $base_con,
                        'character_intelligence'  => $base_int,
                        'character_wisdom'        => $base_wis,
                        'character_charisma'      => $base_cha,
                        'character_ac'            => $class['class_ac_bonus'],
                        'character_weight'        => 0,
                        'character_weight_max'    => (int) $race['race_weight'],
                        'character_gold'          => 50,
                        'character_points'        => 0,
                        'character_sp'            => 0,
                        'character_creation_date' => time(),
                ];

                $this->db->sql_query('INSERT INTO ' . $this->get_table('characters') . ' ' .
                        $this->db->sql_build_array('INSERT', $character_data));

                return true;
        }

        public function delete_character($user_id)
        {
                $user_id = (int) $user_id;

                $tables = [
                        'characters'              => 'character_id',
                        'shops'                   => 'shop_owner_id',
                        'shops_items'             => 'item_owner_id',
                        'vault_blacklist'         => 'user_id',
                        'vault_exchange_users'    => 'user_id',
                        'vault_users'             => 'owner_id',
                        'battle_list'             => 'battle_challenger_id',
                        'jail_users'              => 'celled_id',
                ];

                foreach ($tables as $table => $col)
                {
                        $this->db->sql_query('DELETE FROM ' . $this->get_table($table) . ' WHERE ' . $col . ' = ' . $user_id);
                }
        }

        public function get_item_types()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('shops_items_type') . ' ORDER BY item_type_order ASC, item_type_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_item_qualities()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('shops_items_quality') . ' ORDER BY item_quality_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function get_stores($admin_only = false)
        {
                $where = $admin_only ? 'WHERE store_admin = 1 AND store_status = 1' : 'WHERE store_status = 1';
                $sql = 'SELECT * FROM ' . $this->get_table('stores') . ' ' . $where . ' ORDER BY store_id ASC';
                $result = $this->db->sql_query($sql);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function buy_item_from_store($user_id, $item_id, $store_id)
        {
                $user_id = (int) $user_id;
                $item_id = (int) $item_id;
                $store_id = (int) $store_id;

                $char = $this->get_user_character($user_id);
                if (!$char)
                {
                        return ['success' => false, 'error' => 'ADR_NO_CHARACTER'];
                }

                $sql = 'SELECT i.*, t.item_type_base_price, q.item_quality_modifier_price
                                FROM ' . $this->get_table('shops_items') . ' i
                                LEFT JOIN ' . $this->get_table('shops_items_type') . ' t ON t.item_type_id = i.item_type
                                LEFT JOIN ' . $this->get_table('shops_items_quality') . ' q ON q.item_quality_id = i.item_quality
                                WHERE i.item_id = ' . $item_id . '
                                AND i.item_in_shop = 1
                                AND i.item_in_warehouse = 0';
                $result = $this->db->sql_query($sql);
                $item = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$item)
                {
                        return ['success' => false, 'error' => 'ADR_ITEM_NOT_FOUND'];
                }

                $final_price = (int) ($item['item_price'] * ($item['item_quality_modifier_price'] / 100));

                if ($char['character_gold'] < $final_price)
                {
                        return ['success' => false, 'error' => 'ADR_LACK_POINTS'];
                }

                $weight_check = $char['character_weight'] + $item['item_weight'];
                if ($weight_check > $char['character_weight_max'])
                {
                        return ['success' => false, 'error' => 'ADR_TOO_HEAVY'];
                }

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_gold = character_gold - ' . $final_price . ',
                                character_weight = character_weight + ' . (int) $item['item_weight'] . '
                        WHERE character_id = ' . $user_id);

                $new_item = $item;
                unset($new_item['item_id']);
                $new_item['item_owner_id'] = $user_id;
                $new_item['item_in_shop']  = 0;

                $this->db->sql_query('INSERT INTO ' . $this->get_table('shops_items') . ' ' .
                        $this->db->sql_build_array('INSERT', array_intersect_key($new_item, array_flip([
                                'item_owner_id', 'item_price', 'item_quality', 'item_power', 'item_duration',
                                'item_duration_max', 'item_icon', 'item_name', 'item_desc', 'item_type',
                                'item_ac', 'item_in_shop', 'item_in_warehouse', 'item_equipped', 'item_equip_slot',
                                'item_weight', 'item_restrict_class', 'item_restrict_class_enable',
                                'item_restrict_race', 'item_restrict_race_enable',
                                'item_restrict_align', 'item_restrict_align_enable',
                                'item_restrict_element', 'item_restrict_element_enable',
                                'item_restrict_level', 'item_restrict_str', 'item_restrict_dex',
                                'item_restrict_con', 'item_restrict_int', 'item_restrict_wis', 'item_restrict_cha',
                        ]))));

                return ['success' => true];
        }

        /**
         * Buy an item from another player's listed shop (Blackmarket flow).
         */
        public function buy_item_from_user_shop($buyer_id, $item_id)
        {
                $buyer_id = (int) $buyer_id;
                $item_id  = (int) $item_id;

                $char = $this->get_user_character($buyer_id);
                if (!$char)
                {
                        return ['success' => false, 'error' => 'ADR_NO_CHARACTER'];
                }

                $sql = 'SELECT i.*, u.user_name, t.item_type_base_price, q.item_quality_modifier_price
                                FROM ' . $this->get_table('shops_items') . ' i
                                LEFT JOIN ' . $this->get_table('shops_items_type') . ' t ON t.item_type_id = i.item_type
                                LEFT JOIN ' . $this->get_table('shops_items_quality') . ' q ON q.item_quality_id = i.item_quality
                                LEFT JOIN ' . USERS_TABLE . ' u ON u.user_id = i.item_owner_id
                                WHERE i.item_id = ' . $item_id . '
                                AND i.item_in_shop = 1
                                AND i.item_in_warehouse = 0
                                AND i.item_equipped = 0
                                AND i.item_owner_id <> ' . $buyer_id;
                $result = $this->db->sql_query($sql);
                $item = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$item)
                {
                        return ['success' => false, 'error' => 'ADR_ITEM_NOT_FOUND'];
                }

                $final_price = (int) ($item['item_price'] * ($item['item_quality_modifier_price'] / 100));

                if ($final_price <= 0)
                {
                        return ['success' => false, 'error' => 'ADR_ITEM_NOT_FOUND'];
                }

                if ($char['character_gold'] < $final_price)
                {
                        return ['success' => false, 'error' => 'ADR_LACK_POINTS'];
                }

                $weight_check = $char['character_weight'] + (int) $item['item_weight'];
                if ($weight_check > (int) $char['character_weight_max'])
                {
                        return ['success' => false, 'error' => 'ADR_TOO_HEAVY'];
                }

                // Transfer gold + move item ownership out of the shop.
                $seller_id = (int) $item['item_owner_id'];

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_gold = character_gold - ' . $final_price . ',
                                character_weight = character_weight + ' . (int) $item['item_weight'] . '
                        WHERE character_id = ' . $buyer_id);

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_weight = character_weight - ' . (int) $item['item_weight'] . '
                        WHERE character_id = ' . $seller_id);

                $this->db->sql_query('UPDATE ' . $this->get_table('shops_items') . '
                        SET item_owner_id = ' . $buyer_id . ',
                                item_in_shop = 0,
                                item_in_warehouse = 0,
                                item_equipped = 0,
                                item_equip_slot = \'\'
                        WHERE item_id = ' . $item_id . '
                                AND item_owner_id = ' . $seller_id . '
                                AND item_in_shop = 1
                                AND item_in_warehouse = 0');

                return ['success' => true];
        }

        public function get_vault_data($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT * FROM ' . $this->get_table('vault_users') . ' WHERE owner_id = ' . $user_id;
                $result = $this->db->sql_query($sql);
                $vault = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$vault)
                {
                        $vault_data = [
                                'owner_id'        => $user_id,
                                'account_id'      => 0,
                                'account_sum'     => 0,
                                'account_time'    => time(),
                                'loan_sum'        => 0,
                                'loan_time'       => 0,
                                'account_protect' => 0,
                                'loan_protect'    => 0,
                        ];
                        $this->db->sql_query('INSERT INTO ' . $this->get_table('vault_users') . ' ' .
                                $this->db->sql_build_array('INSERT', $vault_data));
                        return $vault_data;
                }

                return $vault;
        }

        public function get_vault_exchange()
        {
                $sql = 'SELECT * FROM ' . $this->get_table('vault_exchange') . ' ORDER BY stock_id ASC';
                $result = $this->db->sql_query($sql);
                $stocks = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $stocks;
        }

        public function update_stock_prices()
        {
                $last_change = (int) $this->config['stock_last_change'];
                $stock_time  = (int) $this->config['stock_time'];

                if ((time() - $last_change) < $stock_time)
                {
                        return;
                }

                $min_change = max(1, (int) ($this->config['stock_min_change'] ?? 1));
                $max_change = max($min_change, (int) ($this->config['stock_max_change'] ?? 10));

                $stocks = $this->get_vault_exchange();
                foreach ($stocks as $stock)
                {
                        $variation = rand($min_change, $max_change);
                        if (rand(1, 2) === 2)
                        {
                                $variation = -$variation;
                        }

                        $new_price    = (int) ceil($stock['stock_price'] * (1 + ($variation / 100)));
                        $best_price   = max($new_price, (int) $stock['stock_best_price']);
                        $worst_price  = min($new_price, (int) $stock['stock_worst_price']);

                        $this->db->sql_query('UPDATE ' . $this->get_table('vault_exchange') . '
                                SET stock_price = ' . $new_price . ',
                                        stock_previous_price = ' . (int) $stock['stock_price'] . ',
                                        stock_best_price = ' . $best_price . ',
                                        stock_worst_price = ' . $worst_price . '
                                WHERE stock_id = ' . (int) $stock['stock_id']);
                }

                $this->config->set('stock_last_change', time());
        }

        public function get_current_battle($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT * FROM ' . $this->get_table('battle_list') . '
                                WHERE battle_challenger_id = ' . $user_id . '
                                AND battle_result = 0
                                ORDER BY battle_id DESC';
                $result = $this->db->sql_query_limit($sql, 1);
                $battle = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);
                return $battle;
        }

        public function start_monster_battle($user_id, $monster_id, array $equip_info = [])
        {
                $user_id    = (int) $user_id;
                $monster_id = (int) $monster_id;

                if ($this->get_current_battle($user_id))
                {
                        return ['success' => false, 'error' => 'ADR_BATTLE_ALREADY_IN_BATTLE'];
                }

                $char = $this->get_user_character($user_id);
                if (!$char || $char['character_hp'] <= 0)
                {
                        return ['success' => false, 'error' => 'ADR_BATTLE_DEAD'];
                }

                $sql = 'SELECT * FROM ' . $this->get_table('battle_monsters') . ' WHERE monster_id = ' . $monster_id;
                $result = $this->db->sql_query($sql);
                $monster = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$monster)
                {
                        return ['success' => false, 'error' => 'ADR_BATTLE_INVALID_MONSTER'];
                }

                $def_bonus = 0;
                $hp_bonus = 0;
                $mp_bonus = 0;

                $passive_ids = [
                        'helm'    => (int) ($equip_info['helm_id'] ?? 0),
                        'armor'   => (int) ($equip_info['armor_id'] ?? 0),
                        'gloves'  => (int) ($equip_info['gloves_id'] ?? 0),
                        'buckler' => (int) ($equip_info['buckler_id'] ?? 0),
                        'amulet'  => (int) ($equip_info['amulet_id'] ?? 0),
                        'ring'    => (int) ($equip_info['ring_id'] ?? 0),
                ];

                foreach ($passive_ids as $type => $item_id)
                {
                        if ($item_id > 0)
                        {
                                $sql = 'SELECT * FROM ' . $this->get_table('shops_items') . ' WHERE item_id = ' . $item_id . ' AND item_owner_id = ' . $user_id . ' AND item_in_shop = 0 AND item_equipped = 0';
                                $result = $this->db->sql_query($sql);
                                $item = $this->db->sql_fetchrow($result);
                                $this->db->sql_freeresult($result);

                                if ($item)
                                {
                                        if (in_array($type, ['helm', 'armor', 'gloves', 'buckler'], true))
                                        {
                                                $def_bonus += (int) $item['item_power'] + (int) $item['item_add_power'];
                                        }
                                        else if ($type === 'amulet')
                                        {
                                                $hp_bonus += (int) $item['item_power'];
                                        }
                                        else if ($type === 'ring')
                                        {
                                                $mp_bonus += (int) $item['item_power'];
                                        }
                                }
                        }
                }

                $equip_info['def_bonus'] = $def_bonus;
                $equip_info['hp_bonus']  = $hp_bonus;
                $equip_info['mp_bonus']  = $mp_bonus;

                $level_factor = max(1, $char['character_level'] / max(1, $monster['monster_level']));
                $monster_hp = (int) ($monster['monster_base_hp'] * $level_factor);

                $battle_data = [
                        'battle_type'                  => 1,
                        'battle_turn'                  => 0,
                        'battle_result'                => 0,
                        'battle_text'                  => '',
                        'battle_challenger_equip_info' => substr(json_encode($equip_info), 0, 255),
                        'battle_round'                 => 0,
                        'battle_start'                 => time(),
                        'battle_finish'                => 0,
                        'battle_challenger_id'         => $user_id,
                        'battle_monster_id'            => $monster_id,
                        'battle_challenger_hp'         => $char['character_hp'] + $hp_bonus,
                        'battle_challenger_hp_max'     => $char['character_hp_max'] + $hp_bonus,
                        'battle_challenger_mp'         => $char['character_mp'] + $mp_bonus,
                        'battle_monster_hp'            => $monster_hp,
                        'battle_monster_hp_max'        => $monster_hp,
                ];

                $this->db->sql_query('INSERT INTO ' . $this->get_table('battle_list') . ' ' .
                        $this->db->sql_build_array('INSERT', $battle_data));

                return ['success' => true, 'battle_id' => $this->db->sql_nextid()];
        }

        public function do_battle_turn($battle_id, $user_id, $action = 'attack', $item_weapon = 0, $item_spell = 0, $item_potion = 0)
        {
                $battle_id = (int) $battle_id;
                $user_id   = (int) $user_id;

                $sql = 'SELECT b.*, m.* FROM ' . $this->get_table('battle_list') . ' b
                                JOIN ' . $this->get_table('battle_monsters') . ' m ON m.monster_id = b.battle_monster_id
                                WHERE b.battle_id = ' . $battle_id . '
                                AND b.battle_challenger_id = ' . $user_id . '
                                AND b.battle_result = 0';
                $result = $this->db->sql_query($sql);
                $battle = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$battle)
                {
                        return ['success' => false, 'error' => 'ADR_BATTLE_NOT_FOUND'];
                }

                $char = $this->get_user_character($user_id);

                $equip_info = json_decode($battle['battle_challenger_equip_info'] ?? '', true);
                if (!is_array($equip_info))
                {
                        $equip_info = [];
                }

                $player_att  = $this->calc_attack($char['character_might'], $char['character_constitution']);
                $player_def  = $this->calc_defense($char['character_ac'], $char['character_dexterity']) + (int) ($equip_info['def_bonus'] ?? 0);
                $monster_att = (int) $battle['monster_base_att'];
                $monster_def = (int) $battle['monster_base_def'];

                $player_hp   = (int) $battle['battle_challenger_hp'];
                $monster_hp  = (int) $battle['battle_monster_hp'];
                $round       = (int) $battle['battle_round'] + 1;
                $log         = $battle['battle_text'];
                $result_text = '';

                $weapon_item_id  = (int) $item_weapon;
                $potion_item_id  = (int) $item_potion;
                $spell_item_id   = (int) $item_spell;

                $weapon = [];
                if ($weapon_item_id > 0)
                {
                        $sql = 'SELECT * FROM ' . $this->get_table('shops_items') . '
                                WHERE item_id = ' . $weapon_item_id . ' AND item_owner_id = ' . $user_id;
                        $result = $this->db->sql_query($sql);
                        $weapon = $this->db->sql_fetchrow($result) ?: [];
                        $this->db->sql_freeresult($result);
                }

                $potion = [];
                if ($potion_item_id > 0)
                {
                        $sql = 'SELECT * FROM ' . $this->get_table('shops_items') . '
                                WHERE item_id = ' . $potion_item_id . ' AND item_owner_id = ' . $user_id;
                        $result = $this->db->sql_query($sql);
                        $potion = $this->db->sql_fetchrow($result) ?: [];
                        $this->db->sql_freeresult($result);
                }

                $spell = [];
                if ($spell_item_id > 0)
                {
                        $sql = 'SELECT * FROM ' . $this->get_table('shops_items') . '
                                WHERE item_id = ' . $spell_item_id . ' AND item_owner_id = ' . $user_id;
                        $result = $this->db->sql_query($sql);
                        $spell = $this->db->sql_fetchrow($result) ?: [];
                        $this->db->sql_freeresult($result);
                }

                $def = false;
                $dmg_to_monster = 0;

                // Action resolution
                if ($action === 'attack')
                {
                        $weapon_power = isset($weapon['item_power']) ? (int) $weapon['item_power'] : 0;
                        $dmg_to_monster = max(1, $player_att - $monster_def + rand(-2, 2) + $weapon_power);

                        // Consume weapon durability (if this codebase uses finite durations).
                        if (!empty($weapon) && (int) ($weapon['item_duration_max'] ?? 0) !== -1 && (int) ($weapon['item_duration'] ?? 0) > 0)
                        {
                                $this->db->sql_query('UPDATE ' . $this->get_table('shops_items') . '
                                        SET item_duration = item_duration - 1
                                        WHERE item_id = ' . (int) $weapon_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration > 0');

                                $this->db->sql_query('DELETE FROM ' . $this->get_table('shops_items') . '
                                        WHERE item_id = ' . (int) $weapon_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration <= 0');
                        }
                }
                else if ($action === 'magic')
                {
                        if ($char['character_mp'] <= 0)
                        {
                                // No MP => fall back to basic attack.
                                $dmg_to_monster = max(1, $player_att - $monster_def + rand(-2, 2));
                        }
                        else
                        {
                                // Spend 1 MP for any spell cast.
                                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . ' SET character_mp = character_mp - 1 WHERE character_id = ' . $user_id);

                                $spell_type = (int) ($spell['item_type'] ?? 0);
                                $spell_power = isset($spell['item_power']) ? (int) $spell['item_power'] : 0;

                                // item_type: 11=magic_attack, 12=magic_defense
                                if ($spell_type === 11)
                                {
                                        $dmg_to_monster = max(
                                                1,
                                                $this->calc_magic_attack($char['character_intelligence']) - $this->calc_magic_defense((int) ($battle['monster_base_magic_def'] ?? 0)) +
                                                rand(-2, 2) +
                                                $spell_power
                                        );
                                }
                                else if ($spell_type === 12)
                                {
                                        // Defense spell: increase your defense for this round, no direct damage.
                                        $player_def += $spell_power;
                                        $dmg_to_monster = 0;
                                }
                                else
                                {
                                        // Unknown spell type; treat it as basic magic attack.
                                        $dmg_to_monster = max(1, $this->calc_magic_attack($char['character_intelligence']) - $this->calc_magic_defense((int) ($battle['monster_base_magic_def'] ?? 0)) + rand(-2, 2));
                                }

                                // Consume spell charges if applicable.
                                if (!empty($spell) && (int) ($spell['item_duration_max'] ?? 0) !== -1 && (int) ($spell['item_duration'] ?? 0) > 0)
                                {
                                        $this->db->sql_query('UPDATE ' . $this->get_table('shops_items') . '
                                                SET item_duration = item_duration - 1
                                                WHERE item_id = ' . (int) $spell_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration > 0');

                                        $this->db->sql_query('DELETE FROM ' . $this->get_table('shops_items') . '
                                                WHERE item_id = ' . (int) $spell_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration <= 0');
                                }
                        }
                }
                else if ($action === 'potion')
                {
                        $dmg_to_monster = 0;

                        $hp_max = (int) $battle['battle_challenger_hp_max'];
                        $mp_cur = (int) $char['character_mp'];

                        $potion_type = (int) ($potion['item_type'] ?? 0);
                        $potion_power = isset($potion['item_power']) ? (int) $potion['item_power'] : 0;
                        $restore = max(1, $potion_power * 5);

                        if ($potion_type === 15)
                        {
                                // Health potion
                                $player_hp = min($hp_max, $player_hp + $restore);
                        }
                        else if ($potion_type === 16)
                        {
                                // Mana potion
                                $mp_cur = min((int) $char['character_mp_max'], $mp_cur + $restore);
                                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                                        SET character_mp = ' . $mp_cur . '
                                        WHERE character_id = ' . $user_id);
                        }

                        // Consume potion charges if applicable.
                        if (!empty($potion) && (int) ($potion['item_duration_max'] ?? 0) !== -1 && (int) ($potion['item_duration'] ?? 0) > 0)
                        {
                                $this->db->sql_query('UPDATE ' . $this->get_table('shops_items') . '
                                        SET item_duration = item_duration - 1
                                        WHERE item_id = ' . (int) $potion_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration > 0');

                                $this->db->sql_query('DELETE FROM ' . $this->get_table('shops_items') . '
                                        WHERE item_id = ' . (int) $potion_item_id . ' AND item_owner_id = ' . $user_id . ' AND item_duration <= 0');
                        }
                }
                else if ($action === 'defend')
                {
                        // Defend: reduce damage taken this round, no direct damage. Set $def flag to halve monster attack power.
                        $def = true;
                        $dmg_to_monster = 0;
                }
                else
                {
                        // Unknown action => safe fallback.
                        $dmg_to_monster = max(1, $player_att - $monster_def + rand(-2, 2));
                }

                $dmg_to_player = max(1, $monster_att - $player_def + rand(-2, 2));
                if ($def)
                {
                        $dmg_to_player = max(1, (int) floor($dmg_to_player / 2));
                }

                $monster_hp -= (int) $dmg_to_monster;
                $player_hp  -= (int) $dmg_to_player;

                if ($action === 'defend')
                {
                        $result_text .= "Round {$round}: You choose to Defend. Monster deals {$dmg_to_player} damage.\n";
                }
                else
                {
                        $result_text .= "Round {$round}: You deal {$dmg_to_monster} damage. Monster deals {$dmg_to_player} damage.\n";
                }
                $log .= $result_text;

                $battle_result = 0;
                $rewards = [];

                if ($monster_hp <= 0 || $player_hp <= 0)
                {
                        $battle_result = ($monster_hp <= 0) ? 1 : 2;

                        if ($battle_result === 1)
                        {
                                $xp_reward   = (int) $battle['monster_xp_reward'];
                                $gold_reward = (int) $battle['monster_gold_reward'];

                                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                                        SET character_xp = character_xp + ' . $xp_reward . ',
                                                character_gold = character_gold + ' . $gold_reward . ',
                                                character_hp = ' . max(1, $player_hp) . '
                                        WHERE character_id = ' . $user_id);

                                $this->check_level_up($user_id);
                                $rewards = ['xp' => $xp_reward, 'gold' => $gold_reward];
                        }
                        else
                        {
                                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                                        SET character_hp = 1
                                        WHERE character_id = ' . $user_id);
                        }

                        $this->db->sql_query('UPDATE ' . $this->get_table('battle_list') . '
                                SET battle_result = ' . $battle_result . ',
                                        battle_finish = ' . time() . ',
                                        battle_round = ' . $round . ',
                                        battle_text = \'' . $this->db->sql_escape($log) . '\',
                                        battle_challenger_hp = ' . max(0, $player_hp) . ',
                                        battle_monster_hp = ' . max(0, $monster_hp) . '
                                WHERE battle_id = ' . $battle_id);

                        return [
                                'success'        => true,
                                'finished'       => true,
                                'result'         => $battle_result,
                                'player_hp'      => max(0, $player_hp),
                                'monster_hp'     => max(0, $monster_hp),
                                'log'            => $result_text,
                                'rewards'        => $rewards,
                        ];
                }

                $this->db->sql_query('UPDATE ' . $this->get_table('battle_list') . '
                        SET battle_round = ' . $round . ',
                                battle_text = \'' . $this->db->sql_escape($log) . '\',
                                battle_challenger_hp = ' . $player_hp . ',
                                battle_monster_hp = ' . $monster_hp . '
                        WHERE battle_id = ' . $battle_id);

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_hp = ' . $player_hp . '
                        WHERE character_id = ' . $user_id);

                return [
                        'success'    => true,
                        'finished'   => false,
                        'player_hp'  => $player_hp,
                        'monster_hp' => $monster_hp,
                        'log'        => $result_text,
                ];
        }

        public function get_character_list($start = 0, $limit = 20, $sort = 'character_level', $order = 'DESC')
        {
                $allowed_sorts = ['character_level', 'character_xp', 'character_name', 'character_creation_date'];
                if (!in_array($sort, $allowed_sorts))
                {
                        $sort = 'character_level';
                }
                $order = ($order === 'ASC') ? 'ASC' : 'DESC';

                $sql = 'SELECT c.*, u.username, u.user_colour,
                                        r.race_name, r.race_img, cl.class_name, cl.class_img,
                                        a.alignment_name, a.alignment_img, e.element_name, e.element_img
                                FROM ' . $this->get_table('characters') . ' c
                                JOIN ' . USERS_TABLE . ' u ON u.user_id = c.character_id
                                LEFT JOIN ' . $this->get_table('races') . ' r ON r.race_id = c.character_race
                                LEFT JOIN ' . $this->get_table('classes') . ' cl ON cl.class_id = c.character_class
                                LEFT JOIN ' . $this->get_table('alignments') . ' a ON a.alignment_id = c.character_alignment
                                LEFT JOIN ' . $this->get_table('elements') . ' e ON e.element_id = c.character_element
                                ORDER BY c.' . $sort . ' ' . $order;

                $result = $this->db->sql_query_limit($sql, $limit, $start);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);

                $count_sql = 'SELECT COUNT(character_id) as total FROM ' . $this->get_table('characters');
                $count_result = $this->db->sql_query($count_sql);
                $count_row = $this->db->sql_fetchrow($count_result);
                $this->db->sql_freeresult($count_result);

                return ['rows' => $rows, 'total' => (int) $count_row['total']];
        }

        public function get_pvp_battles_for_user($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT b.*,
                                        u1.username AS challenger_name,
                                        u2.username AS challenged_name
                                FROM ' . $this->get_table('battle_pvp') . ' b
                                JOIN ' . USERS_TABLE . ' u1 ON u1.user_id = b.battle_challenger_id
                                JOIN ' . USERS_TABLE . ' u2 ON u2.user_id = b.battle_challenged_id
                                WHERE b.battle_challenger_id = ' . $user_id . '
                                        OR b.battle_challenged_id = ' . $user_id . '
                                ORDER BY b.battle_id DESC';
                $result = $this->db->sql_query_limit($sql, 10);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function challenge_pvp($challenger_id, $challenged_id)
        {
                $challenger_id = (int) $challenger_id;
                $challenged_id = (int) $challenged_id;

                if ($challenger_id === $challenged_id)
                {
                        return ['success' => false, 'error' => 'ADR_PVP_SELF'];
                }

                if (!$this->character_exists($challenger_id) || !$this->character_exists($challenged_id))
                {
                        return ['success' => false, 'error' => 'ADR_NO_CHARACTER'];
                }

                $challenger = $this->get_user_character($challenger_id);
                $challenged = $this->get_user_character($challenged_id);

                $c_att = $this->calc_attack($challenger['character_might'], $challenger['character_constitution']);
                $c_def = $this->calc_defense($challenger['character_ac'], $challenger['character_dexterity']);
                $d_att = $this->calc_attack($challenged['character_might'], $challenged['character_constitution']);
                $d_def = $this->calc_defense($challenged['character_ac'], $challenged['character_dexterity']);

                $c_hp = $challenger['character_hp'];
                $d_hp = $challenged['character_hp'];
                $log = '';
                $round = 0;
                $winner = 0;

                while ($c_hp > 0 && $d_hp > 0 && $round < 50)
                {
                        $round++;
                        $dmg_to_d = max(1, $c_att - $d_def + rand(-2, 2));
                        $dmg_to_c = max(1, $d_att - $c_def + rand(-2, 2));
                        $d_hp -= $dmg_to_d;
                        $c_hp -= $dmg_to_c;
                        $log .= "Round {$round}: You deal {$dmg_to_d}, opponent deals {$dmg_to_c}.\n";
                }

                $winner = ($c_hp > $d_hp) ? $challenger_id : $challenged_id;

                $battle_data = [
                        'battle_turn'              => $round,
                        'battle_result'            => ($c_hp > 0) ? 1 : 2,
                        'battle_text'              => $log,
                        'battle_text_chat'         => '',
                        'battle_start'             => time(),
                        'battle_finish'            => time(),
                        'battle_challenger_id'     => $challenger_id,
                        'battle_challenger_att'    => $c_att,
                        'battle_challenger_def'    => $c_def,
                        'battle_challenger_hp'     => $c_hp,
                        'battle_challenger_hp_max' => $challenger['character_hp_max'],
                        'battle_challenged_id'     => $challenged_id,
                        'battle_challenged_att'    => $d_att,
                        'battle_challenged_def'    => $d_def,
                        'battle_challenged_hp'     => $d_hp,
                        'battle_challenged_hp_max' => $challenged['character_hp_max'],
                ];

                $this->db->sql_query('INSERT INTO ' . $this->get_table('battle_pvp') . ' ' .
                        $this->db->sql_build_array('INSERT', $battle_data));

                return ['success' => true, 'winner' => $winner];
        }

        public function heal_character($user_id, $cost_per_hp)
        {
                $user_id     = (int) $user_id;
                $cost_per_hp = (int) $cost_per_hp;

                $char = $this->get_user_character($user_id);
                if (!$char)
                {
                        return ['success' => false, 'error' => 'ADR_NO_CHARACTER'];
                }

                $hp_missing = $char['character_hp_max'] - $char['character_hp'];
                if ($hp_missing <= 0)
                {
                        return ['success' => false, 'error' => 'ADR_TEMPLE_FULL_HP'];
                }

                $total_cost = $hp_missing * $cost_per_hp;
                if ($char['character_gold'] < $total_cost)
                {
                        return ['success' => false, 'error' => 'ADR_LACK_POINTS', 'cost' => $total_cost];
                }

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_hp = character_hp_max,
                                character_gold = character_gold - ' . $total_cost . '
                        WHERE character_id = ' . $user_id);

                return ['success' => true, 'cost' => $total_cost, 'hp_restored' => $hp_missing];
        }

        public function restore_mp($user_id, $cost_per_mp)
        {
                $user_id     = (int) $user_id;
                $cost_per_mp = (int) $cost_per_mp;

                $char = $this->get_user_character($user_id);
                if (!$char)
                {
                        return ['success' => false, 'error' => 'ADR_NO_CHARACTER'];
                }

                $mp_missing = $char['character_mp_max'] - $char['character_mp'];
                if ($mp_missing <= 0)
                {
                        return ['success' => false, 'error' => 'ADR_TEMPLE_FULL_MP'];
                }

                $total_cost = $mp_missing * $cost_per_mp;
                if ($char['character_gold'] < $total_cost)
                {
                        return ['success' => false, 'error' => 'ADR_LACK_POINTS', 'cost' => $total_cost];
                }

                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_mp = character_mp_max,
                                character_gold = character_gold - ' . $total_cost . '
                        WHERE character_id = ' . $user_id);

                return ['success' => true, 'cost' => $total_cost, 'mp_restored' => $mp_missing];
        }

        public function heal_all_characters()
        {
                $this->db->sql_query('UPDATE ' . $this->get_table('characters') . '
                        SET character_hp = character_hp_max,
                                character_mp = character_mp_max');

                return ['success' => true];
        }

        public function reset_pvp_history()
        {
                $this->db->sql_query('DELETE FROM ' . $this->get_table('battle_pvp'));
                return ['success' => true];
        }

        public function reset_monster_battle_history()
        {
                // Only remove finished battles; keep active battles intact.
                $this->db->sql_query('DELETE FROM ' . $this->get_table('battle_list') . '
                        WHERE battle_result != 0');
                return ['success' => true];
        }

        public function get_pvp_challenges_for_user($user_id)
        {
                $user_id = (int) $user_id;
                $sql = 'SELECT b.*,
                                        u1.username AS challenger_name, u1.user_colour AS challenger_colour,
                                        u2.username AS challenged_name, u2.user_colour AS challenged_colour
                                FROM ' . $this->get_table('battle_pvp') . ' b
                                JOIN ' . USERS_TABLE . ' u1 ON u1.user_id = b.battle_challenger_id
                                JOIN ' . USERS_TABLE . ' u2 ON u2.user_id = b.battle_challenged_id
                                ORDER BY b.battle_id DESC';
                $result = $this->db->sql_query_limit($sql, 20);
                $rows = $this->db->sql_fetchrowset($result);
                $this->db->sql_freeresult($result);
                return $rows;
        }

        public function zones_table()
        {
                return $this->get_table('zones');
        }

        public function items_table()
        {
                return $this->get_table('shops_items');
        }

        public function characters_table()
        {
                return $this->get_table('characters');
        }

        public function check_seasons_cron()
        {
                $last = (int) $this->config['adr_seasons_last_time'];
                $interval = (int) $this->config['adr_seasons_time'];

                if ($last === 0)
                {
                        $this->config->set('adr_seasons_last_time', time());
                        return;
                }

                if ((time() - $last) > $interval)
                {
                        $current = (int) $this->config['adr_seasons'];
                        $next = ($current % 4) + 1;
                        $this->config->set('adr_seasons', $next);
                        $this->config->set('adr_seasons_last_time', $last + $interval);
                }
        }

        public function assign_zone_header(\phpbb\template\template $template, \phpbb\controller\helper $helper, \phpbb\user $user, $area_id, $season_folder)
        {
                $area_id = (int) $area_id;
                $sql = 'SELECT * FROM ' . $this->zones_table() . " WHERE zone_id = $area_id";
                $result = $this->db->sql_query($sql);
                $zone = $this->db->sql_fetchrow($result);
                $this->db->sql_freeresult($result);

                if (!$zone) return;

                $shops_img   = $zone['zone_shops']  ? 'shops_enable'  : 'shops_disable';
                $temple_img  = $zone['zone_temple'] ? 'temple_enable' : 'temple_disable';
                $forge_img   = $zone['zone_forge']  ? 'forge_enable'  : 'forge_disable';
                $bank_img    = $zone['zone_bank']   ? 'bank_enable'   : 'bank_disable';
                $prison_img  = $zone['zone_prison'] ? 'prison_enable' : 'prison_disable';

                $shops_link  = $zone['zone_shops']  ? '<a href="' . $helper->route('adr_rpg_shops')      . '">' . $user->lang('ADR_ZONE_GOTO_SHOPS')  . '</a>' : $user->lang('ADR_ZONE_BUILDING_DISABLE');
                $temple_link = $zone['zone_temple'] ? '<a href="' . $helper->route('adr_rpg_temple')     . '">' . $user->lang('ADR_ZONE_GOTO_TEMPLE') . '</a>' : $user->lang('ADR_ZONE_BUILDING_DISABLE');
                $forge_link  = $zone['zone_forge']  ? '<a href="' . $helper->route('adr_rpg_forge')      . '">' . $user->lang('ADR_ZONE_GOTO_FORGE')  . '</a>' : $user->lang('ADR_ZONE_BUILDING_DISABLE');
                $bank_link   = $zone['zone_bank']   ? '<a href="' . $helper->route('adr_rpg_vault')      . '">' . $user->lang('ADR_ZONE_GOTO_BANK')   . '</a>' : $user->lang('ADR_ZONE_BUILDING_DISABLE');
                $prison_link = $zone['zone_prison'] ? '<a href="' . $helper->route('adr_rpg_courthouse') . '">' . $user->lang('ADR_ZONE_GOTO_PRISON') . '</a>' : $user->lang('ADR_ZONE_BUILDING_DISABLE');

                $template->assign_vars([
                        'ZONE_SEASON_HEADER' => $season_folder,
                        'SHOPS_IMG'          => $shops_img,
                        'TEMPLE_IMG'         => $temple_img,
                        'FORGE_IMG'          => $forge_img,
                        'BANK_IMG'           => $bank_img,
                        'PRISON_IMG'         => $prison_img,
                        'SHOPS_LINK'         => $shops_link,
                        'TEMPLE_LINK'        => $temple_link,
                        'FORGE_LINK'         => $forge_link,
                        'BANK_LINK'          => $bank_link,
                        'PRISON_LINK'        => $prison_link,
                        'SHOPS_ALT'          => $user->lang('ADR_SHOPS'),
                        'TEMPLE_ALT'         => $user->lang('ADR_TEMPLE'),
                        'FORGE_ALT'          => $user->lang('ADR_FORGE'),
                        'BANK_ALT'           => $user->lang('ADR_VAULT'),
                        'PRISON_ALT'         => $user->lang('ADR_CELL'),
                ]);
        }
}
