Here you can find the Points MOD v2.1.2.

The Points MOD or Cash MOD *MUST* be installed prior to ADR installation in order to avoid errors.

You can also download the latest version of the Cash MOD from here: http://www.phpbb.com/mods/db/index.php?i=misc&mode=display&contrib_id=1703

CASH MOD INFO: You *MUST* set a currency field to 'user_points' in order for the MOD to work with ADR.