<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'Vous n\'�tes pas autoris� � visualiser cette page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';

$sql = array();
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD prefs_pvp_notif_pm TINYINT(1) DEFAULT '1' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD prefs_pvp_allow TINYINT(1) DEFAULT '1' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_armor INT(8) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_buckler INT(8) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_helm INT(8) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_gloves INT(8) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_amulet INT(8) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD equip_ring INT(8) DEFAULT '0' NOT NULL";
$sql[] = "CREATE TABLE " . $table_prefix . "adr_battle_pvp (
  battle_id int(8) NOT NULL auto_increment,
  battle_turn int(8) NOT NULL default '0',
  battle_result tinyint(1) NOT NULL default '0',
  battle_text text NOT NULL,
  battle_text_chat text NOT NULL,
  battle_challenger_id int(8) NOT NULL default '0',
  battle_challenger_att int(8) NOT NULL default '0',
  battle_challenger_def int(8) NOT NULL default '0',
  battle_challenger_hp int(8) NOT NULL default '0',
  battle_challenger_mp int(8) NOT NULL default '0',
  battle_challenger_hp_max int(8) NOT NULL default '0',
  battle_challenger_mp_max int(8) NOT NULL default '0',
  battle_challenger_hp_regen int(8) NOT NULL default '0',
  battle_challenger_mp_regen int(8) NOT NULL default '0',
  battle_opponent_id int(8) NOT NULL default '0',
  battle_opponent_att int(8) NOT NULL default '0',
  battle_opponent_def int(8) NOT NULL default '0',
  battle_opponent_hp int(8) NOT NULL default '0',
  battle_opponent_mp int(8) NOT NULL default '0',
  battle_opponent_hp_max int(8) NOT NULL default '0',
  battle_opponent_mp_max int(8) NOT NULL default '0',
  battle_opponent_hp_regen int(8) NOT NULL default '0',
  battle_opponent_mp_regen int(8) NOT NULL default '0',
  PRIMARY KEY  (battle_id)
) TYPE=MyISAM";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('battle_pvp_enable', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('battle_pvp_defies_max', '5')";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_exp_min', 10)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_exp_max', 40)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_exp_modifier', 120)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_reward_min', 10)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_reward_max', 40)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('pvp_base_reward_modifier', 120)";


for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Erreur:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Termin� avec succ�s</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">Success</td></tr>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>