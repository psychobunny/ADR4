There are two upgrade files here to help break down the upgrade process slightly. 


##=== Here's the explaination of each file: ===##

"upgrade_part1.txt" - these code changes are known bug issues which have been previously fixed & posted at the ADR Support forums. The bug fixes have a number reference assigned so you can find out if you've previously added the fix or not.
"upgrade_part2.txt" - these code changes are ESSENTIAL and are part of the upgrade process.


****** Zone MOD users: PLEASE NOTE ******

I CANNOT help with any issues resulting from the upgrade since I do NOT support any Zone MODifcation. 

This upgrade is supported for a vanilla ADR install only.