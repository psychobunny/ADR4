There are four upgrade files here to help break down the upgrade process slightly. 


##=== Here's the explaination of each file: ===##

"upgrade_part1.txt" - the changes in this file have been previously posted at the ADR support forum under the 'v0.4.3 bug fixes thread', so if you find you already have most of the changes in this file already done then you know why.
"upgrade_part2.txt" - these changes are ESSENTIAL and are part of the upgrade process.
"upgrade_part3.txt" - these changes are ESSENTIAL and are part of the upgrade process.
"upgrade_part4.txt" - these changes are late additions to the upgrade & are ESSENTIAL to the upgrade process.


##=== IMPORTANT SCRIPTS TO RUN AFTER FILE MODIFICATION ===##
1. Run the file "adr_db_update_044.php" through your browser.




******Zone MOD users: PLEASE NOTE******

I canNOT help with any issues resulting from the upgrade since I do NOT support any Zone MODifcation. 

This upgrade is supported for a vanilla ADR install only.