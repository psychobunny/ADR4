<?php
/***************************************************************************
 *                               adr_db_update_044.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=adr_db_update_042.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}

$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$sql = array();
$sql[] = "UPDATE " . $table_prefix . "adr_general SET `config_value` = '0' WHERE `config_name` = 'Adr_disable_rpg'";
$sql[] = "UPDATE " . $table_prefix . "config SET `config_value` = '0.4.4' WHERE `config_name` = 'Adr_version'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_align_enable tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_align varchar(255) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_class_enable tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_class varchar(255) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_element_enable tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_element varchar(255) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_race_enable tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_race varchar(255) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_level int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_str int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_dex int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_int int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_wis int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_cha int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_restrict_con int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_crit_hit smallint(3) NOT NULL default '20'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_crit_hit_mod smallint(3) NOT NULL default '2'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_stolen_timestamp int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_stolen_by varchar(255) NOT NULL default ''";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_donated_timestamp int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_donated_by varchar(255) NOT NULL default ''";

$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_shop_steal_sell', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_shop_steal_min_lvl', 5)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_shop_steal_show', 0)";

$sql[] = "CREATE TABLE " . $table_prefix . "adr_stores_user_history(
  user_store_trans_id int(12) NOT NULL default '0',
  user_store_owner_id int(8) NOT NULL default '0',
  user_store_info TEXT NOT NULL default '',
  user_store_total_price int(12) NOT NULL default '0',
  user_store_date int(12) NOT NULL default '0',
  user_store_buyer TEXT NOT NULL default '',
  PRIMARY KEY(user_store_trans_id, user_store_owner_id)
) TYPE=MyISAM";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successful!</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">The database upgrade from ADR v0.4.3 to v0.4.4 has been successfully completed.<br><br>Please be sure to delete this file from your server now for security.<br />If you have run into any errors, please visit the <a href="http://www.adr-support.com/adr_support/index.php" target="_blank">ADR Support Forms</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Please be sure to also apply the code changes to complete the upgrade process!</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>
