There are three upgrade files here to help break down the upgrade process slightly.

Here's the explaination of each file:

"upgrade_part1.txt" - the changes in this file have been previously posted at the ADR support forum under the 'v0.4.0 bug fixes thread', so if you find you already have most of the changes in this file already done then you know why.

"upgrade_part2.txt" - these changes are ESSENTIAL and are part of the upgrade process.




******Zone MOD user please note!******

I CANNOT help with any issues resulting from the upgrade since I do NOT support any Zone MODifcation. 

This upgrade is supported for a vanilla ADR install only.