There are  upgrade files here to help break down the upgrade process slightly. 


##=== Here's the explaination of each file: ===##

"upgrade_part1.txt" - the changes in this file have been previously posted at the ADR support forum under the 'v0.4.4 bug fixes thread', so if you find you already have most of the changes in this file already done then you know why.
"upgrade_part2.txt" - these changes are OPTIONAL but RECOMMENDED and are part of the upgrade process to increase PHP5 compatibility.
"upgrade_part3.txt" - this adds the Battle & Imprison Check mod. If you already have this mod installed, you may have done these changes already.
"upgrade_part4.txt" - this adds Ethalic's page session mod to the standard ADR. If you already have this mod installed, you may have done these changes already.
"upgrade_part5.txt" - this adds vash1486's Item Type Advanced Management mod. If you already have this mod installed, you may have done these changes already.
"upgrade_part6.txt" - this replaces some hardcoded hp/mp text with language keys, adds Bootenks adr_functions_cache fic (you may have already done this part) and replaces several SELECT * queries in ACP
"upgrade_part7.txt" - this fixes a couple of potential security holes
"upgrade_part8.txt" - fixes various errors in the language files



##=== IMPORTANT SCRIPTS TO RUN AFTER FILE MODIFICATION ===##


adr_db_update_045.php


******Zone MOD users: PLEASE NOTE******

This upgrade is supported for a vanilla ADR install only.