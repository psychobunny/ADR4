There are three upgrade files here to help break down the upgrade process slightly.

Here's the explaination of each file:

"upgrade_part1.txt" - the changes in this file have been previously posted at the ADR support forum under the 'v0.3.4 bug fixes thread', so if you find you already have most of the changes in this file already done then you know why.

"upgrade_part2.txt" - these changes are ESSENTIAL and are part of teh full upgrade process.

"upgrade_part3.txt" - these changes are ESSENTIAL and are part of teh full upgrade process.

#IMPORTANT AFTER UPGRADE: thre are major changes to the monster & PvP battles chat boxes. You may notice odd things when viewing a battle that was created before this upgrade took place. Advise all users to end their current monster & PvP battles. This will correct the issue.



******Zone MOD user please note!******

You are HIGHLY likely to hit numerous issues with this upgrade due to the amount of changes made by the Zone Modification. I CANNOT help with this since I do NOT use the Modification. This upgrade is supported for a vanilla ADR only.