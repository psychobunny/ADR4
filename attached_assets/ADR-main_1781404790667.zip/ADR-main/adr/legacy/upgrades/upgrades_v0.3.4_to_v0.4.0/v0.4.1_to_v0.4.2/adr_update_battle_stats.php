<?php
/***************************************************************************
 *                               adr_update_battle_stats.php
 *                            -------------------
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
 
define('IN_PHPBB', true);
define('IN_ADR_CHARACTER', true);
define('IN_ADR_BATTLE', true);
define('IN_ADR_PVP', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);
include($phpbb_root_path . 'adr/includes/adr_global.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if (!$userdata['session_logged_in'])
{
	header('Location: ' . append_sid("login.$phpEx?redirect=adr_update_battle_stats.$phpEx", true));
}

if ($userdata['user_level'] != ADMIN)
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo 'Updating the database...this could take a few minutes to complete depending on the size of your database...<span class="genmed"><ul type="circle">';

$sql = "SELECT character_id FROM " . ADR_CHARACTERS_TABLE;
if (!$result = $db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not char infos', '', __LINE__, __FILE__, $sql);}
$users = $db->sql_fetchrowset($result);
$total_users = count($users);

$sql = "SELECT battle_challenger_id, battle_id, battle_result FROM " . ADR_BATTLE_LIST_TABLE;
if (!$result = $db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not grab monster battle infos', '', __LINE__, __FILE__, $sql);}
$mon_battles = $db->sql_fetchrowset($result);
$total_mon_battles = count($mon_battles);

$sql = "SELECT battle_challenger_id, battle_opponent_id, battle_result FROM " . ADR_BATTLE_PVP_TABLE;
if (!$result = $db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not grab PvP infos', '', __LINE__, __FILE__, $sql);}
$battle_pvp = $db->sql_fetchrowset($result);
$total_pvp_battles = count($battle_pvp);

// Reset monster battle stat for user
$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
	SET character_victories = 0,
		character_defeats = 0,
		character_flees = 0,
		character_victories_pvp = 0,
		character_defeats_pvp = 0,
		character_flees_pvp = 0";
if (!$db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not reset character monster stats', '', __LINE__, __FILE__, $sql);}

for($i = 0; $i < $total_users; $i++)
{
	$character_id = $users[$i]['character_id'];

	for($b = 0; $b < $total_mon_battles; $b++)
	{
		if($character_id === $mon_battles[$b]['battle_challenger_id'])
		{
			$battle_id = $mon_battles[$b]['battle_id'];
			$result = $mon_battles[$b]['battle_result'];

			if($result == '1')
			{
				$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
					SET character_victories = (character_victories + 1)
					WHERE character_id = '$character_id'";
				if (!$db->sql_query($sql)){
					message_die(GENERAL_ERROR, 'Could not update monster_ wins', '', __LINE__, __FILE__, $sql);}
			}
			if($result == '2')
			{
				$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
					SET character_defeats = (character_defeats + 1)
					WHERE character_id = '$character_id'";
				if (!$db->sql_query($sql)){
					message_die(GENERAL_ERROR, 'Could not update monster_defeats', '', __LINE__, __FILE__, $sql);}
			}
			if($result == '3')
			{
				$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
					SET character_flees = (character_flees + 1)
					WHERE character_id = '$character_id'";
				if (!$db->sql_query($sql)){
					message_die(GENERAL_ERROR, 'Could not update monster_flees', '', __LINE__, __FILE__, $sql);}
			}
		}
	}

	for($c = 0; $c < $total_pvp_battles; $c++)
	{
		$result = $battle_pvp[$c]['battle_result'];

		if((($character_id == $battle_pvp[$c]['battle_challenger_id']) && ($result == '1')) || (($character_id == $battle_pvp[$c]['battle_opponent_id']) && ($result == '2')) || (($character_id == $battle_pvp[$c]['battle_challenger_id']) && ($result == '5')) || (($character_id == $battle_pvp[$c]['battle_opponent_id']) && ($result == '6')))
		{
			$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
				SET character_victories_pvp = (character_victories_pvp + 1)
				WHERE character_id = '$character_id'";
			if (!$db->sql_query($sql)){
				message_die(GENERAL_ERROR, 'Could not update pvp victories', '', __LINE__, __FILE__, $sql);	}
		}
		elseif((($character_id == $battle_pvp[$c]['battle_challenger_id']) && ($result == '2')) || (($character_id == $battle_pvp[$c]['battle_opponent_id']) && ($result == '1')))
		{
			$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
				SET character_defeats_pvp = (character_defeats_pvp + 1)
				WHERE character_id = '$character_id'";
			if (!$db->sql_query($sql)){
				message_die(GENERAL_ERROR, 'Could not update pvp defeats', '', __LINE__, __FILE__, $sql);}
		}
		elseif((($character_id == $battle_pvp[$c]['battle_challenger_id']) && ($result == '8')) || (($character_id == $battle_pvp[$c]['battle_opponent_id']) && ($result == '9')) || (($character_id == $battle_pvp[$c]['battle_challenger_id']) && ($result == '6')) || (($character_id == $battle_pvp[$c]['battle_opponent_id']) && ($result == '5')))
		{
			$sql = "UPDATE " . ADR_CHARACTERS_TABLE ."
				SET character_flees_pvp = (character_flees_pvp + 1)
				WHERE character_id = '$character_id'";
			if (!$db->sql_query($sql)){
				message_die(GENERAL_ERROR, 'Could not update pvp flees', '', __LINE__, __FILE__, $sql);}
		}
	}
}

message_die(GENERAL_MESSAGE, 'Successfully completed seperating Monster & PvP battles stats.<br><br><b><u><font size="+3">YOU MUST ONLY RUN THIS SCRIPT ONCE!</font></u></b><br><br>Running this more than once will mess up all of your users battle statistics!');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
?>
