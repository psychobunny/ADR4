<?php
/***************************************************************************
 *                               dadr_db_update_042.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *   project              : http://sourceforge.net/projects/dbgenerator
 *   Website              : http://freakingbooty.no-ip.com/ & http://www.rapiddr3am.net
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=adr_db_update_042.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

$sql = array();
$sql[] = "UPDATE " . $table_prefix . "adr_general SET `config_value` = '0' WHERE `config_name` = 'Adr_disable_rpg'";
$sql[] = "UPDATE " . $table_prefix . "config SET `config_value` = '0.4.2' WHERE `config_name` = 'Adr_version'";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_cache_interval', 15)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_cache_last_updated', 0)";
$sql[] = "UPDATE " . $table_prefix . "config SET `config_value` = '0-0-0-0-0-0-0-0-0' WHERE `config_name` = 'Adr_use_cache_system'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_victories_pvp int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_defeats_pvp int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_flees_pvp int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_fp int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items CHANGE `item_stolen` `item_stolen_id` INT(12) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_bought_timestamp int(12) NOT NULL default '0'";
$sql[] = "UPDATE " . $table_prefix . "adr_battle_list SET battle_text = '' WHERE battle_result != 0";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_equipment_info varchar(255) NOT NULL default ''";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_round int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_start int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_finish int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_start int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_finish int(12) NOT NULL default '0'";
$sql[] = "UPDATE " . $table_prefix . "adr_battle_pvp SET battle_text = '' WHERE battle_result != 3";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_colour varchar(255) NOT NULL default ''";
$sql[] = "CREATE TABLE " . $table_prefix . "adr_stores_stats(
  store_stats_character_id int(12) NOT NULL default '0',
  store_stats_store_id int(12) NOT NULL default '0',
  store_stats_buy_total int(12) NOT NULL default '0',
  store_stats_buy_last int(12) NOT NULL default '0',
  store_stats_sold_total int(12) NOT NULL default '0',
  store_stats_sold_last int(12) NOT NULL default '0',
  store_stats_stolen_item_total int(12) NOT NULL default '0',
  store_stats_stolen_item_fail_total int(12) NOT NULL default '0',
  store_stats_stolen_item_last int(12) NOT NULL default '0',
  store_stats_stolen_points_total int(12) NOT NULL default '0',
  store_stats_stolen_points_last int(12) NOT NULL default '0',
  PRIMARY KEY  (store_stats_character_id, store_stats_store_id)
) TYPE=MyISAM";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successful!</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">The database upgrade from ADR v0.4.1 to v0.4.2 has completed. Please be sure to delete this file from your server now for security.<br />If you have run into any errors, please visit the <a href="http://www.adr-support.com/adr_support/index.php" target="_phpbbsupport">ADR Support Forms</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Please be sure to also apply the code changes to complete the upgrade process!</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>
