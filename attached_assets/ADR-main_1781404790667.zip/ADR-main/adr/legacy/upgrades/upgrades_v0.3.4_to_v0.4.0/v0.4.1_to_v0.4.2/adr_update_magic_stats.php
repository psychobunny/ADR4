<?php
/***************************************************************************
 *                               update_magic_stats.php
 *                            -------------------
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/
 
define('IN_PHPBB', true);
define('IN_ADR_CHARACTER', true);
$phpbb_root_path='./';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);
include($phpbb_root_path . 'adr/includes/adr_global.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if (!$userdata['session_logged_in'])
{
	header('Location: ' . append_sid("login.$phpEx?redirect=adr_update_magic_stats.$phpEx", true));
}

if ($userdata['user_level'] != ADMIN)
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}

include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<span class="gen">Updating the database...this could take a few minutes to complete depending on the size of your database...</span><span class="genmed"><ul type="circle">';

// Grab MA & MR stats
$sql = "SELECT character_id, character_magic_attack, character_magic_resistance, character_intelligence, character_wisdom
		FROM " . ADR_CHARACTERS_TABLE;
if (!$result = $db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not grab character stats', '', __LINE__, __FILE__, $sql);}
$char_stats = $db->sql_fetchrowset($result);
$total_stats = count($char_stats);

$sql = "SELECT character_id FROM " . ADR_CHARACTERS_TABLE;
if (!$result = $db->sql_query($sql)){
	message_die(GENERAL_ERROR, 'Could not!', '', __LINE__, __FILE__, $sql);}
$users = $db->sql_fetchrowset($result);
$total_users = count($users);

for($i = 0; $i < $total_users; $i++)
{
	$character_id = $users[$i]['character_id'];

	for($x = 0; $x < $total_stats; $x++)
	{
		if($character_id === $char_stats[$x]['character_id'])
		{
			$ma_orig = $char_stats[$x]['character_magic_attack'];
			$ma = ($ma_orig > '10') ? ($ma_orig - 10) : 0;
			$ma = ($ma < '0') ? 0 : $ma;

			$md_orig = $char_stats[$x]['character_magic_resistance'];
			$md = ($md_orig > '10') ? ($md_orig - 10) : 0;
			$md = ($md < '0') ? 0 : $md;

			$int = ($char_stats[$x]['character_intelligence'] + $ma);
			$wis = ($char_stats[$x]['character_wisdom'] + $md);

			$sql = "UPDATE " . ADR_CHARACTERS_TABLE . "
				SET character_intelligence = $int,
					character_wisdom = $wis
				WHERE character_id = '$character_id'";
			if (!$db->sql_query($sql)){
				message_die(GENERAL_ERROR, 'Could not update magic stats', '', __LINE__, __FILE__, $sql);}
		}
	}
}

// Remove old columns from database
$sqla = "ALTER TABLE " . ADR_CHARACTERS_TABLE . "
		DROP character_magic_attack";
if (!$result = $db->sql_query($sqla))
{
	message_die(GENERAL_ERROR, 'Could not remove magic_attack column', '', __LINE__, __FILE__, $sql);
}

$sqlb = "ALTER TABLE " . ADR_CHARACTERS_TABLE . "
		DROP character_magic_resistance";
if (!$result = $db->sql_query($sqlb))
{
	message_die(GENERAL_ERROR, 'Could not remove magic_resistance column', '', __LINE__, __FILE__, $sql);
}

message_die(GENERAL_MESSAGE, 'Finished updating Magic stats.');
include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
?>
