There are three upgrade files here to help break down the upgrade process slightly. 

This is a big upgrade to add a few much needed cosmetic touches, changing some unnecessary stats and doing lots of sql & code optimising for faster battle page loading.


##=== Here's the explaination of each file: ===##

"upgrade_part1.txt" - the changes in this file have been previously posted at the ADR support forum under the 'v0.4.1 bug fixes thread', so if you find you already have most of the changes in this file already done then you know why.
"upgrade_part2.txt" - these changes are ESSENTIAL and are part of the upgrade process.
"upgrade_part3.txt" - these changes are ESSENTIAL and are part of the upgrade process.
"upgrade_part4.txt" - these changes were very late additions to the upgrade. These changes are ESSENTIAL and are part of the upgrade process.


##=== IMPORTANT SCRIPTS TO RUN AFTER FILE MODIFICATION ===##
1. Run the file "adr_db_update_042.php" through your browser,
2. Run the file "adr_update_battle_stats.php" through your browser - be sure to run only ONCE & delete from your server afterwards!
3. Run the file "adr_update_magic_stats.php" through your browser - be sure to run only ONCE & delete from your server afterwards!




******Zone MOD users: PLEASE NOTE******

I canNOT help with any issues resulting from the upgrade since I do NOT support any Zone MODifcation. 

This upgrade is supported for a vanilla ADR install only.