UPGRADE README FOR v0.3.3 to v0.3.4:
<><><><><><><><><><><><><><><><><><>

==============================
 1. upgrade_common_part_1.txt: 
==============================

All fixes in this file should be installed on every type of upgrade from v0.3.3 to v0.3.4. 



================================
 2. upgrade_optional_part_2.txt:  
================================

All the code changes in this file are optional.

When upgrading, you can either overwrite the files stated at the begining of the file to complete the upgrade or you can manually do all the code changes listed in this file.