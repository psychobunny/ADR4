<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();

$sql[] = "ALTER TABLE " . $table_prefix . "users ADD user_adr_ban tinyint(1) default '0' NOT NULL";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('posts_enable', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('battle_calc_type', 1)";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_sell_back_percentage int(3) NOT NULL default '75'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_pref_give_pm tinyint(1) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_pref_seller_pm tinyint(1) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_double_ko int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_pref_give_pm tinyint(1) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters DROP character_limit_update";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_limit_update int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_mining character_skill_mining INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_stone character_skill_stone INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_forge character_skill_forge INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_enchantment character_skill_enchantment INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_trading character_skill_trading INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_thief character_skill_thief INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_mining_uses character_skill_mining_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_stone_uses character_skill_stone_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_forge_uses character_skill_forge_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_enchantment_uses character_skill_enchantment_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_trading_uses character_skill_trading_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters CHANGE character_skill_thief_uses character_skill_thief_uses INT(3) UNSIGNED DEFAULT '0' NOT NULL";

$sql[] = "CREATE TABLE " . $table_prefix . "adr_create_exploit_fix (
  user_id int(10) NOT NULL default '0',
  power int(8) NOT NULL default '0',
  agility int(8) NOT NULL default '0',
  endurance int(8) NOT NULL default '0',
  intelligence int(8) NOT NULL default '0',
  willpower int(8) NOT NULL default '0',
  charm int(8) NOT NULL default '0',
  magic_attack int(8) NOT NULL default '0',
  magic_resistance int(8) NOT NULL default '0',
  PRIMARY KEY  (user_id)
) TYPE=MyISAM";


for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfully updated database</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">The upgrade has completed. Please be sure to delete this file.<br />If you have run into any errors, please visit the <a href="http://www.thegamingforum.com/adr" target="_phpbbsupport">thegamingforum.com/adr</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Enjoy!</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>