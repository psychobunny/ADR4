<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2003 Freakin' Booty ;-P & Antony Bailey
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';

$current_time = time();


$sql = array();
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_disable_rpg', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_limit_regen_duration', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_character_battle_limit', 20)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_character_skill_limit', 30)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_character_trading_limit', 30)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('Adr_character_thief_limit', 10)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('weight_enable', 1)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('battle_base_sp_modifier', 120)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('posts_min', 0)";
$sql[] = "INSERT INTO " . $table_prefix . "adr_general (config_name, config_value) VALUES ('stock_time', 86400)";

$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_time_start', '$current_time')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_character_age', '16')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_skill_sp_enable', '0')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_character_sp_enable', '0')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_thief_enable', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_thief_points', '5')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_warehouse_duration', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_warehouse_tax', '0')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_shop_duration', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('Adr_shop_tax', '0')";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_birth int(12) NOT NULL default '$current_time'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_limit_update int(8) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_battle_limit int(3) NOT NULL default '20'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_skill_limit int(3) NOT NULL default '30'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_trading_limit int(3) NOT NULL default '30'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_thief_limit int(3) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_sp int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_magic_attack int(8) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_magic_resistance int(8) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_warehouse tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_warehouse_update int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_shop_update int(8) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_magic_attack int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_magic_resistance int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_dmg int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_magic_attack int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_magic_resistance int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_mp_power int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_sp int(12) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_dmg int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_hp_max int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_mp_max int(8) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_challenger_dmg int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_opponent_dmg int(8) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_mp int(8) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_mp_power int(8) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_custom_spell varchar(255) NOT NULL default 'a magical spell'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_magic_attack int(8) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_magic_resistance int(8) NOT NULL default '10'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_sp int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_thief_skill int(3) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_classes ADD class_magic_attack_req int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_classes ADD class_magic_resistance_req int(8) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_magic_attack_bonus int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_magic_resistance_bonus int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_magic_attack_malus int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_magic_resistance_malus int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_weight int(12) NOT NULL default '1000'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_weight_per_level int(3) NOT NULL default '5'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_challenger_magic_attack int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_challenger_magic_resistance int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_opponent_magic_attack int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_opponent_magic_resistance int(8) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_oppose_strong int(3) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_oppose_strong_dmg int(3) NOT NULL default '100'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_oppose_same_dmg int(3) NOT NULL default '100'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_oppose_weak int(3) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_elements ADD element_oppose_weak_dmg int(3) NOT NULL default '100'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_challenger_element int(3) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_pvp ADD battle_opponent_element int(3) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_base_element int(3) NOT NULL default '1'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_element int(3) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_element int(3) NOT NULL default '0'";

$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_element int(4) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_element_str_dmg int(4) NOT NULL default '100'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_element_same_dmg int(4) NOT NULL default '100'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_element_weak_dmg int(4) NOT NULL default '100'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_store_id int(8) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_weight int(12) NOT NULL default '25'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_auth int(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_max_skill int(8) NOT NULL default '25'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_add_power int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_mp_use int(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_monster_thief tinyint(1) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_in_warehouse tinyint(1) NOT NULL default '0'";

$sql[] = "CREATE TABLE " . $table_prefix . "adr_stores (
  store_id int(8) NOT NULL auto_increment,
  store_name varchar(100) NOT NULL default '',
  store_desc varchar(255) NOT NULL default '',
  store_img varchar(255) NOT NULL default '',
  store_status tinyint(1) NOT NULL default '1',
  store_sales_status tinyint(1) NOT NULL default '0',
  store_admin tinyint(1) NOT NULL default '0',
  store_owner_id int(1) NOT NULL default '1',
  KEY store_id (store_id)
) TYPE=MyISAM";

$sql[] = "INSERT INTO " . $table_prefix . "adr_stores(store_id, store_name, store_desc, store_img, store_status, store_sales_status, store_admin) VALUES(1, 'Forum 
Store', 'The general forum store', '',1 ,0 ,0 )";
$sql[] = "INSERT INTO " . $table_prefix . "adr_stores(store_name, store_desc, store_img, store_status, store_sales_status, store_admin) VALUES('Admin Only Store', 
'Viewable only by the board admin', '',1 ,0 ,1 )";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successfully updated database</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>End</th></tr><tr><td><span class="genmed">The upgrade has completed. Please be sure to delete this file.<br />If you have run into any errors, please visit the <a href="http://www.thegamingforum.com/adr" target="_phpbbsupport">thegamingforum.com/adr</a> and ask someone for help.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Enjoy!</a></span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>