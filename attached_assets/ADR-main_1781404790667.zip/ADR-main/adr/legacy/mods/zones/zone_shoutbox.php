<head>
<style>
//Shoutbox style
<!--
div.chat
{
overflow: auto;
width: 970px;
height: 150px;
border: 1px #757575 solid;
padding: 3px;
background: #EEEEEE;
}
div.miniform
{
width: 200px;
border: 1px #757575 solid;
border-top: 0px;
padding: 3px;
background: #EEEEEE;
text-align: center;
}
.date
{
color: #757575;
font-family:Arial;
font-weight:bold;
font-size: 8pt
}
.pseudo
{
color: #2E19D7;
font-family: Arial;
font-size: 8pt;
font-weight: bold;
text-decoration: underline;
text-transform: capitalize;
}
.msg
{color: #757575;
font-family: Arial;
font-size: 8pt;
font-weight: normal;
text-decoration: none
}
hr.chat
{
height: 1px #D7192E dotted;
border: 1px #D7192E dotted;
}
-->
</style>
</head>
<?php

$msg = array();
function file_save($filename, $content, $flags = 0)
{if (!($file = fopen($filename, 'w')))
     return FALSE;
$n = fwrite($file, $content);
fclose($file);
return $n ? $n : FALSE;
}

if (!file_exists("./zone_chat.php")) file_save("./zone_chat.php","<?php\n\$msg = ".var_export($msg,TRUE)."\n?>");

include "zone_chat.php";

while (count($msg) >= 10) array_shift($msg);

$canpost = empty($_POST['submit']) ? 'refresh' : $_POST['submit'];
$canpost = ($canpost == 'refresh') ? 0 : 1;
if (!empty($_POST['mess']) && !empty($_POST['pseudo']) && $canpost)
{$i = count($msg);
$msg[$i]['pseudo'] = htmlentities($_POST['pseudo']);
$msg[$i]['texte'] = htmlentities($_POST['mess']);
$msg[$i]['date'] = time();
}

$msg2 = array_reverse($msg);
echo '<div class="chat">';
foreach ($msg2 as $message)
{echo '<span class="pseudo">'.$message['pseudo'].'</span> <span class="date">['.date("d/m/y � H:i:s",$message['date']).']</span><br /><span class="msg">'.nl2br($message['texte']).'<br /><hr class="chat">';
}
echo "</div>";

file_save("./zone_chat.php", "<?php\n\$msg = ".var_export($msg,TRUE)."\n?>");

?>
<table width="100%" align="center" border="1">
	<tr>
		<th align="center" colspan="2" ></td>
	</tr>
</table>
Zone MOD by : <a href="http://www.mangas-no-ushi.com/" target="_blank">One_Piece</a>