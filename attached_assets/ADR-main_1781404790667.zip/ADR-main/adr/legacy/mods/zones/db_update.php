<?php
/***************************************************************************
 *                               db_update.php
 *                            -------------------
 *
 *   copyright            : �2007 Ethalic
 *   Website              : http://phpbb.insyderonline.com
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

define('IN_PHPBB', true);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'common.'.$phpEx);

//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//


if( !$userdata['session_logged_in'] )
{
	$header_location = ( @preg_match('/Microsoft|WebSTAR|Xitami/', getenv('SERVER_SOFTWARE')) ) ? 'Refresh: 0; URL=' : 'Location: ';
	header($header_location . append_sid("login.$phpEx?redirect=db_update.$phpEx", true));
	exit;
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, 'You are not authorised to access this page');
}


$page_title = 'Updating the database';
include($phpbb_root_path . 'includes/page_header.'.$phpEx);

echo '<table width="100%" cellspacing="1" cellpadding="2" border="0" class="forumline">';
echo '<tr><th>Updating the database</th></tr><tr><td><span class="genmed"><ul type="circle">';


$sql = array();
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('adr_seasons', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('adr_seasons_time', '86400')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('adr_seasons_last_time', '0')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('zone_bonus_enable', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('zone_bonus_att', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('zone_bonus_def', '1')";
$sql[] = "INSERT INTO " . $table_prefix . "config (config_name, config_value) VALUES ('zone_dead_travel', '1')";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_zone_begin INT(8) NOT NULL default '1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_races ADD race_zone_name VARCHAR( 255 ) DEFAULT '' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_zone INT(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_shops_items ADD item_zone_name VARCHAR( 255 ) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_challenger_intelligence INT(8) NOT NULL default '0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_message_enable INT(1) NOT NULL default ''";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_message VARCHAR( 255 ) DEFAULT '' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_list ADD battle_opponent_item VARCHAR( 255 ) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_area int(8) NOT NULL default'0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_season int(8) NOT NULL default'0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_weather int(8) NOT NULL default'0'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_item VARCHAR( 255 ) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_message_enable int(1) NOT NULL default''";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_message VARCHAR( 255 ) DEFAULT '' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_battle_monsters ADD monster_area_name VARCHAR( 255 ) DEFAULT '0' NOT NULL";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_area int(8) NOT NULL default'1'";
$sql[] = "ALTER TABLE " . $table_prefix . "adr_characters ADD character_weather int(8) NOT NULL default'1'";
$sql[] = "CREATE TABLE `" . $table_prefix . "adr_zones` (
`zone_id` INT( 8 ) DEFAULT '0' NOT NULL ,
`zone_name` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`zone_desc` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`zone_img` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`zone_element` VARCHAR( 255 ) NOT NULL ,
`zone_item` VARCHAR( 255 ) DEFAULT '0' NOT NULL ,
`cost_goto1` INT( 8 ) DEFAULT '0' NOT NULL ,
`cost_goto2` INT( 8 ) DEFAULT '0' NOT NULL ,
`cost_return` INT( 8 ) DEFAULT '0' NOT NULL ,
`goto1_name` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`goto2_name` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`return_name` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`zone_shops` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_forge` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_prison` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_temple` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_bank` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event1` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event2` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event3` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event4` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event5` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event6` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event7` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_event8` INT( 1 ) DEFAULT '0' NOT NULL ,
`zone_pointwin1` INT( 8 ) DEFAULT '0' NOT NULL ,
`zone_pointwin2` INT( 8 ) DEFAULT '0' NOT NULL ,
`zone_pointloss1` INT( 8 ) DEFAULT '0' NOT NULL ,
`zone_pointloss2` INT( 8 ) DEFAULT '0' NOT NULL ,
`zone_chance` INT( 8 ) DEFAULT '0' NOT NULL ,
`npc_price` INT( 8 ) DEFAULT '0' NOT NULL ,
`npc1_enable` INT( 1 ) DEFAULT '0' NOT NULL ,
`npc2_enable` INT( 1 ) DEFAULT '0' NOT NULL ,
`npc3_enable` INT( 1 ) DEFAULT '0' NOT NULL ,
`npc4_enable` INT( 1 ) DEFAULT '0' NOT NULL ,
`npc5_enable` INT( 1 ) DEFAULT '0' NOT NULL ,
`npc1_message` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`npc2_message` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`npc3_message` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`npc4_message` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
`npc5_message` VARCHAR( 255 ) DEFAULT '' NOT NULL ,
PRIMARY KEY ( `zone_id` )
) TYPE = MYISAM";
$sql[] = "INSERT INTO phpbb_adr_zones ( zone_id , zone_name , zone_desc, zone_img , zone_element, cost_goto1, cost_goto2, cost_return, goto1_name, goto2_name, return_name, zone_shops , zone_forge , zone_prison , zone_temple, zone_bank, zone_event1, zone_event2, zone_event3, zone_event4, zone_event5, zone_event6, zone_event7, zone_event8, zone_pointwin1, zone_pointwin2, zone_pointloss1, zone_pointloss2, zone_chance, npc_price, npc1_enable, npc2_enable, npc3_enable, npc4_enable, npc5_enable, npc1_message, npc2_message, npc3_message, npc4_message, npc5_message ) VALUES ( 1 , 'The Imperial City' , 'The capital city on the island in Lake Rumare. It is split into 12 districts.' , 'imperialcity' , 'element test' , 0 , 0 , 0 , 'The Imperial City' , '' , '' , 1 , 1 , 1 , 1 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 10 , 20 , 10 , 20 , 20 , 0 , 1 , 0 , 0 , 0 , 0 , 'this is a test message' , '' , '' , '' , '' )";

for( $i = 0; $i < count($sql); $i++ )
{
	if( !$result = $db->sql_query ($sql[$i]) )
	{
		$error = $db->sql_error();

		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#FF0000"><b>Error:</b></font> ' . $error['message'] . '</li><br />';
	}
	else
	{
		echo '<li>' . $sql[$i] . '<br /> +++ <font color="#00AA00"><b>Successful</b></font></li><br />';
	}
}


echo '</ul></span></td></tr><tr><td class="catBottom" height="28">&nbsp;</td></tr>';

echo '<tr><th>Installation Complete</th></tr><tr><td><span class="genmed">Please be sure to delete this file now.<br />If you require any further assistance, please visit the <a href="http://www.phpbb.insyderonline.com/forums">Cataclysm Designs Support Forum</a>.</span></td></tr>';
echo '<tr><td class="catBottom" height="28" align="center"><span class="genmed"><a href="' . append_sid("index.$phpEx") . '">Go back to your index page</a>.</span></td></table>';

include($phpbb_root_path . 'includes/page_tail.'.$phpEx);

?>