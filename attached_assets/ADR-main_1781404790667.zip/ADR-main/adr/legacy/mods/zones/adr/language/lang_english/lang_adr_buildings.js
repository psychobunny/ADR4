/*
Please refer to readme.html for full Instructions

Text[...]=[title,text]

Style[...]=[TitleColor,TextColor,TitleBgColor,TextBgColor,TitleBgImag,TextBgImag,TitleTextAlign,TextTextAlign, TitleFontFace, TextFontFace, TipPosition, StickyStyle, TitleFontSize, TextFontSize, Width, Height, BorderSize, PadTextArea, CoordinateX , CoordinateY, TransitionNumber, TransitionDuration, TransparencyLevel ,ShadowType, ShadowColor]
*/

var FiltersEnabled = 1 // If your Not going To use transitions Or filters In any of the tips Set this To 0

Text[0]=["Tavern","The place where all guilds come"]
Text[1]=["Animalery","All about pets and creatures"]
Text[2]=["Cauldron","The mystic place where you can combine items"]
Text[3]=["Barrack","You can train all your characteristics, change class or see your warehouse"]
Text[4]=["House","Character sheet and your inventory"]
Text[5]=["Library","Characters list, RPG Faq end your Prefs"]
Text[6]=["Workshop","The place where you can find a job"]
Text[7]=["Tower","Your skills and equipments"]

Style[0]=["white","black","#000099","#E8E8FF","","","","","","","","","","",100,"",2,2,10,10,51,0.5,75,"simple","gray"]

applyCssFilter()