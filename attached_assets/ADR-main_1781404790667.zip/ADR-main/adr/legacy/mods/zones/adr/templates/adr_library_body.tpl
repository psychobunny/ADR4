<form method="post" action="{S_ZONES_ACTION}">

<br />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
	<tr>
		<th class="thHead" colspan="3">{L_ZONE_LIBRARY}</th>
	</tr>
	<tr>
		<td align="center" class="row2" width="33%"><br /><b class="gen">{L_ZONE_CHARACTER_LIST}:</b><br \><br \><a href="{U_ZONE_CHARACTER_LIST}"><img src="adr/images/zones/character_list.gif" border="0" ></a><br /><br /></td>
		<td align="center" class="row1" width="33%"><br /><b class="gen">{L_ZONE_CHARACTER_PREFS}:</b><br \><br \><a href="{U_ZONE_CHARACTER_PREFS}"><img src="adr/images/zones/character_prefs.gif" border="0" ></a><br /><br /></td>
		<td align="center" class="row2" width="33%"><br /><b class="gen">{L_ZONE_CHARACTER_FAQ}:</b><br \><br \><a href="{U_ZONE_CHARACTER_FAQ}"><img src="adr/images/zones/character_faq.gif" border="0" ></a><br /><br /></td>
	</tr>
</table>

<br clear="all" />