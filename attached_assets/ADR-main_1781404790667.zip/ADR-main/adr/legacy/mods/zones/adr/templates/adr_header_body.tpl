<!-- BEGIN header -->
<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<td align="center" class="row2"><br /><img src="adr/images/zones/{ZONE_SEASON}/{SHOPS_IMG}.gif" border="0" /><br /><br /><span class="gen">{SHOPS_LINK}</span><br /><br /></td>
		<td align="center" class="row1"><br /><img src="adr/images/zones/{ZONE_SEASON}/{TEMPLE_IMG}.gif" border="0" /><br /><br /><span class="gen">{TEMPLE_LINK}</span><br /><br /></td>
		<td align="center" class="row2"><br /><img src="adr/images/zones/{ZONE_SEASON}/{FORGE_IMG_ZM}.gif" border="0" /><br /><br /><span class="gen">{FORGE_LINK}</span><br /><br /></td>
		<td align="center" class="row1"><br /><img src="adr/images/zones/{ZONE_SEASON}/{BANK_IMG}.gif" border="0" /><br /><br /><span class="gen">{BANK_LINK}</span><br /><br /></td>
		<td align="center" class="row2"><br /><img src="adr/images/zones/{ZONE_SEASON}/{PRISON_IMG}.gif" border="0" /><br /><br /><span class="gen">{PRISON_LINK}</span><br /><br /></td>
	</tr>
	<tr>
		<td align="center" class="row2" colspan="5"><br \><b class="gen">{ZONE_RETURN}</b><br \><br \></td>
	</tr>
</table>
<br clear="all" />
<!-- END header -->