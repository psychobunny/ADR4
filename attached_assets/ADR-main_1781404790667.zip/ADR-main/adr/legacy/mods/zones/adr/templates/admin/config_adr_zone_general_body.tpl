<h1>{L_ZONE_GENERAL_TITLE}</h1>

<p>{L_ZONE_GENERAL_EXPLAIN}</p>

<form method="post" action="{S_ZONE_ACTION}">

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
	<tr>
		<td class="row1" width="60%"><span class="gen">{L_ZONE_DEAD_TRAVEL}</span></td>
		<td class="row1" align="center"><input type="checkbox" name="dead_travel" value="1" {ZONE_DEAD_TRAVEL} /></td>
	</tr>
	<tr>
		<td class="row2"><span class="gen">{L_ZONE_BONUS_STAT}</span></td>
		<td class="row2" align="center"><input type="checkbox" name="stat_bonus" value="1" {ZONE_BONUS_STAT} /></td>
	</tr>
	<tr>
		<td class="row1"><span class="gen">{L_ZONE_BONUS_ATT}</span></td>
		<td class="row1" align="center"><input type="post" class="post" name="att_bonus" maxlength="8" size="8" value="{ZONE_BONUS_ATT}" /></td>
	</tr>
	<tr>
		<td class="row2"><span class="gen">{L_ZONE_BONUS_DEF}</span></td>
		<td class="row2" align="center"><input type="post" class="post" name="def_bonus" maxlength="8" size="8" value="{ZONE_BONUS_DEF}" /></td>
	</tr>
	<tr>
		<td class="cat" colspan="2" align="center"><input type="submit" name="submit" value="{L_ZONE_SUBMIT}" class="mainoption" /></td>
	</tr>
</table>

</form>

<br clear="all" />