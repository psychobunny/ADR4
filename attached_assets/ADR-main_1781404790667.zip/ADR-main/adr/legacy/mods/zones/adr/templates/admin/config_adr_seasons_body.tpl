<h1>{L_SEASONS_TITLE}</h1>

<p>{L_SEASONS_EXPLAIN}</p>

<form method="post" action="{S_SEASONS_ACTION}">

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
	<tr>
		<th class="thHead" colspan="2">{L_SEASONS_CONFIG}</th>
	</tr>
	<tr>
		<td class="row2" width="60%"><span class="gen">{L_SEASON_CHOICE}</span></td>
		<td class="row2" align="center">{SEASON_LIST}</td>
	</tr>
	<tr>
		<td class="row1"><span class="gen">{L_SEASON_TIME}</span></td>
		<td class="row1" align="center"><input type="post" class="post" name="season_time" maxlength="8" size="8" value="{SEASON_TIME}" /><span class="gen">&nbsp;{L_SEASON_DAYS}</span></td>
	</tr>
	<tr>
		<td class="cat" colspan="2" align="center"><input type="submit" name="submit" value="{L_SEASON_SUBMIT}" class="mainoption" /></td>
	</tr>
</table>

</form>

<br clear="all" />