<h1>{L_ZONE_TITLE}</h1>

<p>{L_ZONE_EXPLAIN}</p>

<form method="post" action="{S_ZONES_ACTION}">

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
	<tr>
		<th class="thCornerL">{L_ZONE_NAME}</th>
		<th class="thTop">{L_ZONE_ELEMENT}</th>
		<th class="thTop">{L_ZONE_ITEM}</th>
		<th class="thTop">{L_ZONE_DESTINATION1}</th>
		<th class="thTop">{L_ZONE_DESTINATION2}</th>
		<th class="thTop">{L_ZONE_RETURN}</th>
		<th colspan="2" class="thCornerR">{L_ZONE_ACTION}</th>
	</tr>
	<!-- BEGIN zones -->
	<tr align="center">
		<td class="{zones.ROW_CLASS}">{zones.NAME}</td>
		<td class="{zones.ROW_CLASS}">{zones.ELEMENT}</td>
		<td class="{zones.ROW_CLASS}">{zones.ITEM}</td>
		<td class="{zones.ROW_CLASS}">{zones.DESTINATION1}</td>
		<td class="{zones.ROW_CLASS}">{zones.DESTINATION2}</td>
		<td class="{zones.ROW_CLASS}">{zones.RETURN}</td>
		<td class="{zones.ROW_CLASS}"><a href="{zones.U_ZONES_EDIT}">{L_EDIT}</a></td>
		<td class="{zones.ROW_CLASS}"><a href="{zones.U_ZONES_DELETE}">{L_DELETE}</a></td>
	</tr>
	<!-- END zones -->
	<tr>
		<td class="cat" colspan="2" align="center">{S_HIDDEN_FIELDS}<input type="submit" name="add" value="{L_ZONE_ADD}" class="mainoption" /></td>
	</tr>
</table>

</form>

<br clear="all" />