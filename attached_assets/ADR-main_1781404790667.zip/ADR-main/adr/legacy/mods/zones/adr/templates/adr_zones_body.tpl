<div id="TipLayer" style="visibility:hidden;position:absolute;z-index:1000;top:-100;"></div>

<script language="JavaScript1.2" src="adr/language/lang_{LANG}/lang_adr_buildings.js" type="text/javascript"></script>

<form method="post" action="{S_ZONES_ACTION}">

<br />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead" colspan="2">{ZONE_NAME}</th>
	</tr>
	<tr>
		<td align="center" class="row1" width="40%"><img src="adr/images/zones/zones_img/{ZONE_IMG}.jpg" border="0" /></td>
		<td align="left" class="row2" width="60%"><br \><b class="gen">{L_ZONE_DESCRIPTION}:</b> <span class="gen">{ZONE_DESCRIPTION}</span><br /><br /><b><b class="gen">{L_ZONE_ELEMENT}:</b> <span class="gen">{ZONE_ELEMENT}</span><br /><br />
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
				<tr>
					<th class="thHead" colspan="2">{L_ZONE_SEASON} & {L_ZONE_WEATHER}</th>
				</tr>
				<tr>
					<td align="center" class="row2"><span class="gen">{ZONE_SEASON_NAME}</span><br /><br /><img src="adr/images/zones/seasons/{ZONE_SEASON_IMG}.gif" border="0" ><br /><br /></td>
					<td align="center" class="row2"><span class="gen">{ZONE_WEATHER_NAME}</span><br /><br /><img src="adr/images/zones/weather/{ZONE_WEATHER_IMG}.gif" border="0" ><br /><br /></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<br clear="all" />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead" colspan="5">{L_ZONE_BUILDINGS}</th>
	</tr>
	<tr align="center">
		<td class="row2"><br /><b class="gen">{L_SHOPS_NAME}</b><br /><br /><img src="adr/images/zones/{ZONE_SEASON}/{SHOPS_IMG}.gif" border="0" /><br /><br /><span class="gen">{SHOPS_LINK}</span><br /><br /></td>
		<td class="row1"><br /><b class="gen">{L_TEMPLE_NAME}</b><br /><br /><img src="adr/images/zones/{ZONE_SEASON}/{TEMPLE_IMG}.gif" border="0" /><br /><br /><span class="gen">{TEMPLE_LINK}</span><br /><br /></td>
		<td class="row2"><br /><b class="gen">{L_FORGE_NAME}</b><br /><br /><img src="adr/images/zones/{ZONE_SEASON}/{FORGE_IMG}.gif" border="0" /><br /><br /><span class="gen">{FORGE_LINK}</span><br /><br /></td>
		<td class="row1"><br /><b class="gen">{L_BANK_NAME}</b><br /><br /><img src="adr/images/zones/{ZONE_SEASON}/{BANK_IMG}.gif" border="0" /><br /><br /><span class="gen">{BANK_LINK}</span><br /><br /></td>
		<td class="row2"><br /><b class="gen">{L_PRISON_NAME}</b><br /><br /><img src="adr/images/zones/{ZONE_SEASON}/{PRISON_IMG}.gif" border="0" /><br /><br /><span class="gen">{PRISON_LINK}</span><br /><br /></td>
	</tr>
</table>

<br clear="all" />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead" colspan="3">{L_ZONE_ACTION}</th>
	</tr>
	<tr>
		<td align="center" class="row2" width="30%">
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<th class="thHead">{L_ZONE_GOTO}</th>
				</tr>
				<tr>
					<td align="center" class="row2"><br /><b class="gen">{L_ZONE_GOTO1}:</b> <span class="gen">{ZONE_GOTO1}</span><br /><br /><b class="gen">{L_ZONE_COST}:</b> <span class="gen">{ZONE_COST1}</span><br /><br /><input type="submit" name="goto1" value="{L_GOTO}" class="mainoption" /><br /><br /></td>
				</tr>
			</table>
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<td align="center" class="row1"><br \><b class="gen">{L_ZONE_GOTO2}:</b> <span class="gen">{ZONE_GOTO2}</span><br /><br /><b class="gen">{L_ZONE_COST}:</b> <span class="gen">{ZONE_COST2}</span><br /><br /><input type="submit" name="goto2" value="{L_GOTO}" class="mainoption" /><br /><br /></td>
				</tr>
			</table>
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<td align="center" class="row2"><br \><b class="gen">{L_ZONE_RETURN}:</b> <span class="gen">{ZONE_RETURN}</span><br \><br \><b class="gen">{L_ZONE_COST}:</b> <span class="gen">{ZONE_COST_RETURN}</span><br /><br /><input type="submit" name="return" value="{L_GOTO}" class="mainoption" /><br /><br /></td>
				</tr>
			</table>
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<th class="thHead">{L_POINTS}</th>
				</tr>
				<tr>
					<td align="center" class="row1"><br \><b class="gen">{L_POINTS}:</b> <span class="gen">{POINTS}<br \><br \></span></td>
				</tr>
			</table>
 		</td>
		<td align="center" class="row1" width="60%">
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<th class="thHead">{L_ZONE_TOWN}</th>
				</tr>
				<tr>
					<td align="center" class="row1"><a href="{U_ZONE_GUILD}"><img src="adr/images/zones/{ZONE_SEASON}/tile_1.gif" border="0" onMouseOver="stm(Text[0],Style[0])" onMouseOut="htm()" /></a><a href="{U_ZONE_ANIMALERY}"><img src="adr/images/zones/{ZONE_SEASON}/tile_2.gif" border="0" onMouseOver="stm(Text[1],Style[0])" onMouseOut="htm()" /></a><a href="{U_ZONE_AUTEL}"><img src="adr/images/zones/{ZONE_SEASON}/tile_3.gif" border="0" onMouseOver="stm(Text[2],Style[0])" onMouseOut="htm()" /></a><br /><a href="{U_ZONE_BARRACK}"><img src="adr/images/zones/{ZONE_SEASON}/tile_4.gif" border="0" onMouseOver="stm(Text[3],Style[0])" onMouseOut="htm()" /></a><a href="{U_ZONE_HOUSE}"><img src="adr/images/zones/{ZONE_SEASON}/tile_5.gif" border="0" onMouseOver="stm(Text[4],Style[0])" onMouseOut="htm()" /></a><a href="{U_ZONE_LIBRARY}"><img src="adr/images/zones/{ZONE_SEASON}/tile_6.gif" border="0" onMouseOver="stm(Text[5],Style[0])" onMouseOut="htm()" /></a><br /><a href="{U_ZONE_WORKSHOP}"><img src="adr/images/zones/{ZONE_SEASON}/tile_7.gif" border="0" onMouseOver="stm(Text[6],Style[0])" onMouseOut="htm()" /></a><img src="adr/images/zones/{ZONE_SEASON}/tile_8.gif" border="0" /><a href="{U_ZONE_TOWER}"><img src="adr/images/zones/{ZONE_SEASON}/tile_9.gif" border="0" onMouseOver="stm(Text[7],Style[0])" onMouseOut="htm()" /></a></td>
				</tr>
			</table>
		</td>
		<td align="center" class="row2" width="10%">
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<th class="thHead">{L_ZONE_BATTLE}</th>
				</tr>
				<tr>
					<td align="center" class="row2"><br /><b class="gen">{L_BATTLE}:</b><br /><a href="{U_ZONE_BATTLE}"><img src="adr/images/zones/monster_battle.gif " alt="{L_BATTLE}" border="0" /></a><br /><br /><b class="gen">{L_PVP_BATTLE}:</b><br /><a href="{U_ZONE_PVP_BATTLE}"><img src="adr/images/zones/pvp_battle.gif " alt="{L_PVP_BATTLE}" border="0" /></a><br /><br /></td>
				</tr>
			</table>
			</form>
			<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
				<tr>
					<th class="thHead">{L_ZONE_SHOUTBOX}</th>
				</tr>
				<tr>
					<td align="center" class="row2">
						<div>
							<form method="post">
								<span class="gen">Name:</span><br \><input name="pseudo" size="19"><br /><br \>
	                                                        <span class="gen">Message:</span><br \><textarea name="mess" cols="20" rows="3"></textarea><br /><br />
								<input name="submit" type="submit" value="Submit"> <input name="submit" type="submit" value="Refresh"><br /><br />
							</form>
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<br clear="all" />

<form method="post" action="{S_ZONES_ACTION}">

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead" colspan="5">{L_ZONE_NPC}</th>
	</tr>
	<tr>
		<td align="center" class="row2" colspan="5"><br /><span class="gen">{ZONE_NPC_PRICE}</span><br /><br /></td>
	</tr>
	<tr>
		<td align="center" class="row2"><br /><b class="gen">{L_NPC1_NAME}</b><br /><br /><img src="adr/images/zones/npc/{NPC1_IMG}.gif" border="0" /><br /><br />{NPC1_LINK}<br /><br /></td>
		<td align="center" class="row1"><br /><b class="gen">{L_NPC2_NAME}</b><br /><br /><img src="adr/images/zones/npc/{NPC2_IMG}.gif" border="0" /><br /><br />{NPC2_LINK}<br /><br /></td>
		<td align="center" class="row2"><br /><b class="gen">{L_NPC3_NAME}</b><br /><br /><img src="adr/images/zones/npc/{NPC3_IMG}.gif" border="0" /><br /><br />{NPC3_LINK}<br /><br /></td>
		<td align="center" class="row1"><br /><b class="gen">{L_NPC4_NAME}</b><br /><br /><img src="adr/images/zones/npc/{NPC4_IMG}.gif" border="0" /><br /><br />{NPC4_LINK}<br /><br /></td>
		<td align="center" class="row2"><br /><b class="gen">{L_NPC5_NAME}</b><br /><br /><img src="adr/images/zones/npc/{NPC5_IMG}.gif" border="0" /><br /><br />{NPC5_LINK}<br /><br /></td>
	</tr>
</table>

<br clear="all" />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead">{L_ZONE_CONNECTED}</th>
	</tr>
  	<tr>
		<td class="row1"><br \><span class="gen">{USERS_CONNECTED_LIST}</span><br \><br \></td>
  	</tr>
</table>

<br clear="all" />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="100%">
	<tr>
		<th class="thHead">Chat</th>
	</tr>
</table>

</form>