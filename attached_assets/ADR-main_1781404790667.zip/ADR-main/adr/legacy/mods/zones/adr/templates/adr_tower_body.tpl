<form method="post" action="{S_ZONES_ACTION}">

<br />

<table align="center" border="0" cellspacing="1" cellpadding="3" class="forumline" width="90%">
	<tr>
		<th class="thHead" colspan="2">{L_ZONE_TOWER}</th>
	</tr>
	<tr>
		<td align="center" class="row2" width="50%"><br /><b class="gen">{L_ZONE_CHARACTER_SKILLS}:</b><br \><br \><a href="{U_ZONE_CHARACTER_SKILLS}"><img src="adr/images/zones/character_skills.gif" border="0" ></a><br /><br /></td>
		<td align="center" class="row1" width="50%"><br /><b class="gen">{L_ZONE_CHARACTER_EQUIP}:</b><br \><br \><a href="{U_ZONE_CHARACTER_EQUIP}"><img src="adr/images/zones/character_equip.gif" border="0" ></a><br /><br /></td>
	</tr>
</table>

<br clear="all" />