<?php
/***************************************************************************
 *                              adr_header.php
 *                            -------------------
 *   begin                : 09/03/2005
 *   copyright            : one_piece
 *   site                 : http://mangas-no-ushi.com/
 *
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
	die('Hacking attempt');

// Includes the tpl
adr_advanced_template_file('adr_header_body.tpl',header);

// Just because this may be if use for furthers versions
$template->assign_block_vars('header',array());

##=== START: cache update check
if(time() > ($adr_general['Adr_cache_last_updated'] + ($adr_general['Adr_cache_interval'] *60))){
   adr_update_all_cache_infos(); // check for cache update
   if($adr_general['Adr_character_limit_enable'] == '1'){
      adr_character_replen_quota();} // check for quota's etc update
}
##=== END: cache update check

// Get the general character infos
$adr_user = adr_get_user_infos($user_id);

// Get Zone infos
$area_id = $adr_user['character_area'];
$actual_season = $board_config['adr_seasons'];

$sql = " SELECT * FROM  " . ADR_ZONES_TABLE . "
       WHERE zone_id = '$area_id' ";
if( !($result = $db->sql_query($sql)) )
        message_die(GENERAL_ERROR, 'Could not query area list', '', __LINE__, __FILE__, $sql);

$zone = $db->sql_fetchrow($result);
$zone_shops = $zone['zone_shops'];
$zone_forge = $zone['zone_forge'];
$zone_temple = $zone['zone_temple'];
$zone_prison = $zone['zone_prison'];
$zone_bank = $zone['zone_bank'];

// Building images
( $zone_temple == '1' ) ? $temple = 'temple_enable' : $temple = 'temple_disable';
( $zone_prison == '1' ) ? $prison = 'prison_enable' : $prison = 'prison_disable';
( $zone_shops == '1' ) ? $shops = 'shops_enable' : $shops = 'shops_disable';
( $zone_forge == '1' ) ? $forge = 'forge_enable' : $forge = 'forge_disable';
( $zone_bank == '1' ) ? $bank = 'bank_enable' : $bank = 'bank_disable';

// Building links
( $zone_temple == '1' ) ? $temple_link = '<a href="'.append_sid("adr_temple.$phpEx").'">'. $lang['Adr_zone_goto_temple'] .'</a>' : $temple_link = $lang['Adr_zone_building_disable'];
( $zone_prison == '1' ) ? $prison_link = '<a href="'.append_sid("adr_courthouse.$phpEx").'">'. $lang['Adr_zone_goto_prison'] .'</a>' : $prison_link = $lang['Adr_zone_building_disable'];
( $zone_shops == '1' ) ? $shops_link = '<a href="'.append_sid("adr_shops.$phpEx").'">'. $lang['Adr_zone_goto_shops'] .'</a>' : $shops_link = $lang['Adr_zone_building_disable'];
( $zone_forge == '1' ) ? $forge_link = '<a href="'.append_sid("adr_forge.$phpEx").'">'. $lang['Adr_zone_goto_forge'] .'</a>' : $forge_link = $lang['Adr_zone_building_disable'];
( $zone_bank == '1' ) ? $bank_link = '<a href="'.append_sid("adr_vault.$phpEx").'">'. $lang['Adr_zone_goto_bank'] .'</a>' : $bank_link = $lang['Adr_zone_building_disable'];

$template->assign_vars(array(
	'ZONE_SEASON' => $actual_season,
	'SHOPS_IMG' => $shops,
	'TEMPLE_IMG' => $temple,
	'FORGE_IMG_ZM' => $forge,
	'BANK_IMG' => $bank,
	'PRISON_IMG' => $prison,
	'SHOPS_LINK' => $shops_link,
	'TEMPLE_LINK' => $temple_link,
	'FORGE_LINK' => $forge_link,
	'BANK_LINK' => $bank_link,
	'PRISON_LINK' => $prison_link,
	'ZONE_RETURN' => $lang['Adr_zone_header_return'],
	'L_COPYRIGHT' => $lang['Adr_copyright'],
	'U_COPYRIGHT' => append_sid("adr_copyright.$phpEx"),
));

$template->pparse('header');

?>